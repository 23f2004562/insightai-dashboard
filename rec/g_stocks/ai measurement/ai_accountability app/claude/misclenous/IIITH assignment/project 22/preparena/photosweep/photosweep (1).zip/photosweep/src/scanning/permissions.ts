/**
 * Turns the platform's permission response into states the UI can explain.
 * Pure (no Expo imports) so it can be tested anywhere.
 */

/** The fields we read from expo-media-library's PermissionResponse. */
export interface PermissionLike {
  status: 'granted' | 'denied' | 'undetermined' | string;
  granted: boolean;
  canAskAgain: boolean;
  accessPrivileges?: 'all' | 'limited' | 'none';
}

export type LibraryAccess =
  | 'undetermined' // never asked
  | 'all' // full library
  | 'limited' // only photos the user picked (iOS 14+, Android 14+)
  | 'denied' // said no, but we may ask again
  | 'blocked' // denied permanently, or restricted (e.g. parental controls): only Settings can change it
  | 'unavailable'; // this platform has no photo library (web)

export function toLibraryAccess(r: PermissionLike): LibraryAccess {
  if (r.granted || r.status === 'granted') {
    return r.accessPrivileges === 'limited' ? 'limited' : 'all';
  }
  if (r.status === 'undetermined') return 'undetermined';
  // iOS "restricted" arrives as denied with canAskAgain = false, same as "denied for good".
  return r.canAskAgain ? 'denied' : 'blocked';
}

export function canScan(access: LibraryAccess): boolean {
  return access === 'all' || access === 'limited';
}
