/**
 * Photo sources: everything about WHERE photos come from.
 *
 * To add a new source later (e.g. the Android gallery):
 *   1. Create a file that implements PhotoSourceAdapter (see adapter.ts).
 *   2. Add it to `activeAdapters` below.
 * Screens don't need to change.
 */
import { PhotoSourceAdapter } from './adapter';
import { sampleAdapter } from './sample/sampleAdapter';

export * from './adapter';
export * from './catalog';
export * from './ids';
export * from './providers';

/** The adapters the app uses. Only the sample adapter exists in this milestone. */
export const activeAdapters: PhotoSourceAdapter[] = [sampleAdapter];
