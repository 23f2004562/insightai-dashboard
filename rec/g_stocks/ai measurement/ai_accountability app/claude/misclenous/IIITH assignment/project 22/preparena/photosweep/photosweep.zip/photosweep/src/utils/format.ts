/** Small formatting helpers shared by many screens. */

/** 3_400_000 → "3.2 MB", 2_100_000_000 → "1.96 GB" */
export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let value = bytes / 1024;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  const decimals = value >= 100 ? 0 : 1;
  return `${value.toFixed(decimals)} ${units[unit]}`;
}

/** 4812 → "4,812" */
export function formatCount(n: number): string {
  return n.toLocaleString('en-US');
}

/** "2026-08-14T18:42:03Z" → "Aug 14, 2026" */
export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

/** Picks the singular or plural word: plural(1, 'photo') → "1 photo" */
export function plural(n: number, word: string, pluralWord = `${word}s`): string {
  return `${formatCount(n)} ${n === 1 ? word : pluralWord}`;
}

/** 4032, 3024 → "4032 × 3024" */
export function formatDimensions(width: number, height: number): string {
  return `${width} × ${height}`;
}
