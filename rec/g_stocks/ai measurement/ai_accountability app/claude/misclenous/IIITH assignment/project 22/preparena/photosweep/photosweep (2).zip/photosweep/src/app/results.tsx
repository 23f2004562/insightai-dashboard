import { Redirect, router } from 'expo-router';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Animated, FlatList, StyleSheet, View } from 'react-native';

import {
  ActionBar,
  AppText,
  Button,
  Chip,
  DuplicateGroupCard,
  SampleBadge,
  Screen,
  ScreenHeader,
} from '@/components';
import { useScan } from '@/state/ScanContext';
import { colors, radius, spacing } from '@/theme';
import { MatchKind } from '@/types';
import { formatBytes, plural } from '@/utils/format';

/** DUPLICATE RESULTS — review each group and choose what to keep. */

type Filter = 'all' | MatchKind;
const filters: { key: Filter; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'exact', label: 'Exact copies' },
  { key: 'similar', label: 'Look-alikes' },
];

export default function ResultsScreen() {
  const { summary, decisions, togglePhoto, applySuggestion, applyAllSuggestions, markedPhotos, markedBytes } =
    useScan();
  const [filter, setFilter] = useState<Filter>('all');
  const [notice, setNotice] = useState<string | null>(null);
  const noticeOpacity = useRef(new Animated.Value(0)).current;

  // Short message shown when the user tries to delete the last copy in a group.
  useEffect(() => {
    if (!notice) return;
    Animated.timing(noticeOpacity, { toValue: 1, duration: 150, useNativeDriver: true }).start();
    const t = setTimeout(() => {
      Animated.timing(noticeOpacity, { toValue: 0, duration: 200, useNativeDriver: true }).start(() =>
        setNotice(null),
      );
    }, 2600);
    return () => clearTimeout(t);
  }, [notice, noticeOpacity]);

  const groups = useMemo(
    () => (summary ? summary.groups.filter((g) => filter === 'all' || g.kind === filter) : []),
    [summary, filter],
  );

  // If someone lands here without results (e.g. app reloaded), send them home.
  if (!summary) return <Redirect href="/home" />;

  const handleToggle = (groupId: string, photoId: string) => {
    if (togglePhoto(groupId, photoId) === 'blocked-last-copy') {
      setNotice('Each group keeps at least one photo. Keep another one first.');
    }
  };

  const header = (
    <View style={styles.listHeader}>
      <ScreenHeader title="Duplicates" />
      <SampleBadge kind="banner" />
      <AppText variant="small" color="inkSoft" style={styles.hint}>
        Tap a photo to switch it between keep and delete. Everything is kept until you change it.
      </AppText>
      <View style={styles.filters}>
        {filters.map((f) => (
          <Chip key={f.key} label={f.label} selected={filter === f.key} onPress={() => setFilter(f.key)} />
        ))}
      </View>
      <Button
        label="Keep the best photo in every group"
        icon="star"
        variant="secondary"
        onPress={applyAllSuggestions}
      />
    </View>
  );

  return (
    <Screen
      edges={['top', 'left', 'right']}
      contentStyle={styles.noPad}
      footer={
        <ActionBar>
          <View style={styles.barText}>
            <AppText variant="bodyStrong">
              {markedPhotos.length === 0 ? 'Nothing marked' : plural(markedPhotos.length, 'photo')}
            </AppText>
            <AppText variant="small" color="inkSoft">
              {markedPhotos.length === 0 ? 'Tap photos to mark them' : `${formatBytes(markedBytes)} to free up`}
            </AppText>
          </View>
          <Button
            label="Review"
            icon="trash-2"
            variant="danger"
            disabled={markedPhotos.length === 0}
            onPress={() => router.push('/confirm')}
            accessibilityHint="Opens a summary of photos marked for deletion. Nothing is deleted yet."
          />
        </ActionBar>
      }
    >
      <FlatList
        data={groups}
        keyExtractor={(g) => g.id}
        ListHeaderComponent={header}
        contentContainerStyle={styles.list}
        ItemSeparatorComponent={() => <View style={{ height: spacing.md }} />}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <DuplicateGroupCard
            group={item}
            decisions={decisions}
            onTogglePhoto={(photoId) => handleToggle(item.id, photoId)}
            onUseSuggestion={() => applySuggestion(item.id)}
          />
        )}
        ListEmptyComponent={
          <AppText variant="small" color="inkSoft" align="center">
            No groups of this type.
          </AppText>
        }
      />

      {notice && (
        <Animated.View style={[styles.notice, { opacity: noticeOpacity }]} pointerEvents="none">
          <AppText variant="small" color="onNight">
            {notice}
          </AppText>
        </Animated.View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  noPad: { paddingHorizontal: 0, paddingBottom: 0, maxWidth: undefined },
  list: { paddingHorizontal: spacing.lg, paddingBottom: spacing.xl, width: '100%', maxWidth: 640, alignSelf: 'center' },
  listHeader: { gap: spacing.md, marginBottom: spacing.md },
  hint: { marginTop: -spacing.xxs },
  filters: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  barText: { flex: 1 },
  notice: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    bottom: spacing.md,
    backgroundColor: colors.ink,
    padding: spacing.sm,
    borderRadius: radius.md,
  },
});
