/**
 * Spacing and corner-radius scale.
 *
 * Using a fixed scale (4, 8, 12, 16 …) instead of random numbers keeps
 * every screen visually consistent.
 */
export const spacing = {
  xxs: 4,
  xs: 8,
  sm: 12,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
} as const;

/** Radius grows with the size of the element: small chips are tighter, big panels softer. */
export const radius = {
  sm: 6, // thumbnails, chips
  md: 12, // buttons
  lg: 20, // cards and panels
  pill: 999,
} as const;
