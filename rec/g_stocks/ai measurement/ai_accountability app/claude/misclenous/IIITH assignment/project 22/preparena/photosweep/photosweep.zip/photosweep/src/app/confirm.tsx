import { Feather } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import { useState } from 'react';
import { Pressable, StyleSheet, useWindowDimensions, View } from 'react-native';

import { AccountBadge, ActionBar, AppText, Button, PhotoThumb, SampleBadge, Screen, ScreenHeader } from '@/components';
import { groupByAccount, splitByDeletionPolicy, totalBytes } from '@/state/selection';
import { useScan } from '@/state/ScanContext';
import { colors, radius, spacing } from '@/theme';
import { Photo, PhotoCatalog } from '@/types';
import { formatBytes, plural } from '@/utils/format';

/**
 * CONFIRM — the safety step, now account-aware.
 *
 * Marked photos are split into:
 * - On this phone: would be deleted later, through the phone's own dialog
 * - In cloud accounts: NEVER deleted by PhotoSweep; they go on a manual checklist
 * Every photo is listed under the account that contains it.
 * In this milestone nothing is deleted.
 */
export default function ConfirmScreen() {
  const { summary, markedPhotos, markedBytes } = useScan();
  const [checked, setChecked] = useState(false);
  const { width } = useWindowDimensions();

  if (!summary || markedPhotos.length === 0) return <Redirect href="/results" />;

  const { device, cloud } = splitByDeletionPolicy(markedPhotos);
  const contentWidth = Math.min(width, 640) - spacing.lg * 2 - spacing.md * 2;
  // minus 4 for the account block's borders, so four thumbnails fit on every row
  const thumb = Math.floor((contentWidth - 4 - spacing.sm * 3) / 4);

  const buttonLabel = device.length > 0 ? `Delete ${plural(device.length, 'phone photo')}` : 'Create cleanup checklist';

  return (
    <Screen
      scroll
      edges={['top', 'left', 'right']}
      footer={
        <ActionBar>
          <Button label="Cancel" variant="secondary" onPress={() => router.back()} />
          <Button
            label={buttonLabel}
            variant="danger"
            icon={device.length > 0 ? 'trash-2' : 'check-square'}
            disabled={!checked}
            style={styles.flex}
            onPress={() => router.replace('/done')}
            accessibilityHint="Prototype only: shows what would happen. Nothing is deleted."
          />
        </ActionBar>
      }
    >
      <ScreenHeader title="Review removal" leading="close" />

      <View style={styles.summary}>
        <AppText variant="number" color="remove">
          {plural(markedPhotos.length, 'photo')}
        </AppText>
        <AppText variant="body" color="inkSoft">
          {formatBytes(markedBytes)} across {plural(groupByAccount(markedPhotos).length, 'account')}. One copy of every
          group is kept.
        </AppText>
      </View>

      <SampleBadge
        kind="banner"
        message="Prototype with sample accounts. Confirming will not delete anything from any phone or account."
      />

      {device.length > 0 && (
        <Section
          icon="smartphone"
          title="On this phone"
          detail={`${plural(device.length, 'photo')}, ${formatBytes(totalBytes(device))}. In the finished app, your phone will ask you to confirm before anything is deleted.`}
          photos={device}
          catalog={summary.catalog}
          thumb={thumb}
        />
      )}

      {cloud.length > 0 && (
        <Section
          icon="flag"
          title="In cloud accounts"
          detail={`${plural(cloud.length, 'photo')}, ${formatBytes(totalBytes(cloud))}. PhotoSweep never deletes cloud photos. You'll get a checklist to remove these yourself in each account.`}
          photos={cloud}
          catalog={summary.catalog}
          thumb={thumb}
        />
      )}

      <Pressable
        onPress={() => setChecked((c) => !c)}
        style={styles.check}
        accessibilityRole="checkbox"
        accessibilityState={{ checked }}
      >
        <View style={[styles.box, checked && styles.boxOn]}>
          {checked && <Feather name="check" size={16} color="#FFFFFF" />}
        </View>
        <AppText variant="bodyStrong" style={styles.flex}>
          I've checked these photos and the accounts they're in
        </AppText>
      </Pressable>
    </Screen>
  );
}

interface SectionProps {
  icon: 'smartphone' | 'flag';
  title: string;
  detail: string;
  photos: Photo[];
  catalog: PhotoCatalog;
  thumb: number;
}

/** One section (phone or cloud), with a block per account. */
function Section({ icon, title, detail, photos, catalog, thumb }: SectionProps) {
  return (
    <View style={styles.section}>
      <View style={styles.sectionHead}>
        <Feather name={icon} size={18} color={colors.ink} />
        <AppText variant="heading">{title}</AppText>
      </View>
      <AppText variant="small" color="inkSoft">
        {detail}
      </AppText>
      {groupByAccount(photos).map(({ accountId, photos: list }) => (
        <View key={accountId} style={styles.accountBlock}>
          <View style={styles.accountHead}>
            <AccountBadge account={catalog.accounts[accountId]} variant="full" />
            <AppText variant="smallStrong" color="inkSoft">
              {list.length}
            </AppText>
          </View>
          <View style={styles.grid}>
            {list.map((p) => (
              <PhotoThumb key={p.id} photo={p} size={thumb} decision="delete" account={catalog.accounts[accountId]} />
            ))}
          </View>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  summary: { gap: spacing.xxs, marginBottom: spacing.md },
  section: { marginTop: spacing.xl, gap: spacing.sm },
  sectionHead: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  accountBlock: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.md,
    gap: spacing.md,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  accountHead: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  check: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.xl,
    padding: spacing.md,
    backgroundColor: colors.card,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  box: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: colors.inkFaint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  boxOn: { backgroundColor: colors.remove, borderColor: colors.remove },
});
