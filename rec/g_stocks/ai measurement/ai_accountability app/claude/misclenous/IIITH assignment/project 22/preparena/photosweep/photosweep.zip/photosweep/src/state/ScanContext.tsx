import { createContext, ReactNode, useCallback, useContext, useMemo, useState } from 'react';

import { sampleGroups } from '@/data/sampleData';
import { activeAdapters, buildCatalog } from '@/sources';
import { Photo, PhotoId, ScanSummary } from '@/types';
import {
  Decisions,
  decisionFor,
  markedForDeletion,
  suggestedDecisions,
  totalBytes,
  wouldDeleteLastCopy,
} from './selection';

/**
 * Shared app state, available to every screen.
 *
 * WHY CONTEXT? The Results screen sets keep/delete choices and the Confirm
 * screen reads them. Context lets both share the same data.
 *
 * Nothing here touches a real photo library or account. It holds sample
 * data and the user's choices in memory; closing the app resets everything.
 */

export type ToggleResult =
  | { status: 'marked'; photo: Photo }
  | { status: 'kept'; photo: Photo }
  | { status: 'blocked-last-copy' }
  | { status: 'not-found' };

interface ScanContextValue {
  /** null until a (demo) scan has finished. */
  summary: ScanSummary | null;
  decisions: Decisions;
  markedPhotos: Photo[];
  markedBytes: number;

  /** Loads sample accounts through the adapter layer and attaches sample groups. */
  loadSampleResults: () => Promise<void>;
  togglePhoto: (groupId: string, photoId: PhotoId) => ToggleResult;
  applySuggestion: (groupId: string) => void;
  applyAllSuggestions: () => void;
  clearDecisions: () => void;
}

const ScanContext = createContext<ScanContextValue | null>(null);

export function ScanProvider({ children }: { children: ReactNode }) {
  const [summary, setSummary] = useState<ScanSummary | null>(null);
  const [decisions, setDecisions] = useState<Decisions>({});

  const loadSampleResults = useCallback(async () => {
    // Same path real sources will use: adapters → catalog.
    const catalog = await buildCatalog(activeAdapters);
    const totalPhotosScanned = Object.values(catalog.accounts).reduce((n, a) => n + (a.totalPhotos ?? 0), 0);
    setSummary({
      source: 'sample',
      totalPhotosScanned,
      catalog,
      // Duplicate detection isn't built yet, so the groups are sample groups too.
      groups: sampleGroups.filter((g) => g.photoIds.every((id) => catalog.photos[id])),
      completedAt: new Date().toISOString(),
    });
    setDecisions({}); // start with everything kept — the user decides
  }, []);

  const togglePhoto = useCallback(
    (groupId: string, photoId: PhotoId): ToggleResult => {
      const group = summary?.groups.find((g) => g.id === groupId);
      const photo = summary?.catalog.photos[photoId];
      if (!group || !photo) return { status: 'not-found' };

      const current = decisionFor(decisions, photoId);
      if (current === 'keep' && wouldDeleteLastCopy(group, decisions, photoId)) {
        return { status: 'blocked-last-copy' };
      }
      const next = current === 'keep' ? 'delete' : 'keep';
      setDecisions((prev) => ({ ...prev, [photoId]: next }));
      return { status: next === 'delete' ? 'marked' : 'kept', photo };
    },
    [summary, decisions],
  );

  const applySuggestion = useCallback(
    (groupId: string) => {
      const group = summary?.groups.find((g) => g.id === groupId);
      if (group) setDecisions((prev) => ({ ...prev, ...suggestedDecisions(group) }));
    },
    [summary],
  );

  const applyAllSuggestions = useCallback(() => {
    if (!summary) return;
    setDecisions(summary.groups.reduce<Decisions>((acc, g) => ({ ...acc, ...suggestedDecisions(g) }), {}));
  }, [summary]);

  const clearDecisions = useCallback(() => setDecisions({}), []);

  const value = useMemo<ScanContextValue>(() => {
    const markedPhotos = summary ? markedForDeletion(summary.groups, summary.catalog, decisions) : [];
    return {
      summary,
      decisions,
      markedPhotos,
      markedBytes: totalBytes(markedPhotos),
      loadSampleResults,
      togglePhoto,
      applySuggestion,
      applyAllSuggestions,
      clearDecisions,
    };
  }, [summary, decisions, loadSampleResults, togglePhoto, applySuggestion, applyAllSuggestions, clearDecisions]);

  return <ScanContext.Provider value={value}>{children}</ScanContext.Provider>;
}

export function useScan(): ScanContextValue {
  const ctx = useContext(ScanContext);
  if (!ctx) throw new Error('useScan must be used inside <ScanProvider>');
  return ctx;
}
