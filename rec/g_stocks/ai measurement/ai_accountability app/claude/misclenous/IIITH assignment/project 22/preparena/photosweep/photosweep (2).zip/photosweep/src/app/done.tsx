import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { StyleSheet, View } from 'react-native';

import { AppText, Button, Screen } from '@/components';
import { useScan } from '@/state/ScanContext';
import { colors, spacing } from '@/theme';
import { formatBytes, plural } from '@/utils/format';

/**
 * OUTCOME SCREEN after confirming.
 * Says plainly that this was a demo and nothing was deleted.
 */
export default function DoneScreen() {
  const { count, bytes } = useLocalSearchParams<{ count: string; bytes: string }>();
  const { clearDecisions } = useScan();
  const n = Number(count) || 0;
  const b = Number(bytes) || 0;

  const finish = () => {
    clearDecisions();
    router.dismissTo('/home');
  };

  return (
    <Screen edges={['top', 'bottom', 'left', 'right']} contentStyle={styles.content}>
      <View style={styles.middle}>
        <View style={styles.icon}>
          <Feather name="check" size={32} color={colors.keep} />
        </View>
        <AppText variant="title" align="center">
          Demo complete
        </AppText>
        <AppText variant="body" color="inkSoft" align="center" style={styles.text}>
          In the finished app, {plural(n, 'photo')} would now be deleted, freeing {formatBytes(b)}.{'\n\n'}
          This prototype uses sample photos, so nothing was deleted.
        </AppText>
      </View>
      <Button label="Back to overview" size="lg" onPress={finish} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { justifyContent: 'space-between', paddingTop: spacing.md, paddingBottom: spacing.md },
  middle: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.md },
  icon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: colors.keepTint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: { maxWidth: 340 },
});
