import { Feather } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { Pressable, StyleSheet, View } from 'react-native';

import { providers } from '@/sources';
import { colors, radius } from '@/theme';
import { Photo, PhotoDecision, SourceAccount } from '@/types';
import { formatBytes, formatDimensions } from '@/utils/format';
import { AccountBadge, describeAccount } from './AccountBadge';
import { AppText } from './AppText';

interface PhotoThumbProps {
  photo: Photo;
  size: number;
  decision?: PhotoDecision;
  suggested?: boolean;
  onPress?: () => void;
  /** The account this photo is in. When given, it's shown under the thumbnail. */
  account?: SourceAccount;
  /** Show email/label, file size and dimensions under the thumbnail. */
  showDetails?: boolean;
}

/**
 * One photo thumbnail.
 * - Keep:   teal ring + check
 * - Delete: dimmed, red ring. Trash icon for phone photos;
 *           flag icon for cloud photos, which the user removes manually.
 */
export function PhotoThumb({ photo, size, decision, suggested, onPress, account, showDetails }: PhotoThumbProps) {
  const isDelete = decision === 'delete';
  const isKeep = decision === 'keep';
  const isCloud = providers[photo.provider].kind === 'cloud';

  const a11y = [
    photo.filename,
    account ? `in ${describeAccount(account)}` : null,
    formatBytes(photo.sizeBytes),
    formatDimensions(photo.width, photo.height).replace('×', 'by'),
    decision ? `marked to ${decision === 'delete' ? (isCloud ? 'remove manually' : 'delete') : 'keep'}` : null,
    suggested ? 'suggested to keep' : null,
  ]
    .filter(Boolean)
    .join(', ');

  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      accessibilityRole={onPress ? 'button' : 'image'}
      accessibilityLabel={a11y}
      accessibilityHint={onPress ? 'Double tap to switch between keep and delete' : undefined}
      style={({ pressed }) => [{ width: size, opacity: pressed ? 0.85 : 1 }]}
    >
      <View
        style={[styles.frame, { width: size, height: size }, isKeep && styles.keepFrame, isDelete && styles.deleteFrame]}
      >
        <Image
          source={{ uri: photo.uri }}
          style={[styles.image, isDelete && styles.dimmed]}
          contentFit="cover"
          transition={200}
          placeholder={{ blurhash: 'L6PZfSi_.AyE_3t7t7R**0o#DgR4' }}
        />
        {decision && (
          <View style={[styles.mark, isDelete ? styles.markDelete : styles.markKeep]}>
            <Feather name={isDelete ? (isCloud ? 'flag' : 'trash-2') : 'check'} size={13} color="#FFFFFF" />
          </View>
        )}
        {suggested && (
          <View style={styles.bestTag}>
            <Feather name="star" size={10} color={colors.ink} />
            <AppText variant="caption" style={styles.bestText}>
              Best
            </AppText>
          </View>
        )}
      </View>

      {showDetails ? (
        <View style={styles.details}>
          {account && <AccountBadge account={account} />}
          {account?.provider === 'device' && (
            <AppText variant="caption" color="inkFaint" numberOfLines={1} ellipsizeMode="middle">
              {photo.filename}
            </AppText>
          )}
          {account && account.provider !== 'device' && (
            <AppText variant="caption" color="inkFaint" numberOfLines={1} ellipsizeMode="middle">
              {account.email ?? 'Email not shared'}
            </AppText>
          )}
          <AppText variant="caption" color={isDelete ? 'remove' : 'inkSoft'} numberOfLines={1}>
            {formatBytes(photo.sizeBytes)}
          </AppText>
          <AppText variant="caption" color="inkFaint" numberOfLines={1}>
            {formatDimensions(photo.width, photo.height)}
          </AppText>
        </View>
      ) : (
        <AppText variant="caption" color={isDelete ? 'remove' : 'inkSoft'} numberOfLines={1} style={styles.size}>
          {formatBytes(photo.sizeBytes)}
        </AppText>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  frame: {
    borderRadius: radius.sm + 2,
    overflow: 'hidden',
    backgroundColor: colors.sunken,
    borderWidth: 3,
    borderColor: 'transparent',
  },
  keepFrame: { borderColor: colors.keep },
  deleteFrame: { borderColor: colors.remove },
  image: { flex: 1 },
  dimmed: { opacity: 0.4 },
  mark: {
    position: 'absolute',
    top: 5,
    right: 5,
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  markKeep: { backgroundColor: colors.keep },
  markDelete: { backgroundColor: colors.remove },
  bestTag: {
    position: 'absolute',
    left: 5,
    bottom: 5,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    backgroundColor: 'rgba(255,255,255,0.92)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: radius.pill,
  },
  bestText: { fontWeight: '700', color: colors.ink },
  size: { marginTop: 4, textAlign: 'center' },
  details: { marginTop: 6, gap: 1 },
});
