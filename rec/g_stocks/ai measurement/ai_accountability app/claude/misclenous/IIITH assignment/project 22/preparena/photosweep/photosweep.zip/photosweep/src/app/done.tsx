import { Feather } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import { useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { AccountBadge, ActionBar, AppText, Button, Screen } from '@/components';
import { providers } from '@/sources';
import { groupByAccount, splitByDeletionPolicy, totalBytes } from '@/state/selection';
import { useScan } from '@/state/ScanContext';
import { colors, radius, spacing } from '@/theme';
import { PhotoId } from '@/types';
import { formatBytes, plural } from '@/utils/format';

/**
 * OUTCOME after confirming.
 * - Phone photos: says what would happen; nothing was deleted (prototype).
 * - Cloud photos: a checklist per account for the user to remove manually.
 */
export default function DoneScreen() {
  const { summary, markedPhotos, clearDecisions } = useScan();
  const [ticked, setTicked] = useState<Record<PhotoId, boolean>>({});

  if (!summary) return <Redirect href="/home" />;
  const { device, cloud } = splitByDeletionPolicy(markedPhotos);

  const finish = () => {
    clearDecisions();
    router.dismissTo('/home');
  };

  return (
    <Screen
      scroll
      edges={['top', 'left', 'right']}
      footer={
        <ActionBar>
          <Button label="Back to overview" size="lg" onPress={finish} style={styles.flex} />
        </ActionBar>
      }
    >
      <View style={styles.top}>
        <View style={styles.icon}>
          <Feather name="check" size={32} color={colors.keep} />
        </View>
        <AppText variant="title" align="center">
          Demo complete
        </AppText>
        <AppText variant="body" color="inkSoft" align="center" style={styles.text}>
          This prototype uses sample accounts and photos, so nothing was deleted anywhere.
        </AppText>
      </View>

      {device.length > 0 && (
        <View style={styles.block}>
          <View style={styles.blockHead}>
            <Feather name="smartphone" size={18} color={colors.ink} />
            <AppText variant="heading">On this phone</AppText>
          </View>
          <AppText variant="small" color="inkSoft">
            In the finished app, your phone would ask you to confirm deleting {plural(device.length, 'photo')} (
            {formatBytes(totalBytes(device))}). They would then sit in Recently Deleted for a while before being removed
            for good.
          </AppText>
        </View>
      )}

      {cloud.length > 0 && (
        <View style={styles.block}>
          <View style={styles.blockHead}>
            <Feather name="flag" size={18} color={colors.ink} />
            <AppText variant="heading">Remove these yourself</AppText>
          </View>
          <AppText variant="small" color="inkSoft">
            PhotoSweep doesn't delete cloud photos. Open each account's app and remove these copies, ticking them off as
            you go.
          </AppText>

          {groupByAccount(cloud).map(({ accountId, photos }) => {
            const account = summary.catalog.accounts[accountId];
            return (
              <View key={accountId} style={styles.account}>
                <AccountBadge account={account} variant="full" />
                <AppText variant="caption" color="inkFaint">
                  Open {providers[account.provider].label} with this account
                </AppText>
                {photos.map((p) => {
                  const on = Boolean(ticked[p.id]);
                  return (
                    <Pressable
                      key={p.id}
                      onPress={() => setTicked((t) => ({ ...t, [p.id]: !on }))}
                      style={styles.item}
                      accessibilityRole="checkbox"
                      accessibilityState={{ checked: on }}
                    >
                      <View style={[styles.box, on && styles.boxOn]}>
                        {on && <Feather name="check" size={14} color="#FFFFFF" />}
                      </View>
                      <AppText
                        variant="small"
                        color={on ? 'inkFaint' : 'ink'}
                        style={[styles.flex, on && styles.struck]}
                        numberOfLines={1}
                      >
                        {p.filename}
                      </AppText>
                      <AppText variant="caption" color="inkSoft">
                        {formatBytes(p.sizeBytes)}
                      </AppText>
                    </Pressable>
                  );
                })}
              </View>
            );
          })}
        </View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  top: { alignItems: 'center', gap: spacing.md, paddingTop: spacing.xl },
  icon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: colors.keepTint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: { maxWidth: 340 },
  block: { marginTop: spacing.xl, gap: spacing.sm },
  blockHead: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  account: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.md,
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  item: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.xxs },
  box: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: colors.inkFaint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  boxOn: { backgroundColor: colors.keep, borderColor: colors.keep },
  struck: { textDecorationLine: 'line-through' },
});
