/**
 * Permission state mapping. These are the platform responses expo-media-library
 * returns for each case; the device itself can't be tested here. Run with: npm test
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import { canScan, toLibraryAccess } from '@/scanning/permissions';

describe('toLibraryAccess', () => {
  it('never asked', () => {
    assert.equal(toLibraryAccess({ status: 'undetermined', granted: false, canAskAgain: true }), 'undetermined');
  });
  it('full access', () => {
    assert.equal(
      toLibraryAccess({ status: 'granted', granted: true, canAskAgain: true, accessPrivileges: 'all' }),
      'all',
    );
  });
  it('limited access (iOS 14+ "Selected photos", Android 14+ partial access)', () => {
    const r = toLibraryAccess({ status: 'granted', granted: true, canAskAgain: true, accessPrivileges: 'limited' });
    assert.equal(r, 'limited');
    assert.equal(canScan(r), true);
  });
  it('denied but can ask again', () => {
    const r = toLibraryAccess({ status: 'denied', granted: false, canAskAgain: true, accessPrivileges: 'none' });
    assert.equal(r, 'denied');
    assert.equal(canScan(r), false);
  });
  it('denied for good or restricted: only Settings can change it', () => {
    const r = toLibraryAccess({ status: 'denied', granted: false, canAskAgain: false, accessPrivileges: 'none' });
    assert.equal(r, 'blocked');
    assert.equal(canScan(r), false);
  });
});
