import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';

import { AppText, Button, ProgressBar, Screen } from '@/components';
import { scanStages } from '@/data/sampleData';
import { useScan } from '@/state/ScanContext';
import { colors, fonts, radius, spacing } from '@/theme';
import { formatCount } from '@/utils/format';

/**
 * SCANNING SCREEN (demo).
 *
 * This does NOT read any photos. A timer moves the progress bar forward so
 * we can design the experience. When the real scanner is built, it will
 * report progress to this same screen.
 */

const DEMO_DURATION_MS = 6000;
const TICK_MS = 50;
const SAMPLE_TOTAL = 4812;

export default function ScanScreen() {
  const { loadSampleResults } = useScan();
  const [progress, setProgress] = useState(0);
  const finished = useRef(false);

  useEffect(() => {
    const started = Date.now();
    const timer = setInterval(() => {
      const p = Math.min(1, (Date.now() - started) / DEMO_DURATION_MS);
      setProgress(p);
      if (p >= 1 && !finished.current) {
        finished.current = true;
        clearInterval(timer);
        // Loads sample accounts through the adapter layer, then opens the results.
        // replace() so the back button skips the finished scan screen.
        loadSampleResults().then(() => setTimeout(() => router.replace('/results'), 400));
      }
    }, TICK_MS);
    // Cleanup: stop the timer if the user leaves the screen early.
    return () => clearInterval(timer);
  }, [loadSampleResults]);

  const stageIndex = Math.min(scanStages.length - 1, Math.floor(progress * scanStages.length));
  const percent = Math.round(progress * 100);

  return (
    <Screen tone="night" edges={['top', 'bottom', 'left', 'right']} contentStyle={styles.content}>
      <View style={styles.demoNote}>
        <Feather name="info" size={14} color={colors.onNightSoft} />
        <AppText variant="caption" color="onNightSoft" style={styles.flex}>
          Demo scan. Your photo library is not being read.
        </AppText>
      </View>

      <View style={styles.center}>
        <AppText variant="small" color="onNightSoft">
          {progress < 1 ? 'Looking for duplicates' : 'Scan complete'}
        </AppText>
        <AppText style={styles.percent} color="onNight" accessibilityLiveRegion="polite">
          {percent}%
        </AppText>
        <ProgressBar progress={progress} trackColor={colors.lineNight} fillColor={colors.onNight} height={6} />
        <AppText variant="small" color="onNightSoft" style={styles.count}>
          {formatCount(Math.round(progress * SAMPLE_TOTAL))} of {formatCount(SAMPLE_TOTAL)} sample photos
        </AppText>
      </View>

      <View style={styles.stages}>
        {scanStages.map((label, i) => {
          const done = i < stageIndex || progress >= 1;
          const active = i === stageIndex && progress < 1;
          return (
            <View key={label} style={styles.stage}>
              <View style={[styles.stageDot, done && styles.stageDone]}>
                {done ? (
                  <Feather name="check" size={13} color={colors.night} />
                ) : active ? (
                  <ActivityIndicator size="small" color={colors.onNight} />
                ) : (
                  <AppText variant="caption" color="onNightSoft">
                    {i + 1}
                  </AppText>
                )}
              </View>
              <AppText variant="small" color={done || active ? 'onNight' : 'onNightSoft'} style={styles.flex}>
                {label}
              </AppText>
            </View>
          );
        })}
      </View>

      <Button label="Cancel" variant="ghost" onPress={() => router.back()} disabled={progress >= 1} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { justifyContent: 'space-between', paddingTop: spacing.md, paddingBottom: spacing.md },
  flex: { flex: 1 },
  demoNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    alignSelf: 'center',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.lineNight,
  },
  center: { gap: spacing.sm },
  percent: {
    fontFamily: fonts.displayHeavy,
    fontSize: 96,
    lineHeight: 100,
    letterSpacing: -4,
    fontVariant: ['tabular-nums'],
  },
  count: { fontVariant: ['tabular-nums'] },
  stages: {
    gap: spacing.md,
    backgroundColor: colors.nightRaised,
    borderRadius: radius.lg,
    padding: spacing.lg,
  },
  stage: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  stageDot: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: colors.lineNight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stageDone: { backgroundColor: colors.onNight, borderColor: colors.onNight },
});
