import { StatusBar } from 'expo-status-bar';
import { ReactNode } from 'react';
import { ScrollView, StyleSheet, View, ViewStyle } from 'react-native';
import { Edge, SafeAreaView } from 'react-native-safe-area-context';

import { colors, spacing } from '@/theme';

interface ScreenProps {
  children: ReactNode;
  /** 'night' = dark background (welcome, scan); 'paper' = light (everything else). */
  tone?: 'paper' | 'night';
  scroll?: boolean;
  /** Pinned to the bottom, outside the scroll area (e.g. an action bar). */
  footer?: ReactNode;
  edges?: Edge[];
  contentStyle?: ViewStyle;
}

/**
 * Wraps every screen. It handles:
 * - the background color
 * - safe areas (keeps content clear of the notch and home indicator)
 * - the status bar text color
 * - optional scrolling and a pinned footer
 */
export function Screen({
  children,
  tone = 'paper',
  scroll = false,
  footer,
  edges = ['top', 'left', 'right'],
  contentStyle,
}: ScreenProps) {
  const bg = tone === 'night' ? colors.night : colors.paper;
  const body = scroll ? (
    <ScrollView contentContainerStyle={[styles.content, contentStyle]} showsVerticalScrollIndicator={false}>
      {children}
    </ScrollView>
  ) : (
    <View style={[styles.content, styles.fill, contentStyle]}>{children}</View>
  );

  return (
    <SafeAreaView style={[styles.fill, { backgroundColor: bg }]} edges={edges}>
      <StatusBar style={tone === 'night' ? 'light' : 'dark'} />
      <View style={styles.fill}>{body}</View>
      {footer}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  content: { paddingHorizontal: spacing.lg, paddingBottom: spacing.xl, width: '100%', maxWidth: 640, alignSelf: 'center' },
});
