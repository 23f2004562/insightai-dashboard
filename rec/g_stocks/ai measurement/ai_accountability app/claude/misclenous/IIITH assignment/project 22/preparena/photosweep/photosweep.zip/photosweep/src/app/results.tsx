import { Redirect, router } from 'expo-router';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Animated, FlatList, ScrollView, StyleSheet, View } from 'react-native';

import {
  ActionBar,
  AppText,
  Button,
  Chip,
  describeAccount,
  DuplicateGroupCard,
  SampleBadge,
  Screen,
  ScreenHeader,
} from '@/components';
import { accountShortName, listAccounts, providerOrder, providers } from '@/sources';
import { splitByDeletionPolicy } from '@/state/selection';
import { useScan } from '@/state/ScanContext';
import { colors, radius, spacing } from '@/theme';
import { AccountId, MatchKind, PhotoId } from '@/types';
import { formatBytes, plural } from '@/utils/format';

/** DUPLICATE RESULTS — review each group and choose what to keep. */

type KindFilter = 'all' | MatchKind;
const kindFilters: { key: KindFilter; label: string }[] = [
  { key: 'all', label: 'All matches' },
  { key: 'exact', label: 'Exact' },
  { key: 'similar', label: 'Similar' },
];

interface Notice {
  text: string;
  key: number;
}

export default function ResultsScreen() {
  const { summary, decisions, togglePhoto, applySuggestion, applyAllSuggestions, markedPhotos, markedBytes } =
    useScan();
  const [kindFilter, setKindFilter] = useState<KindFilter>('all');
  const [accountFilter, setAccountFilter] = useState<AccountId | 'all'>('all');
  const [notice, setNotice] = useState<Notice | null>(null);
  const noticeOpacity = useRef(new Animated.Value(0)).current;

  // Message that says which account a tapped photo is in. Hides after a few seconds.
  useEffect(() => {
    if (!notice) return;
    Animated.timing(noticeOpacity, { toValue: 1, duration: 150, useNativeDriver: true }).start();
    const t = setTimeout(() => {
      Animated.timing(noticeOpacity, { toValue: 0, duration: 200, useNativeDriver: true }).start();
    }, 3200);
    return () => clearTimeout(t);
  }, [notice, noticeOpacity]);

  // Only accounts that appear in at least one group get a filter chip.
  const accountsInResults = useMemo(() => {
    if (!summary) return [];
    const used = new Set(summary.groups.flatMap((g) => g.photoIds.map((id) => summary.catalog.photos[id]?.accountId)));
    return listAccounts(summary.catalog, providerOrder).filter((a) => used.has(a.id));
  }, [summary]);

  const groups = useMemo(() => {
    if (!summary) return [];
    return summary.groups.filter(
      (g) =>
        (kindFilter === 'all' || g.kind === kindFilter) &&
        (accountFilter === 'all' || g.photoIds.some((id) => summary.catalog.photos[id]?.accountId === accountFilter)),
    );
  }, [summary, kindFilter, accountFilter]);

  if (!summary) return <Redirect href="/home" />;
  const { catalog } = summary;
  const { device, cloud } = splitByDeletionPolicy(markedPhotos);

  const handleToggle = (groupId: string, photoId: PhotoId) => {
    const result = togglePhoto(groupId, photoId);
    if (result.status === 'blocked-last-copy') {
      setNotice({ text: 'Each group keeps at least one photo. Keep another copy first.', key: Date.now() });
      return;
    }
    if (result.status === 'not-found') return;

    const account = catalog.accounts[result.photo.accountId];
    const where = describeAccount(account);
    const isCloud = providers[account.provider].kind === 'cloud';
    const text =
      result.status === 'kept'
        ? `Keeping ${result.photo.filename} in ${where}.`
        : isCloud
          ? `Marked ${result.photo.filename} in ${where}. Cloud copies are only removed by you.`
          : `Marked ${result.photo.filename} on ${where}.`;
    setNotice({ text, key: Date.now() });
  };

  const header = (
    <View style={styles.listHeader}>
      <ScreenHeader title="Duplicates" />
      <SampleBadge
        kind="banner"
        message="Sample accounts and photos for the prototype. No accounts are connected and nothing will be deleted."
      />
      <AppText variant="small" color="inkSoft" style={styles.hint}>
        Each copy shows the account it's in. Tap a photo to switch it between keep and remove.
      </AppText>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filters}>
        <Chip label="All accounts" selected={accountFilter === 'all'} onPress={() => setAccountFilter('all')} />
        {accountsInResults.map((a) => (
          <Chip
            key={a.id}
            label={accountShortName(a)}
            selected={accountFilter === a.id}
            onPress={() => setAccountFilter(a.id)}
          />
        ))}
      </ScrollView>
      <View style={styles.kindFilters}>
        {kindFilters.map((f) => (
          <Chip key={f.key} label={f.label} selected={kindFilter === f.key} onPress={() => setKindFilter(f.key)} />
        ))}
      </View>

      <Button label="Keep the best photo in every group" icon="star" variant="secondary" onPress={applyAllSuggestions} />
    </View>
  );

  const barDetail =
    markedPhotos.length === 0
      ? 'Tap photos to mark them'
      : [device.length ? `${device.length} on phone` : null, cloud.length ? `${cloud.length} in cloud` : null]
          .filter(Boolean)
          .join(', ') + `, ${formatBytes(markedBytes)}`;

  return (
    <Screen
      edges={['top', 'left', 'right']}
      contentStyle={styles.noPad}
      footer={
        <ActionBar>
          <View style={styles.barText}>
            <AppText variant="bodyStrong">
              {markedPhotos.length === 0 ? 'Nothing marked' : `${plural(markedPhotos.length, 'photo')} marked`}
            </AppText>
            <AppText variant="small" color="inkSoft" numberOfLines={1}>
              {barDetail}
            </AppText>
          </View>
          <Button
            label="Review"
            icon="list"
            variant="danger"
            disabled={markedPhotos.length === 0}
            onPress={() => router.push('/confirm')}
            accessibilityHint="Opens a summary of marked photos grouped by account. Nothing is deleted yet."
          />
        </ActionBar>
      }
    >
      <FlatList
        data={groups}
        keyExtractor={(g) => g.id}
        ListHeaderComponent={header}
        contentContainerStyle={styles.list}
        ItemSeparatorComponent={() => <View style={{ height: spacing.md }} />}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <DuplicateGroupCard
            group={item}
            catalog={catalog}
            decisions={decisions}
            onTogglePhoto={(photoId) => handleToggle(item.id, photoId)}
            onUseSuggestion={() => applySuggestion(item.id)}
          />
        )}
        ListEmptyComponent={
          <AppText variant="small" color="inkSoft" align="center">
            No matches for these filters.
          </AppText>
        }
      />

      {notice && (
        <Animated.View
          key={notice.key}
          style={[styles.notice, { opacity: noticeOpacity }]}
          pointerEvents="none"
          accessibilityLiveRegion="polite"
        >
          <AppText variant="small" color="onNight">
            {notice.text}
          </AppText>
        </Animated.View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  noPad: { paddingHorizontal: 0, paddingBottom: 0, maxWidth: undefined },
  list: { paddingHorizontal: spacing.lg, paddingBottom: spacing.xl, width: '100%', maxWidth: 640, alignSelf: 'center' },
  listHeader: { gap: spacing.md, marginBottom: spacing.md },
  hint: { marginTop: -spacing.xxs },
  filters: { gap: spacing.xs, paddingRight: spacing.lg },
  kindFilters: { flexDirection: 'row', gap: spacing.xs, marginTop: -spacing.xs },
  barText: { flex: 1 },
  notice: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    bottom: spacing.md,
    backgroundColor: colors.ink,
    padding: spacing.sm,
    borderRadius: radius.md,
  },
});
