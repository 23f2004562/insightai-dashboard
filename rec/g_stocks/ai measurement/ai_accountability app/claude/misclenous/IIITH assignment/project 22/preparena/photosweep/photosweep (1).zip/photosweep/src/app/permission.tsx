import { Feather } from '@expo/vector-icons';
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { ComponentProps, useCallback, useState } from 'react';
import { ActivityIndicator, AppState, StyleSheet, View } from 'react-native';

import { AppText, Button, Screen, ScreenHeader } from '@/components';
import { LibraryAccess } from '@/scanning/permissions';
import {
  checkLibraryAccess,
  chooseMorePhotos,
  openAppSettings,
  requestLibraryAccess,
} from '@/sources/device/permissions';
import { colors, radius, spacing } from '@/theme';

/**
 * PHOTO ACCESS — explains why before asking, and handles every answer.
 * The system prompt only appears after the user taps "Allow access to photos".
 */

const reasons: { icon: ComponentProps<typeof Feather>['name']; text: string }[] = [
  {
    icon: 'search',
    text: 'PhotoSweep reads each original file on this phone to find photos that are byte-for-byte identical.',
  },
  { icon: 'smartphone', text: 'Everything happens on this phone. Photos and their details are never uploaded.' },
  { icon: 'eye', text: 'This version only shows duplicates. It cannot delete or change any photo.' },
];

// Lets developers preview each state in a dev build: /permission?simulate=blocked
const SIMULATABLE: LibraryAccess[] = ['undetermined', 'all', 'limited', 'denied', 'blocked', 'unavailable'];

export default function PermissionScreen() {
  const { simulate } = useLocalSearchParams<{ simulate?: string }>();
  const simulated = __DEV__ && SIMULATABLE.includes(simulate as LibraryAccess) ? (simulate as LibraryAccess) : null;
  const [access, setAccess] = useState<LibraryAccess | null>(simulated);
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(() => {
    if (simulated) return;
    checkLibraryAccess()
      .then(setAccess)
      .catch(() => setAccess('unavailable'));
  }, [simulated]);

  // Re-check when the screen opens and when the user comes back from Settings.
  useFocusEffect(
    useCallback(() => {
      refresh();
      const sub = AppState.addEventListener('change', (s) => s === 'active' && refresh());
      return () => sub.remove();
    }, [refresh]),
  );

  const run = (fn: () => Promise<LibraryAccess>) => async () => {
    if (simulated) return;
    setBusy(true);
    try {
      setAccess(await fn());
    } finally {
      setBusy(false);
    }
  };

  const startScan = () =>
    router.replace({ pathname: '/device-scan', params: { limited: access === 'limited' ? '1' : '0' } });

  return (
    <Screen scroll edges={['top', 'bottom', 'left', 'right']}>
      <ScreenHeader title="Scan this phone" />

      {access === null ? (
        <ActivityIndicator color={colors.ink} style={styles.loading} />
      ) : (
        <>
          <StatusCard access={access} />

          {(access === 'undetermined' || access === 'denied') && (
            <View style={styles.reasons}>
              {reasons.map((r) => (
                <View key={r.icon} style={styles.reason}>
                  <Feather name={r.icon} size={18} color={colors.inkSoft} style={styles.reasonIcon} />
                  <AppText variant="small" color="inkSoft" style={styles.flex}>
                    {r.text}
                  </AppText>
                </View>
              ))}
            </View>
          )}

          <View style={styles.actions}>
            {access === 'undetermined' && (
              <Button
                label="Allow access to photos"
                icon="unlock"
                size="lg"
                onPress={run(requestLibraryAccess)}
                disabled={busy}
              />
            )}
            {access === 'denied' && (
              <Button label="Ask again" icon="unlock" size="lg" onPress={run(requestLibraryAccess)} disabled={busy} />
            )}
            {access === 'blocked' && (
              <Button label="Open Settings" icon="settings" size="lg" onPress={() => openAppSettings()} />
            )}
            {access === 'all' && <Button label="Start scan" icon="search" size="lg" onPress={startScan} />}
            {access === 'limited' && (
              <>
                <Button label="Scan selected photos" icon="search" size="lg" onPress={startScan} />
                <Button
                  label="Choose more photos"
                  variant="secondary"
                  onPress={run(chooseMorePhotos)}
                  disabled={busy}
                />
              </>
            )}
            {access !== 'all' && access !== 'limited' && (
              <Button
                label="Use the sample demo instead"
                variant="ghost"
                onPress={() => router.replace({ pathname: '/scan' })}
              />
            )}
            <Button label="Not now" variant="ghost" onPress={() => router.back()} />
          </View>
        </>
      )}
    </Screen>
  );
}

const statusCopy: Record<
  LibraryAccess,
  { icon: ComponentProps<typeof Feather>['name']; title: string; body: string; tone: 'neutral' | 'good' | 'warn' }
> = {
  undetermined: {
    icon: 'image',
    title: 'PhotoSweep needs to see your photos',
    body: 'Your phone will ask for permission. If it offers a choice, pick full access to check your whole library, or choose specific photos to try it on a few.',
    tone: 'neutral',
  },
  all: {
    icon: 'check-circle',
    title: 'Access to all photos',
    body: 'PhotoSweep can check your whole photo library.',
    tone: 'good',
  },
  limited: {
    icon: 'grid',
    title: 'Access to selected photos only',
    body: "Only the photos you chose will be checked, so duplicates of other photos won't be found. You can add more photos or change this in Settings.",
    tone: 'warn',
  },
  denied: {
    icon: 'lock',
    title: 'Photo access was declined',
    body: "PhotoSweep can't scan without access. You can ask again, or keep exploring with the sample demo.",
    tone: 'warn',
  },
  blocked: {
    icon: 'lock',
    title: 'Photo access is turned off',
    body: "Your phone won't show the request again. This can also happen if access is restricted, for example by parental controls. Turn on photo access for PhotoSweep in Settings, then come back.",
    tone: 'warn',
  },
  unavailable: {
    icon: 'monitor',
    title: 'Not available here',
    body: 'Scanning a photo library works in the iOS and Android app. On the web, use the sample demo.',
    tone: 'neutral',
  },
};

function StatusCard({ access }: { access: LibraryAccess }) {
  const c = statusCopy[access];
  const tint = c.tone === 'good' ? colors.keepTint : c.tone === 'warn' ? colors.sampleTint : colors.card;
  const iconColor = c.tone === 'good' ? colors.keep : c.tone === 'warn' ? colors.sample : colors.ink;
  return (
    <View style={[styles.card, { backgroundColor: tint }]} accessibilityLiveRegion="polite">
      <Feather name={c.icon} size={22} color={iconColor} />
      <AppText variant="heading">{c.title}</AppText>
      <AppText variant="body" color="inkSoft">
        {c.body}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  loading: { marginTop: spacing.xxl },
  card: {
    gap: spacing.sm,
    padding: spacing.lg,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  reasons: { gap: spacing.md, marginTop: spacing.lg },
  reason: { flexDirection: 'row', gap: spacing.sm },
  reasonIcon: { marginTop: 1 },
  actions: { gap: spacing.sm, marginTop: spacing.xl },
});
