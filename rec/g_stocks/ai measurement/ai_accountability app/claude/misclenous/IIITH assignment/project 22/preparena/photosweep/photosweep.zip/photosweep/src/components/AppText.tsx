import { StyleSheet, Text, TextProps } from 'react-native';

import { ColorName, colors, TextVariant, textVariants } from '@/theme';

interface AppTextProps extends TextProps {
  variant?: TextVariant;
  color?: ColorName;
  align?: 'left' | 'center' | 'right';
}

/**
 * The only text component screens should use.
 * <AppText variant="title" color="ink">Hello</AppText>
 * Centralising text means fonts and sizes stay consistent across the app.
 */
export function AppText({ variant = 'body', color = 'ink', align, style, ...rest }: AppTextProps) {
  return (
    <Text
      style={[textVariants[variant], { color: colors[color] }, align && { textAlign: align }, styles.base, style]}
      {...rest}
    />
  );
}

const styles = StyleSheet.create({
  // Stops Android adding extra space above text set in custom fonts.
  base: { includeFontPadding: false },
});
