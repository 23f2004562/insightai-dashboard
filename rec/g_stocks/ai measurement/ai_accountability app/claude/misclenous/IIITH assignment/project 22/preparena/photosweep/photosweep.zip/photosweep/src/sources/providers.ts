import { Feather } from '@expo/vector-icons';
import { ComponentProps } from 'react';

import { DeletionPolicy, ProviderId } from '@/types';

/**
 * PROVIDER REGISTRY — facts about each kind of photo source.
 *
 * Screens look up labels, icons and deletion rules here instead of
 * hard-coding them. Adding a provider = add it to ProviderId in src/types
 * and add one entry below.
 */
export interface ProviderInfo {
  id: ProviderId;
  label: string;
  icon: ComponentProps<typeof Feather>['name'];
  kind: 'device' | 'cloud';
  /** Cloud providers are always 'manual': PhotoSweep never deletes them automatically. */
  deletionPolicy: DeletionPolicy;
  /** How we plan to connect it. Shown nowhere yet; it's a note for developers. */
  plannedIntegration: string;
}

export const providers: Record<ProviderId, ProviderInfo> = {
  device: {
    id: 'device',
    label: 'Phone',
    icon: 'smartphone',
    kind: 'device',
    deletionPolicy: 'system-dialog',
    plannedIntegration:
      'expo-media-library: Android MediaStore and iOS PHPhotoLibrary. Deletion goes through the system confirmation dialog.',
  },
  google_photos: {
    id: 'google_photos',
    label: 'Google Photos',
    icon: 'image',
    kind: 'cloud',
    deletionPolicy: 'manual',
    plannedIntegration:
      'Google Photos Picker API: the user picks which photos to share. No Google Photos API deletes from a user library.',
  },
  icloud: {
    id: 'icloud',
    label: 'iCloud Photos',
    icon: 'cloud',
    kind: 'cloud',
    deletionPolicy: 'manual',
    plannedIntegration:
      'No public iCloud Photos API. On iPhone, iCloud photos appear through PHPhotoLibrary with cloud metadata.',
  },
  onedrive: {
    id: 'onedrive',
    label: 'OneDrive',
    icon: 'hard-drive',
    kind: 'cloud',
    deletionPolicy: 'manual',
    plannedIntegration: 'Microsoft Graph API (Camera Roll folder). Kept manual for safety.',
  },
};

/** Display order on the dashboard. */
export const providerOrder: ProviderId[] = ['device', 'google_photos', 'icloud', 'onedrive'];
