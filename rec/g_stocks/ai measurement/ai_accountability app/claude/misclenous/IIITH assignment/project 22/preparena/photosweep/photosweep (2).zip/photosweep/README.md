# PhotoSweep

Finds duplicate and look-alike photos across your photo libraries and helps you clean them up safely.

**Milestone 1: UI prototype.** Every screen and the full navigation flow are built, using sample data.

| Built in this milestone | Not built yet (on purpose) |
| --- | --- |
| Welcome, dashboard, scan, results, confirm and outcome screens | Photo library permissions |
| Keep / delete selection with a "keep at least one copy" rule | Real scanning or duplicate detection |
| Confirmation step before any deletion | Real deletion |
| Clearly labelled sample data | Google sign-in, uploads, servers |

## Run it

You need [Node.js](https://nodejs.org) (version 20 or newer) and the **Expo Go** app on your phone (App Store or Google Play).

```bash
cd photosweep
npm install        # first time only: downloads the libraries
npx expo start     # starts the development server
```

A QR code appears in the terminal.

- **iPhone:** scan it with the Camera app.
- **Android:** scan it from inside Expo Go.

Your phone and computer must be on the same Wi-Fi network. Edits you save on your computer reload instantly on the phone.

Other ways to run:

- `npx expo start --web`: opens the app in a browser (handy for quick checks)
- press `i` or `a` in the terminal: opens an iOS Simulator (Mac only) or Android emulator, if installed

The sample thumbnails load from picsum.photos, so the phone needs an internet connection. Nothing is ever uploaded.

## Checks

```bash
npm run typecheck   # TypeScript: catches type errors
npx expo-doctor     # checks package versions and config
```

## Project layout

```
src/
  app/                  SCREENS. Each file is a route (Expo Router).
    _layout.tsx         Root: loads fonts, shared state, the navigation stack
    index.tsx           Welcome
    home.tsx            Dashboard (stats + Scan photos button)
    scan.tsx            Demo scan with progress
    results.tsx         Duplicate groups, keep/delete selection
    confirm.tsx         Review before deletion (modal)
    done.tsx            Outcome ("nothing was deleted")
  components/           Reusable building blocks (Button, PhotoThumb, …)
  state/
    ScanContext.tsx     Shared state: results + the user's choices
    selection.ts        Pure helper functions (safety rule lives here)
  data/sampleData.ts    SAMPLE photos and groups (not real results)
  theme/                Colors, spacing, typography: the whole look in one place
  types/index.ts        TypeScript shapes for photos, groups, scan results
  utils/format.ts       File size / number / date formatting
```

## Key decisions

- **Expo Router** for navigation: each file in `src/app` is a screen.
- **React Context** for shared state, with no extra library. Enough for now; easy to replace later.
- **One theme folder** instead of a UI kit, so the design is custom and easy to change.
- **Honest demo mode:** `ScanSummary.source` is `'sample'`, and the UI shows a "Sample data" label wherever sample results appear.
- **Safety first:** photos default to *keep*. A group can never have all its photos marked for deletion. Deleting needs a review screen plus a checkbox.

## Next milestones (suggested)

1. Ask for photo library permission (`expo-media-library`) and list real photos.
2. Fingerprint photos on the device and group real duplicates.
3. Real deletion through the system's own delete dialog (photos go to Recently Deleted).
4. Google Photos sign-in.
