/**
 * Catalog validation tests. Run with: npm test
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import { PhotoSourceAdapter } from '@/sources/adapter';
import { buildCatalog, CancelledError, CatalogValidationError } from '@/sources/catalog';
import { makeAccountId, makePhotoId } from '@/sources/ids';
import { sampleAdapter } from '@/sources/sample/sampleAdapter';
import { Photo, SourceAccount } from '@/types';

const ACC = makeAccountId('google_photos', 'acct-a');

function account(over: Partial<SourceAccount> = {}): SourceAccount {
  return {
    id: ACC,
    provider: 'google_photos',
    providerAccountId: 'acct-a',
    displayName: 'A',
    connection: 'sample',
    ...over,
  };
}

function photo(providerPhotoId: string, over: Partial<Photo> = {}): Photo {
  return {
    id: makePhotoId(ACC, providerPhotoId),
    accountId: ACC,
    provider: 'google_photos',
    providerPhotoId,
    uri: 'x',
    filename: `${providerPhotoId}.jpg`,
    createdAt: '2026-01-01T00:00:00.000Z',
    width: 1,
    height: 1,
    hash: { status: 'pending' },
    ...over,
  };
}

/** Builds a fake adapter from a list of accounts and a page function. */
function fakeAdapter(
  accounts: SourceAccount[],
  pages: (accountId: string, cursor?: string) => { photos: Photo[]; nextCursor?: string },
): PhotoSourceAdapter {
  return {
    id: 'fake',
    providers: ['google_photos', 'device'],
    isAvailable: () => true,
    listAccounts: async () => accounts,
    listPhotos: async (a, c) => pages(a, c),
  };
}

async function rejectsWith(promise: Promise<unknown>, code: CatalogValidationError['code']) {
  await assert.rejects(promise, (e: unknown) => {
    assert.ok(e instanceof CatalogValidationError, `expected CatalogValidationError, got ${e}`);
    assert.equal(e.code, code);
    return true;
  });
}

describe('buildCatalog', () => {
  it('builds the sample catalog with every photo in its account collection', async () => {
    const c = await buildCatalog([sampleAdapter]);
    assert.equal(Object.keys(c.accounts).length, 6);
    const inCollections = Object.values(c.collections).flat();
    assert.equal(inCollections.length, Object.keys(c.photos).length);
  });

  it('pages through multiple pages', async () => {
    const all = [photo('1'), photo('2'), photo('3')];
    const c = await buildCatalog([
      fakeAdapter([account()], (_a, cur) => {
        const i = Number(cur ?? 0);
        return { photos: [all[i]], nextCursor: i < 2 ? String(i + 1) : undefined };
      }),
    ]);
    assert.deepEqual(
      c.collections[ACC],
      all.map((p) => p.id),
    );
  });

  it('rejects duplicate account IDs', async () => {
    await rejectsWith(buildCatalog([fakeAdapter([account(), account()], () => ({ photos: [] }))]), 'duplicate-account');
  });

  it('rejects an account whose ID does not match provider + provider account ID', async () => {
    await rejectsWith(
      buildCatalog([fakeAdapter([account({ id: 'google_photos:other' })], () => ({ photos: [] }))]),
      'inconsistent-account-id',
    );
  });

  it('rejects duplicate photo IDs instead of overwriting', async () => {
    await rejectsWith(
      buildCatalog([fakeAdapter([account()], () => ({ photos: [photo('1'), photo('1')] }))]),
      'duplicate-photo',
    );
  });

  it('rejects a photo whose account does not exist', async () => {
    const ghost = makeAccountId('google_photos', 'ghost');
    await rejectsWith(
      buildCatalog([
        fakeAdapter([account()], () => ({
          photos: [photo('1', { accountId: ghost, id: makePhotoId(ghost, '1') })],
        })),
      ]),
      'unknown-account',
    );
  });

  it('rejects a photo listed under a different (existing) account', async () => {
    const B = makeAccountId('google_photos', 'acct-b');
    const accounts = [account(), account({ id: B, providerAccountId: 'acct-b' })];
    await rejectsWith(
      buildCatalog([fakeAdapter(accounts, (a) => (a === ACC ? { photos: [] } : { photos: [photo('1')] }))]),
      'wrong-account',
    );
  });

  it('rejects a photo whose provider differs from its account', async () => {
    await rejectsWith(
      buildCatalog([fakeAdapter([account()], () => ({ photos: [photo('1', { provider: 'device' })] }))]),
      'provider-mismatch',
    );
  });

  it('rejects a photo ID that does not match account ID + provider photo ID', async () => {
    await rejectsWith(
      buildCatalog([fakeAdapter([account()], () => ({ photos: [photo('1', { id: `${ACC}/2` })] }))]),
      'inconsistent-photo-id',
    );
  });

  it('stops on a repeated cursor instead of looping forever', async () => {
    let n = 0;
    await rejectsWith(
      buildCatalog([fakeAdapter([account()], () => ({ photos: [photo(String(n++))], nextCursor: 'same' }))]),
      'repeated-cursor',
    );
  });

  it('stops an adapter that never runs out of pages', async () => {
    let n = 0;
    await rejectsWith(
      buildCatalog([fakeAdapter([account()], () => ({ photos: [], nextCursor: `c${n++}` }))], {
        maxPagesPerAccount: 50,
      }),
      'too-many-pages',
    );
  });

  it('can be cancelled between pages', async () => {
    const signal = { aborted: false };
    let calls = 0;
    await assert.rejects(
      buildCatalog(
        [
          fakeAdapter([account()], () => {
            calls += 1;
            signal.aborted = true;
            return { photos: [photo(String(calls))], nextCursor: `c${calls}` };
          }),
        ],
        { signal },
      ),
      CancelledError,
    );
    assert.equal(calls, 1);
  });
});
