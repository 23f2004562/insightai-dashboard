# PhotoSweep

Finds duplicate and look-alike photos across your photo libraries and helps you clean them up safely.

**Milestone 2: account-aware prototype.** Every screen and the full navigation flow are built. Every photo knows which account it lives in, across multiple accounts per provider. All accounts and photos are sample data.

| Built in this milestone | Not built yet (on purpose) |
| --- | --- |
| Welcome, dashboard, scan, results, confirm and outcome screens | Photo library permissions |
| Keep / delete selection with a "keep at least one copy" rule | Real scanning or duplicate detection |
| Confirmation step before any deletion | Real deletion |
| Clearly labelled sample data | Google sign-in, uploads, servers |

## Run it

You need [Node.js](https://nodejs.org) (version 20 or newer) and the **Expo Go** app on your phone (App Store or Google Play).

```bash
cd photosweep
npm install        # first time only: downloads the libraries
npx expo start     # starts the development server
```

A QR code appears in the terminal.

- **iPhone:** scan it with the Camera app.
- **Android:** scan it from inside Expo Go.

Your phone and computer must be on the same Wi-Fi network. Edits you save on your computer reload instantly on the phone.

Other ways to run:

- `npx expo start --web`: opens the app in a browser (handy for quick checks)
- press `i` or `a` in the terminal: opens an iOS Simulator (Mac only) or Android emulator, if installed

The sample thumbnails load from picsum.photos, so the phone needs an internet connection. Nothing is ever uploaded.

## Checks

```bash
npm run typecheck   # TypeScript: catches type errors
npx expo-doctor     # checks package versions and config
```

## Project layout

```
src/
  app/                  SCREENS. Each file is a route (Expo Router).
    _layout.tsx         Root: loads fonts, shared state, the navigation stack
    index.tsx           Welcome
    home.tsx            Dashboard (stats + Scan photos button)
    scan.tsx            Demo scan with progress
    results.tsx         Duplicate groups, keep/delete selection
    confirm.tsx         Review before deletion (modal)
    done.tsx            Outcome ("nothing was deleted")
  components/           Reusable building blocks (Button, PhotoThumb, AccountBadge, …)
  sources/              WHERE PHOTOS COME FROM
    adapter.ts          The interface every photo source implements
    providers.ts        Facts per provider: label, icon, deletion policy
    catalog.ts          Builds the catalog from adapters; resolvePhotoSource()
    ids.ts              Globally unique account and photo IDs
    sample/             The only adapter so far: sample accounts and photos
  state/
    ScanContext.tsx     Shared state: results + the user's choices
    selection.ts        Pure helper functions (safety rule lives here)
  data/sampleData.ts    SAMPLE accounts, photos and groups (not real)
  theme/                Colors, spacing, typography: the whole look in one place
  types/index.ts        TypeScript shapes for photos, groups, scan results
  utils/format.ts       File size / number / date formatting
```

## Data model

```
Provider (google_photos)
  └─ SourceAccount   id "google_photos:acct-work", displayName, email?
       └─ Photo      id "google_photos:acct-work/AF1Qip…", accountId,
                     sizeBytes, width, height, createdAt,
                     hashes { content (SHA-256), perceptual (dHash) }
```

- Any number of accounts per provider. Each has its own photo collection in `PhotoCatalog.collections`.
- Account name and email are stored once, on the account. `resolvePhotoSource(photo, catalog)` returns a photo's provider, account ID, display name, email and a safe label.
- `email` is optional: it is only present when shared and authorized. The UI falls back to "OneDrive (Backup)" style labels.
- Duplicate groups store photo IDs. Exact = same content hash; similar = close perceptual hash.

### Adding a real photo source

1. Create a file in `src/sources/` that implements `PhotoSourceAdapter`.
2. Add it to `activeAdapters` in `src/sources/index.ts`.

The screens don't change.

### Cloud photos are never deleted by PhotoSweep

Each provider has a `deletionPolicy`:

- **Phone:** `system-dialog`. Later, removal will go through the phone's own confirmation.
- **Google Photos, iCloud, OneDrive:** `manual`. PhotoSweep produces a per-account checklist and the user removes those copies in each service's own app.

## Key decisions

- **Expo Router** for navigation: each file in `src/app` is a screen.
- **React Context** for shared state, with no extra library. Enough for now; easy to replace later.
- **One theme folder** instead of a UI kit, so the design is custom and easy to change.
- **Honest demo mode:** `ScanSummary.source` is `'sample'`, and the UI shows a "Sample data" label wherever sample results appear.
- **Safety first:** photos default to *keep*. A group can never have all its photos marked for deletion. Deleting needs a review screen plus a checkbox.

## Next milestones (suggested)

1. A device adapter using `expo-media-library` (Android gallery and iOS Photos), behind a permission prompt.
2. Real content and perceptual hashing on the device, and real duplicate grouping.
3. Phone deletion through the system's own delete dialog (photos go to Recently Deleted).
4. A Google Photos Picker adapter (users choose which photos to share).
