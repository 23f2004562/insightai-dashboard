import { providers } from '@/sources/providers';
import { AccountId, DuplicateGroup, Photo, PhotoCatalog, PhotoDecision, PhotoId } from '@/types';

/**
 * Pure helper functions for the keep/delete selection.
 * "Pure" = they only read their inputs and return a result, which makes
 * them easy to reason about and test.
 */

export type Decisions = Record<PhotoId, PhotoDecision>;

/** Photos with no decision yet are treated as "keep". This is the safe default. */
export function decisionFor(decisions: Decisions, photoId: PhotoId): PhotoDecision {
  return decisions[photoId] ?? 'keep';
}

export function keptInGroup(group: DuplicateGroup, decisions: Decisions): PhotoId[] {
  return group.photoIds.filter((id) => decisionFor(decisions, id) === 'keep');
}

/**
 * SAFETY RULE: every group must keep at least one photo.
 * Returns true if marking this photo would remove the last kept copy.
 */
export function wouldDeleteLastCopy(group: DuplicateGroup, decisions: Decisions, photoId: PhotoId): boolean {
  const kept = keptInGroup(group, decisions);
  return kept.length === 1 && kept[0] === photoId;
}

/** Keep the suggested photo, mark the rest. */
export function suggestedDecisions(group: DuplicateGroup): Decisions {
  const result: Decisions = {};
  for (const id of group.photoIds) result[id] = id === group.suggestedKeepId ? 'keep' : 'delete';
  return result;
}

export function markedForDeletion(groups: DuplicateGroup[], catalog: PhotoCatalog, decisions: Decisions): Photo[] {
  return groups
    .flatMap((g) => g.photoIds)
    .filter((id) => decisionFor(decisions, id) === 'delete')
    .map((id) => catalog.photos[id])
    .filter((p): p is Photo => Boolean(p));
}

export function totalBytes(photos: Photo[]): number {
  // Unknown sizes count as 0 so totals never overstate savings.
  return photos.reduce((sum, p) => sum + (p.sizeBytes ?? 0), 0);
}

/** Storage freed if the user accepted every suggestion (device and cloud combined). */
export function potentialSavings(groups: DuplicateGroup[], catalog: PhotoCatalog): number {
  return groups.reduce(
    (sum, g) =>
      sum +
      totalBytes(g.photoIds.filter((id) => id !== g.suggestedKeepId).map((id) => catalog.photos[id]).filter(Boolean)),
    0,
  );
}

/**
 * Splits marked photos by how they may be removed:
 * - device: can later go through the phone's own delete dialog
 * - cloud:  PhotoSweep never deletes these; the user removes them manually
 */
export function splitByDeletionPolicy(photos: Photo[]): { device: Photo[]; cloud: Photo[] } {
  const device: Photo[] = [];
  const cloud: Photo[] = [];
  for (const p of photos) (providers[p.provider].deletionPolicy === 'system-dialog' ? device : cloud).push(p);
  return { device, cloud };
}

/** Groups photos by the account that contains them, keeping first-seen order. */
export function groupByAccount(photos: Photo[]): { accountId: AccountId; photos: Photo[] }[] {
  const map = new Map<AccountId, Photo[]>();
  for (const p of photos) map.set(p.accountId, [...(map.get(p.accountId) ?? []), p]);
  return [...map.entries()].map(([accountId, list]) => ({ accountId, photos: list }));
}
