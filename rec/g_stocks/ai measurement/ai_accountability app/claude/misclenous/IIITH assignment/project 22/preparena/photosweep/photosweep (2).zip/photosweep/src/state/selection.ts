import { DuplicateGroup, Photo, PhotoDecision } from '@/types';

/**
 * Pure helper functions for the keep/delete selection.
 *
 * "Pure" means they only read their inputs and return a result — no state,
 * no side effects. That makes them easy to understand and easy to test.
 */

export type Decisions = Record<string, PhotoDecision>;

/** Photos with no decision yet are treated as "keep". This is the safe default. */
export function decisionFor(decisions: Decisions, photoId: string): PhotoDecision {
  return decisions[photoId] ?? 'keep';
}

export function keptInGroup(group: DuplicateGroup, decisions: Decisions): Photo[] {
  return group.photos.filter((p) => decisionFor(decisions, p.id) === 'keep');
}

/**
 * SAFETY RULE: every group must keep at least one photo.
 * Returns true if marking this photo for deletion would remove the last copy.
 */
export function wouldDeleteLastCopy(
  group: DuplicateGroup,
  decisions: Decisions,
  photoId: string,
): boolean {
  const kept = keptInGroup(group, decisions);
  return kept.length === 1 && kept[0].id === photoId;
}

/** The decisions that follow our suggestion: keep the suggested photo, delete the rest. */
export function suggestedDecisions(group: DuplicateGroup): Decisions {
  const result: Decisions = {};
  for (const p of group.photos) {
    result[p.id] = p.id === group.suggestedKeepId ? 'keep' : 'delete';
  }
  return result;
}

export function markedForDeletion(groups: DuplicateGroup[], decisions: Decisions): Photo[] {
  return groups.flatMap((g) => g.photos.filter((p) => decisionFor(decisions, p.id) === 'delete'));
}

export function totalBytes(photos: Photo[]): number {
  return photos.reduce((sum, p) => sum + p.sizeBytes, 0);
}

/** Storage freed if the user accepted every suggestion. Shown on the dashboard. */
export function potentialSavings(groups: DuplicateGroup[]): number {
  return groups.reduce(
    (sum, g) => sum + totalBytes(g.photos.filter((p) => p.id !== g.suggestedKeepId)),
    0,
  );
}
