import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Pressable, StyleSheet, View } from 'react-native';

import { AccountBadge, AppText, Button, SampleBadge, Screen, StatFigure } from '@/components';
import { getPhotos, listAccounts, providerOrder, providers } from '@/sources';
import { potentialSavings, splitByDeletionPolicy, totalBytes } from '@/state/selection';
import { useScan } from '@/state/ScanContext';
import { colors, radius, spacing } from '@/theme';
import { ProviderId } from '@/types';
import { formatBytes, formatCount, plural } from '@/utils/format';

/** HOME DASHBOARD */

// Honest status for each provider before any (demo) scan: nothing is connected.
const notConnectedStatus: Record<ProviderId, string> = {
  device: 'Access not requested yet',
  google_photos: 'Sign-in coming in a later version',
  icloud: 'Coming in a later version',
  onedrive: 'Sign-in coming in a later version',
};

export default function HomeScreen() {
  const { summary, markedPhotos } = useScan();

  const savings = summary ? potentialSavings(summary.groups, summary.catalog) : 0;
  const duplicatePhotos = summary ? summary.groups.reduce((n, g) => n + g.photoIds.length, 0) : 0;

  // Split the suggested savings into phone vs cloud, so the user sees where space would come from.
  const suggestedRemovals = summary
    ? summary.groups.flatMap((g) => getPhotos(summary.catalog, g.photoIds.filter((id) => id !== g.suggestedKeepId)))
    : [];
  const split = splitByDeletionPolicy(suggestedRemovals);
  const accounts = summary ? listAccounts(summary.catalog, providerOrder) : [];

  return (
    <Screen scroll>
      <View style={styles.header}>
        <AppText variant="title">Library overview</AppText>
        {summary && <SampleBadge />}
      </View>

      <View style={styles.panel}>
        {summary ? (
          <>
            <StatFigure size="large" color="keep" value={formatBytes(savings)} label="Potential storage savings" />
            <AppText variant="small" color="inkSoft" style={styles.splitLine}>
              {formatBytes(totalBytes(split.device))} on this phone, {formatBytes(totalBytes(split.cloud))} in cloud
              accounts
            </AppText>
            <View style={styles.divider} />
            <View style={styles.row}>
              <StatFigure value={formatCount(summary.totalPhotosScanned)} label="Photos scanned" />
              <View style={styles.vDivider} />
              <StatFigure value={formatCount(summary.groups.length)} label="Duplicate groups" />
            </View>
          </>
        ) : (
          <View style={styles.empty}>
            <AppText variant="heading">No scan yet</AppText>
            <AppText variant="small" color="inkSoft">
              Run a scan to see how many duplicates you have and how much space you could free up. In this prototype, the
              scan is a demo that uses sample accounts and photos.
            </AppText>
            <View style={styles.row}>
              <StatFigure value="–" label="Photos scanned" />
              <View style={styles.vDivider} />
              <StatFigure value="–" label="Duplicate groups" />
            </View>
          </View>
        )}
      </View>

      <Button
        label={summary ? 'Scan again' : 'Scan photos'}
        icon="search"
        size="lg"
        onPress={() => router.push('/scan')}
        accessibilityHint="Runs a demo scan with sample accounts and photos"
        style={styles.scanButton}
      />

      {summary && (
        <Pressable
          onPress={() => router.push('/results')}
          style={({ pressed }) => [styles.resultsLink, pressed && { backgroundColor: colors.sunken }]}
          accessibilityRole="button"
        >
          <View style={styles.flex}>
            <AppText variant="bodyStrong">Review duplicates</AppText>
            <AppText variant="small" color="inkSoft">
              {plural(duplicatePhotos, 'photo')} in {plural(summary.groups.length, 'group')}
              {markedPhotos.length > 0 ? `, ${markedPhotos.length} marked` : ''}
            </AppText>
          </View>
          <Feather name="chevron-right" size={22} color={colors.inkFaint} />
        </Pressable>
      )}

      <AppText variant="heading" style={styles.sectionTitle}>
        Accounts
      </AppText>

      {summary ? (
        <View style={styles.list}>
          {accounts.map((a, i) => (
            <View key={a.id} style={[styles.listRow, i > 0 && styles.rowBorder]}>
              <AccountBadge account={a} variant="full" />
              {a.totalPhotos !== undefined && (
                <AppText variant="small" color="inkSoft">
                  {plural(a.totalPhotos, 'photo')}
                </AppText>
              )}
            </View>
          ))}
        </View>
      ) : (
        <View style={styles.list}>
          {providerOrder.map((id, i) => (
            <View key={id} style={[styles.listRow, i > 0 && styles.rowBorder]}>
              <View style={styles.libIcon}>
                <Feather name={providers[id].icon} size={17} color={colors.inkSoft} />
              </View>
              <View style={styles.flex}>
                <AppText variant="bodyStrong">{providers[id].label}</AppText>
                <AppText variant="small" color="inkFaint">
                  {notConnectedStatus[id]}
                </AppText>
              </View>
            </View>
          ))}
        </View>
      )}
      <AppText variant="caption" color="inkFaint" style={styles.footnote}>
        You'll be able to add several accounts from the same service, such as a personal and a work Google account.
      </AppText>
    </Screen>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, gap: 2 },
  header: { paddingTop: spacing.lg, paddingBottom: spacing.lg, gap: spacing.xs },
  panel: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.lg,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  splitLine: { marginTop: spacing.xs },
  divider: { height: StyleSheet.hairlineWidth * 2, backgroundColor: colors.line, marginVertical: spacing.lg },
  row: { flexDirection: 'row', alignItems: 'stretch', gap: spacing.lg },
  vDivider: { width: StyleSheet.hairlineWidth * 2, backgroundColor: colors.line },
  empty: { gap: spacing.md },
  scanButton: { marginTop: spacing.lg },
  resultsLink: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.md,
  },
  sectionTitle: { marginTop: spacing.xl, marginBottom: spacing.sm },
  list: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  listRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, padding: spacing.md },
  rowBorder: { borderTopWidth: StyleSheet.hairlineWidth * 2, borderTopColor: colors.line },
  libIcon: {
    width: 36,
    height: 36,
    borderRadius: radius.md,
    backgroundColor: colors.paper,
    alignItems: 'center',
    justifyContent: 'center',
  },
  footnote: { marginTop: spacing.sm },
});
