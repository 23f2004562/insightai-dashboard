import { File } from 'expo-file-system';
import { Asset, AssetField, AssetMetadata, MediaType, Query } from 'expo-media-library';
import { Platform } from 'react-native';

import { AccountId, Photo, SourceAccount } from '@/types';
import { HashOriginalResult, OriginalSizeResult, PhotoPage, PhotoSourceAdapter } from '../adapter';
import { makeAccountId, makePhotoId } from '../ids';

/**
 * DEVICE PHOTO LIBRARY ADAPTER (iOS Photos / Android gallery)
 *
 * Uses the SDK 58 class-based expo-media-library API (not the legacy one).
 * - Listing uses Query.exeForMetadata(): IDs, filenames, dimensions and dates
 *   only, read cheaply in pages. No files are opened while listing.
 * - Asset IDs are kept exactly as the platform gives them:
 *   iOS "ph://<localIdentifier>", Android "content://media/...".
 *   expo-image can draw thumbnails straight from these IDs.
 * - Sizes and hashes come from the full original file via expo-file-system.
 *
 * ONE ACCOUNT ONLY. On iPhone, iCloud Photos are part of this same library,
 * so there is deliberately no separate iCloud account: photos would be
 * counted twice. Cloud-only originals are flagged with availability instead.
 *
 * Nothing here deletes anything, and nothing is sent anywhere.
 */

const PROVIDER_ACCOUNT_ID = 'this-device';
export const DEVICE_ACCOUNT_ID: AccountId = makeAccountId('device', PROVIDER_ACCOUNT_ID);
const PAGE_SIZE = 200;

function deviceLabel(): string {
  if (Platform.OS === 'ios') return Platform.isPad ? 'Photos on this iPad' : 'Photos on this iPhone';
  return 'Gallery on this phone';
}

function toIso(ms: number | null): string {
  // Some files have no recorded date; the epoch marks "unknown" and sorts last-first consistently.
  return new Date(ms ?? 0).toISOString();
}

function errorMessage(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

/** A fresh adapter per scan, so cached file locations never outlive the scan. */
export function createDeviceAdapter(): PhotoSourceAdapter {
  // Where each photo's original file lives, found during the size check and reused for hashing.
  const originalUris = new Map<string, string>();
  // Offset paging can repeat an item if the library changes mid-scan; skip repeats here.
  const seen = new Set<string>();

  function toPhoto(m: AssetMetadata): Photo {
    return {
      id: makePhotoId(DEVICE_ACCOUNT_ID, m.id),
      accountId: DEVICE_ACCOUNT_ID,
      provider: 'device',
      providerPhotoId: m.id,
      uri: m.id,
      filename: m.filename ?? 'Untitled',
      createdAt: toIso(m.creationTime ?? m.modificationTime),
      width: m.width ?? 0,
      height: m.height ?? 0,
      hash: { status: 'pending' },
    };
  }

  /** Finds the original file without downloading it. Returns null + reason if it can't. */
  async function resolveOriginal(photo: Photo): Promise<OriginalSizeResult & { uri?: string }> {
    const asset = new Asset(photo.providerPhotoId);
    if (Platform.OS === 'ios') {
      // getUri() would download an iCloud-only original, so check first and skip those.
      if (await asset.getIsInCloud()) {
        return { ok: false, reason: 'cloud-only', availability: 'cloud-only' };
      }
    }
    const uri = await asset.getUri(); // current version; for unedited photos this is the original
    const file = new File(uri);
    if (!file.exists) {
      return { ok: false, reason: 'unreadable', message: 'File not found', availability: 'unknown' };
    }
    return { ok: true, size: file.size, availability: 'local', uri };
  }

  return {
    id: 'device-media-library',
    providers: ['device'],

    isAvailable: () => Platform.OS === 'ios' || Platform.OS === 'android',

    async listAccounts(): Promise<SourceAccount[]> {
      return [
        {
          id: DEVICE_ACCOUNT_ID,
          provider: 'device',
          providerAccountId: PROVIDER_ACCOUNT_ID,
          displayName: deviceLabel(),
          connection: 'connected',
          // No email: a device library has none, and we never invent one.
        },
      ];
    },

    async listPhotos(accountId: AccountId, cursor?: string): Promise<PhotoPage> {
      if (accountId !== DEVICE_ACCOUNT_ID) return { photos: [] };
      const offset = cursor ? Number(cursor) : 0;
      if (offset === 0) seen.clear();

      // Oldest first, so photos taken during the scan are added at the end instead of shifting pages.
      const items = await new Query()
        .eq(AssetField.MEDIA_TYPE, MediaType.IMAGE)
        .orderBy({ key: AssetField.CREATION_TIME, ascending: true })
        .limit(PAGE_SIZE)
        .offset(offset)
        .exeForMetadata();

      const photos = items.filter((m) => !seen.has(m.id)).map(toPhoto);
      items.forEach((m) => seen.add(m.id));
      return {
        photos,
        nextCursor: items.length === PAGE_SIZE ? String(offset + PAGE_SIZE) : undefined,
      };
    },

    async getOriginalSize(photo: Photo): Promise<OriginalSizeResult> {
      try {
        const r = await resolveOriginal(photo);
        if (r.ok && r.uri) originalUris.set(photo.id, r.uri);
        const { uri: _uri, ...result } = r;
        return result;
      } catch (e) {
        return { ok: false, reason: 'unreadable', message: errorMessage(e), availability: 'unknown' };
      }
    },

    async hashOriginal(photo: Photo): Promise<HashOriginalResult> {
      try {
        let uri = originalUris.get(photo.id);
        if (!uri) {
          const r = await resolveOriginal(photo);
          if (!r.ok) return { ok: false, reason: r.reason, message: r.message };
          if (!r.uri) return { ok: false, reason: 'unreadable' };
          uri = r.uri;
        }
        // Native streaming SHA-256 of the full original (expo-file-system 58+).
        const sha256 = await new File(uri).digest('SHA-256');
        return { ok: true, sha256 };
      } catch (e) {
        return { ok: false, reason: 'unreadable', message: errorMessage(e) };
      }
    },
  };
}
