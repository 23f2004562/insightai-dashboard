# PhotoSweep

Finds duplicate and look-alike photos across your photo libraries and helps you clean them up safely.

**Milestone 3: real device scanning.** PhotoSweep can scan this phone's photo library (with permission) and find **exact duplicates** by SHA-256 of the original files. Real results are review-only. The sample demo, with invented accounts, is still available for UI work.

| Built | Not built yet (on purpose) |
| --- | --- |
| Photo access flow (explain first, then ask; full, limited, denied, blocked) | Deleting real photos |
| Real scan of this phone: paged listing, file sizes, native SHA-256 | Visually similar (perceptual) matching |
| Exact-duplicate groups with real thumbnails and file details | Google Photos, OneDrive, cloud deletion |
| Sample demo with multi-account data and the full delete review flow | Uploads or servers of any kind |

## Run it

You need [Node.js](https://nodejs.org) (version 20 or newer) and the **Expo Go** app on your phone (App Store or Google Play).

```bash
cd photosweep
npm install        # first time only: downloads the libraries
npx expo start     # starts the development server
```

A QR code appears in the terminal.

- **iPhone:** scan it with the Camera app.
- **Android:** scan it from inside Expo Go.

Your phone and computer must be on the same Wi-Fi network. Edits you save on your computer reload instantly on the phone.

### Expo Go or a development build?

- **Expo Go** includes `expo-media-library` and `expo-file-system`, so the real scan should run there. The permission prompt will show Expo Go's name and text, though.
- **A development build** shows PhotoSweep's own prompt and requests photo access only:

  ```bash
  npx expo run:ios       # needs a Mac with Xcode
  npx expo run:android   # needs Android Studio
  # or build in the cloud: npx eas-cli@latest build --profile development
  ```

Other ways to run:

- `npx expo start --web`: opens the app in a browser (handy for quick checks)
- press `i` or `a` in the terminal: opens an iOS Simulator (Mac only) or Android emulator, if installed

The sample thumbnails load from picsum.photos, so the phone needs an internet connection. Nothing is ever uploaded.

## Checks

```bash
npm run typecheck   # TypeScript (app + tests)
npm test            # catalog validation, hashing with real files, permission states
npx expo-doctor     # checks package versions and config
```

## Project layout

```
src/
  app/                  SCREENS. Each file is a route (Expo Router).
    _layout.tsx         Root: loads fonts, shared state, the navigation stack
    index.tsx           Welcome
    home.tsx            Dashboard (stats + Scan photos button)
    scan.tsx            Sample demo scan
    permission.tsx      Explains photo access, then asks; handles every answer
    device-scan.tsx     Real scan of this phone with live progress and Cancel
    results.tsx         Duplicate groups, keep/delete selection
    confirm.tsx         Review before deletion (modal)
    done.tsx            Outcome ("nothing was deleted")
  components/           Reusable building blocks (Button, PhotoThumb, AccountBadge, …)
  sources/              WHERE PHOTOS COME FROM
    adapter.ts          The interface every photo source implements
    providers.ts        Facts per provider: label, icon, deletion policy
    catalog.ts          Builds the catalog from adapters; resolvePhotoSource()
    ids.ts              Globally unique account and photo IDs
    sample/             Sample accounts and photos (demo mode)
    device/             This phone's library (expo-media-library) + permissions
  scanning/
    exactDuplicates.ts  Size check, SHA-256, grouping by identical hash
    deviceScan.ts       Runs a real scan end to end
    permissions.ts      Maps platform permission answers to UI states
  state/
    ScanContext.tsx     Shared state: results + the user's choices
    selection.ts        Pure helper functions (safety rule lives here)
  data/sampleData.ts    SAMPLE accounts, photos and groups (not real)
  theme/                Colors, spacing, typography: the whole look in one place
  types/index.ts        TypeScript shapes for photos, groups, scan results
  utils/format.ts       File size / number / date formatting
tests/                  npm test
```

## Data model

```
Provider (google_photos)
  └─ SourceAccount   id "google_photos:acct-work", displayName, email?
       └─ Photo      id "google_photos:acct-work/AF1Qip…", accountId,
                     sizeBytes, width, height, createdAt,
                     hashes { content (SHA-256), perceptual (dHash) }
```

- Any number of accounts per provider. Each has its own photo collection in `PhotoCatalog.collections`.
- Account name and email are stored once, on the account. `resolvePhotoSource(photo, catalog)` returns a photo's provider, account ID, display name, email and a safe label.
- `email` is optional: it is only present when shared and authorized. The UI falls back to "OneDrive (Backup)" style labels.
- Duplicate groups store photo IDs. Exact = same content hash; similar = close perceptual hash.

### How exact duplicates are found

1. **List** photos in pages of 200 with `Query.exeForMetadata()`. This reads only IDs, filenames, dimensions and dates.
2. **Size check:** read each original's exact byte size.
   - On iPhone, photos whose original is only in iCloud are skipped (`getIsInCloud()`), so nothing is downloaded.
   - Two files of different sizes can't be identical, so only photos that share a size go on to be hashed.
3. **Hash** with `File.digest('SHA-256')` from expo-file-system. It's native and streams the file in 64 KB chunks, one file at a time.
4. **Group** only photos whose hashes are equal. Names, dates and dimensions are never used to decide a match.

Each photo's `hash` has a status: `pending`, `processing`, `complete`, `skipped` (unique size) or `failed` (cloud-only or unreadable). Real photos never get invented hashes.

### Adding a real photo source

1. Create a file in `src/sources/` that implements `PhotoSourceAdapter`.
2. Add it to `activeAdapters` in `src/sources/index.ts`.

The screens don't change.

### Cloud photos are never deleted by PhotoSweep

Each provider has a `deletionPolicy`:

- **Phone:** `system-dialog`. Later, removal will go through the phone's own confirmation.
- **Google Photos, iCloud, OneDrive:** `manual`. PhotoSweep produces a per-account checklist and the user removes those copies in each service's own app.

## Key decisions

- **Expo Router** for navigation: each file in `src/app` is a screen.
- **React Context** for shared state, with no extra library. Enough for now; easy to replace later.
- **One theme folder** instead of a UI kit, so the design is custom and easy to change.
- **Honest demo mode:** `ScanSummary.source` is `'sample'`, and the UI shows a "Sample data" label wherever sample results appear.
- **Safety first:** photos default to *keep*. A group can never have all its photos marked for deletion. Deleting needs a review screen plus a checkbox.

## Next milestones (suggested)

1. Visually similar matching (perceptual hashes), on the device.
2. Phone deletion through the system's own delete dialog (photos go to Recently Deleted).
3. Remember scan results between app launches, so a large library isn't rescanned every time.
4. A Google Photos Picker adapter (users choose which photos to share).
