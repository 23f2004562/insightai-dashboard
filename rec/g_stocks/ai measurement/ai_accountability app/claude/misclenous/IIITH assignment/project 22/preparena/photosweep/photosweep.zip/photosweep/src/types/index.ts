/**
 * Shared TypeScript types — PhotoSweep's data model.
 *
 * The big idea: every photo belongs to exactly one SourceAccount, and an
 * account belongs to one provider. A user can have any number of accounts
 * per provider (e.g. three Google accounts).
 *
 *   Provider (google_photos)
 *     └─ SourceAccount (google_photos:acct-personal)   ← has its own photo collection
 *          └─ Photo (google_photos:acct-personal/AF1Qip…)
 *
 * Account details (name, email) are stored ONCE, on the account. Photos only
 * store the account's ID. Use resolvePhotoSource() in src/sources to get the
 * full source details for a photo.
 */

// ─── Providers and accounts ──────────────────────────────────────────────

/** Where photos can come from. Add new providers here. */
export type ProviderId = 'device' | 'google_photos' | 'icloud' | 'onedrive';

/**
 * How PhotoSweep is allowed to remove a photo from this provider.
 * - system-dialog: the phone's own "Delete N photos?" prompt (device library)
 * - manual:        PhotoSweep never deletes; the user removes it in the provider's app
 */
export type DeletionPolicy = 'system-dialog' | 'manual';

/**
 * sample        = invented account used by the prototype
 * connected     = the user granted access (later milestones)
 * not_connected = known provider, no access yet
 */
export type ConnectionStatus = 'sample' | 'connected' | 'not_connected';

/** e.g. "google_photos:acct-personal". Always `${provider}:${providerAccountId}`. */
export type AccountId = string;

/** e.g. "google_photos:acct-personal/AF1Qip9x". Always `${accountId}/${providerPhotoId}`. */
export type PhotoId = string;

export interface SourceAccount {
  id: AccountId;
  provider: ProviderId;
  /** The account's ID as the provider knows it (Google's user ID, OneDrive drive ID…). */
  providerAccountId: string;
  /** A label the user recognises: "Personal", "Work", "Phone library". */
  displayName: string;
  /**
   * Only set when the provider shares it AND the user authorized it.
   * Screens must not assume it exists — use accountLabel() for a safe fallback.
   */
  email?: string;
  connection: ConnectionStatus;
  /** Total photos in this account, if the provider reports it. */
  totalPhotos?: number;
}

// ─── Photos ──────────────────────────────────────────────────────────────

export interface PhotoHashes {
  /** SHA-256 of the file bytes. Equal hashes = exact copy. */
  content: string;
  /** Perceptual hash (64-bit dHash, hex). Close values = looks the same. */
  perceptual: string;
}

export interface Photo {
  id: PhotoId;
  accountId: AccountId;
  /** Copied from the account for fast filtering. Always equals the account's provider. */
  provider: ProviderId;
  /** The photo's ID inside its provider (MediaStore ID, PHAsset localIdentifier, Google media item ID…). */
  providerPhotoId: string;
  /** Thumbnail address. */
  uri: string;
  filename: string;
  /** ISO date string when the photo was taken/created. */
  createdAt: string;
  sizeBytes: number;
  width: number;
  height: number;
  hashes: PhotoHashes;
}

/** Everything about where a photo lives, resolved from its account. */
export interface PhotoSource {
  provider: ProviderId;
  providerLabel: string;
  accountId: AccountId;
  accountDisplayName: string;
  email?: string;
  /** Email if known, otherwise "Google Photos (Work)" style label. Always safe to show. */
  label: string;
  deletionPolicy: DeletionPolicy;
}

// ─── Catalog: all accounts and their photos ──────────────────────────────

/**
 * A normalized store: each photo exists once in `photos`, and everything
 * else refers to it by ID. This keeps every screen in sync.
 */
export interface PhotoCatalog {
  accounts: Record<AccountId, SourceAccount>;
  /** Each account's own photo collection (photo IDs, in order). */
  collections: Record<AccountId, PhotoId[]>;
  photos: Record<PhotoId, Photo>;
}

// ─── Duplicate detection results ─────────────────────────────────────────

/**
 * exact   = identical content hash (byte-for-byte copies)
 * similar = close perceptual hash (bursts, edits, re-saved copies)
 */
export type MatchKind = 'exact' | 'similar';

export interface DuplicateGroup {
  id: string;
  kind: MatchKind;
  /** 0–100. How alike the photos in the group are. */
  similarity: number;
  /** Short human-readable label, e.g. "Same photo in 3 accounts". */
  title: string;
  photoIds: PhotoId[];
  /** The copy we would suggest keeping. */
  suggestedKeepId: PhotoId;
  suggestionReason: string;
}

/** What the user decided for each photo. Undecided photos count as "keep". */
export type PhotoDecision = 'keep' | 'delete';

/** Whether results are invented ('sample') or from a real scan. */
export type ResultSource = 'sample' | 'device-scan';

export interface ScanSummary {
  source: ResultSource;
  totalPhotosScanned: number;
  catalog: PhotoCatalog;
  groups: DuplicateGroup[];
  completedAt: string;
}
