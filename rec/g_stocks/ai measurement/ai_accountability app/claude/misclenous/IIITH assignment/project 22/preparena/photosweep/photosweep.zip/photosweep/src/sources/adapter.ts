import { AccountId, Photo, PhotoId, ProviderId, SourceAccount } from '@/types';

/**
 * THE PLUG-IN CONTRACT FOR PHOTO SOURCES.
 *
 * Every way of reading photos implements this interface. The rest of the
 * app (catalog, duplicate detection, screens) only talks to this interface,
 * so new sources can be added without touching the UI.
 *
 * Implemented now:
 *   sample/sampleAdapter.ts      invented accounts and photos
 *
 * Planned (one file each, same interface):
 *   device/mediaLibraryAdapter.ts   Android gallery + iOS Photos (expo-media-library)
 *   google/pickerAdapter.ts          Google Photos Picker API (user-picked items only)
 *   onedrive/graphAdapter.ts         Microsoft Graph
 */

export interface PhotoPage {
  photos: Photo[];
  /** Pass back to listPhotos() for the next page. Undefined = no more pages. */
  nextCursor?: string;
}

export interface PhotoSourceAdapter {
  /** Stable name for this adapter, e.g. 'sample', 'media-library', 'google-picker'. */
  readonly id: string;
  /** Which providers' accounts this adapter can return. */
  readonly providers: readonly ProviderId[];

  /** Can this adapter run on this platform right now? (e.g. iOS-only APIs) */
  isAvailable(): boolean;

  /** Accounts this adapter can see. A provider can return several (multiple Google accounts). */
  listAccounts(): Promise<SourceAccount[]>;

  /** One page of an account's photo collection. Photos must use IDs from makePhotoId(). */
  listPhotos(accountId: AccountId, cursor?: string): Promise<PhotoPage>;

  /**
   * ONLY for providers whose deletionPolicy is 'system-dialog' (the device library).
   * Must show the operating system's own confirmation. Cloud adapters must never
   * implement this. Not implemented by any adapter in this milestone.
   */
  requestDeletion?(photoIds: PhotoId[]): Promise<{ deleted: PhotoId[]; cancelled: boolean }>;
}
