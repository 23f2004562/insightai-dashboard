/**
 * PhotoSweep color palette.
 *
 * Every screen and component reads colors from here instead of hard-coding
 * hex values. To restyle the whole app, change the values in this one file.
 *
 * The palette borrows from a photographer's light table: cool paper,
 * deep slate ink, and two "grease pencil" marks — teal for keep, red for delete.
 */
export const colors = {
  // Surfaces
  paper: '#F1F3F6', // app background — cool, not cream
  card: '#FFFFFF',
  sunken: '#E6E9EF', // inset areas such as progress tracks
  night: '#121A2B', // welcome + scan screens
  nightRaised: '#1C2639',

  // Text
  ink: '#152033',
  inkSoft: '#56627A',
  inkFaint: '#8C95A8',
  onNight: '#F1F3F6',
  onNightSoft: '#9AA6BF',

  // Lines
  line: '#DCE0E8',
  lineNight: '#2A3550',

  // Meaning
  keep: '#0E7C66', // grease-pencil teal
  keepTint: '#DDF1EB',
  remove: '#D6453D', // grease-pencil red
  removeTint: '#FBE4E2',
  sample: '#B7791F', // amber marker for "sample data" labels
  sampleTint: '#FBF0DC',

  // Primary action
  accent: '#3F5BD9', // cobalt
  accentPressed: '#2F48B8',
  onAccent: '#FFFFFF',
} as const;

export type ColorName = keyof typeof colors;
