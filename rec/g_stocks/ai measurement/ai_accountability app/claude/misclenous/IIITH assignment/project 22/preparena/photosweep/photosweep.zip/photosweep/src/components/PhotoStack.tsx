import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useEffect, useRef } from 'react';
import { AccessibilityInfo, Animated, Easing, StyleSheet, View } from 'react-native';

import { colors, radius } from '@/theme';

const W = 168;
const H = 208;

/** A drawn "print" of a sunset — made from shapes, so it needs no image files or internet. */
function Print() {
  return (
    <View style={styles.print}>
      <LinearGradient colors={['#F6B26B', '#E0607E', '#5B4B9A']} style={styles.picture}>
        <View style={styles.sun} />
        <View style={styles.hillBack} />
        <View style={styles.hillFront} />
      </LinearGradient>
    </View>
  );
}

/**
 * Welcome-screen hero: three identical prints fanned out, which then
 * sweep away to leave a single copy marked "keep" — the whole app in one gesture.
 * Plays once. Skipped if the user has "Reduce motion" turned on.
 */
export function PhotoStack() {
  const t = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    let cancelled = false;
    AccessibilityInfo.isReduceMotionEnabled().then((reduce) => {
      if (cancelled) return;
      if (reduce) {
        t.setValue(1);
        return;
      }
      Animated.timing(t, {
        toValue: 1,
        duration: 1400,
        delay: 700,
        easing: Easing.inOut(Easing.cubic),
        useNativeDriver: true,
      }).start();
    });
    return () => {
      cancelled = true;
    };
  }, [t]);

  // Side prints: start fanned, then slide outward and fade.
  const side = (dir: -1 | 1) => ({
    opacity: t.interpolate({ inputRange: [0, 0.5, 1], outputRange: [1, 0.9, 0] }),
    transform: [
      { translateX: t.interpolate({ inputRange: [0, 1], outputRange: [dir * 46, dir * 150] }) },
      { translateY: t.interpolate({ inputRange: [0, 1], outputRange: [14, 30] }) },
      { rotate: t.interpolate({ inputRange: [0, 1], outputRange: [`${dir * 11}deg`, `${dir * 22}deg`] }) },
    ],
  });

  const center = {
    transform: [{ scale: t.interpolate({ inputRange: [0, 1], outputRange: [1, 1.06] }) }],
  };
  const check = {
    opacity: t.interpolate({ inputRange: [0.7, 1], outputRange: [0, 1], extrapolate: 'clamp' }),
    transform: [{ scale: t.interpolate({ inputRange: [0.7, 1], outputRange: [0.5, 1], extrapolate: 'clamp' }) }],
  };

  return (
    <View style={styles.stage} accessible accessibilityLabel="Three copies of the same photo become one">
      <Animated.View style={[styles.abs, side(-1)]}>
        <Print />
      </Animated.View>
      <Animated.View style={[styles.abs, side(1)]}>
        <Print />
      </Animated.View>
      <Animated.View style={[styles.abs, center]}>
        <Print />
        <Animated.View style={[styles.check, check]}>
          <Feather name="check" size={22} color="#FFFFFF" />
        </Animated.View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  stage: { height: H + 60, alignItems: 'center', justifyContent: 'center' },
  abs: { position: 'absolute' },
  print: {
    width: W,
    height: H,
    padding: 8,
    paddingBottom: 30,
    backgroundColor: '#FAFBFC',
    borderRadius: radius.sm,
    shadowColor: '#000',
    shadowOpacity: 0.35,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
  },
  picture: { flex: 1, borderRadius: 3, overflow: 'hidden' },
  sun: {
    position: 'absolute',
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: '#FFE3B0',
    top: 38,
    left: 54,
  },
  hillBack: {
    position: 'absolute',
    width: 220,
    height: 220,
    borderRadius: 110,
    backgroundColor: '#3E3A7A',
    top: 108,
    left: -70,
  },
  hillFront: {
    position: 'absolute',
    width: 240,
    height: 240,
    borderRadius: 120,
    backgroundColor: '#24234F',
    top: 128,
    left: 10,
  },
  check: {
    position: 'absolute',
    top: -14,
    right: -14,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.keep,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: colors.night,
  },
});
