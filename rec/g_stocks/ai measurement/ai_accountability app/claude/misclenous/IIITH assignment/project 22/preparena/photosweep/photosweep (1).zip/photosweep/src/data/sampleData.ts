import { makeAccountId, makePhotoId } from '@/sources/ids';
import { AccountId, DuplicateGroup, Photo, SourceAccount } from '@/types';

/**
 * SAMPLE DATA — NOT REAL ACCOUNTS OR SCAN RESULTS.
 *
 * Everything here is invented so we can design the UI before real sources
 * exist. Emails use example.com, a domain reserved for examples, so they
 * can't belong to a real person. Thumbnails are free stock photos from
 * picsum.photos (downloaded for display only; nothing is uploaded).
 * Hashes are made-up values with the right shape, not real hashes.
 *
 * This data reaches the app only through src/sources/sample/sampleAdapter.ts,
 * the same way real accounts will later.
 */

// ─── Accounts ────────────────────────────────────────────────────────────

const PHONE = makeAccountId('device', 'this-phone');
const G_PERSONAL = makeAccountId('google_photos', 'acct-personal');
const G_WORK = makeAccountId('google_photos', 'acct-work');
const G_OLD = makeAccountId('google_photos', 'acct-old');
const ICLOUD = makeAccountId('icloud', 'acct-main');
const ONEDRIVE = makeAccountId('onedrive', 'acct-backup');

export const sampleAccounts: SourceAccount[] = [
  { id: PHONE, provider: 'device', providerAccountId: 'this-phone', displayName: 'Phone library', connection: 'sample', totalPhotos: 1964 },
  { id: G_PERSONAL, provider: 'google_photos', providerAccountId: 'acct-personal', displayName: 'Personal', email: 'alex.rivera@example.com', connection: 'sample', totalPhotos: 1210 },
  { id: G_WORK, provider: 'google_photos', providerAccountId: 'acct-work', displayName: 'Work', email: 'a.rivera@studio.example.com', connection: 'sample', totalPhotos: 642 },
  { id: G_OLD, provider: 'google_photos', providerAccountId: 'acct-old', displayName: 'Old account', email: 'alexr2014@example.com', connection: 'sample', totalPhotos: 388 },
  { id: ICLOUD, provider: 'icloud', providerAccountId: 'acct-main', displayName: 'Main', email: 'alex.r@example.com', connection: 'sample', totalPhotos: 455 },
  // No email: shows how the UI falls back when an email isn't authorized.
  { id: ONEDRIVE, provider: 'onedrive', providerAccountId: 'acct-backup', displayName: 'Backup', connection: 'sample', totalPhotos: 153 },
];

// ─── Sample hashes ───────────────────────────────────────────────────────

/** Deterministic fake hex string (FNV-1a based). NOT a real hash — just the right shape. */
function fakeHex(seed: string, length: number): string {
  let out = '';
  let h = 2166136261;
  for (let round = 0; out.length < length; round++) {
    for (const ch of `${seed}#${round}`) {
      h ^= ch.charCodeAt(0);
      h = Math.imul(h, 16777619) >>> 0;
    }
    out += h.toString(16).padStart(8, '0');
  }
  return out.slice(0, length);
}

/** Similar photos get perceptual hashes that differ in only the last few characters. */
function nearHash(base: string, variant: number): string {
  if (variant === 0) return base;
  return base.slice(0, 13) + fakeHex(`${base}${variant}`, 3);
}

// ─── Photos ──────────────────────────────────────────────────────────────

interface SamplePhotoSpec {
  accountId: AccountId;
  providerPhotoId: string;
  picsumId: number;
  filename: string;
  createdAt: string;
  sizeMB: number;
  width: number;
  height: number;
  /** Photos with the same contentKey are exact copies. */
  contentKey: string;
  /** Photos with the same perceptualKey look alike; variant 0 = base. */
  perceptualKey: string;
  variant: number;
  /** Optional picsum effect so look-alikes don't look identical. */
  effect?: string;
}

const MB = 1024 * 1024;

function toPhoto(s: SamplePhotoSpec): Photo {
  const provider = sampleAccounts.find((a) => a.id === s.accountId)!.provider;
  // Thumbnail keeps the photo's real aspect ratio, scaled down.
  const scale = 400 / Math.max(s.width, s.height);
  const tw = Math.round(s.width * scale);
  const th = Math.round(s.height * scale);
  return {
    id: makePhotoId(s.accountId, s.providerPhotoId),
    accountId: s.accountId,
    provider,
    providerPhotoId: s.providerPhotoId,
    uri: `https://picsum.photos/id/${s.picsumId}/${tw}/${th}${s.effect ?? ''}`,
    filename: s.filename,
    createdAt: s.createdAt,
    sizeBytes: Math.round(s.sizeMB * MB),
    width: s.width,
    height: s.height,
    // Sample photos are "complete" with SAMPLE hash values. Real photos start as 'pending'.
    hash: {
      status: 'complete',
      content: fakeHex(`content:${s.contentKey}`, 64),
      perceptual: nearHash(fakeHex(`phash:${s.perceptualKey}`, 16), s.variant),
    },
    availability: 'local',
  };
}

const specs: SamplePhotoSpec[] = [
  // g1 — burst on the phone
  { accountId: PHONE, providerPhotoId: '48211', picsumId: 1015, filename: 'IMG_4821.HEIC', createdAt: '2026-08-14T18:42:03Z', sizeMB: 3.1, width: 4032, height: 3024, contentKey: 'g1a', perceptualKey: 'g1', variant: 1 },
  { accountId: PHONE, providerPhotoId: '48212', picsumId: 1015, filename: 'IMG_4822.HEIC', createdAt: '2026-08-14T18:42:03Z', sizeMB: 3.4, width: 4032, height: 3024, contentKey: 'g1b', perceptualKey: 'g1', variant: 0 },
  { accountId: PHONE, providerPhotoId: '48213', picsumId: 1015, filename: 'IMG_4823.HEIC', createdAt: '2026-08-14T18:42:04Z', sizeMB: 3.0, width: 4032, height: 3024, contentKey: 'g1c', perceptualKey: 'g1', variant: 2 },
  { accountId: PHONE, providerPhotoId: '48214', picsumId: 1015, filename: 'IMG_4824.HEIC', createdAt: '2026-08-14T18:42:04Z', sizeMB: 2.9, width: 4032, height: 3024, contentKey: 'g1d', perceptualKey: 'g1', variant: 3, effect: '?blur=1' },

  // g2 — phone photo backed up to Google (Personal)
  { accountId: PHONE, providerPhotoId: '33071', picsumId: 1025, filename: 'IMG_3307.HEIC', createdAt: '2026-06-02T09:15:40Z', sizeMB: 2.7, width: 3024, height: 4032, contentKey: 'g2', perceptualKey: 'g2', variant: 0 },
  { accountId: G_PERSONAL, providerPhotoId: 'AF1QipN3307', picsumId: 1025, filename: 'IMG_3307.HEIC', createdAt: '2026-06-02T09:15:40Z', sizeMB: 2.7, width: 3024, height: 4032, contentKey: 'g2', perceptualKey: 'g2', variant: 0 },

  // g3 — original in Google (Work) + two recompressed chat copies on the phone
  { accountId: G_WORK, providerPhotoId: 'AF1QipW0921', picsumId: 237, filename: 'team-dog.jpg', createdAt: '2026-09-21T16:03:11Z', sizeMB: 4.2, width: 4000, height: 3000, contentKey: 'g3a', perceptualKey: 'g3', variant: 0 },
  { accountId: PHONE, providerPhotoId: '50004', picsumId: 237, filename: 'IMG-20260921-WA0004.jpg', createdAt: '2026-09-21T16:05:29Z', sizeMB: 0.31, width: 1600, height: 1200, contentKey: 'g3b', perceptualKey: 'g3', variant: 1 },
  { accountId: PHONE, providerPhotoId: '50007', picsumId: 237, filename: 'IMG-20260921-WA0007.jpg', createdAt: '2026-09-21T16:05:52Z', sizeMB: 0.31, width: 1600, height: 1200, contentKey: 'g3c', perceptualKey: 'g3', variant: 1 },

  // g4 — original and edit on the phone
  { accountId: PHONE, providerPhotoId: '22901', picsumId: 1016, filename: 'IMG_2290.HEIC', createdAt: '2026-04-11T11:27:00Z', sizeMB: 3.8, width: 4032, height: 3024, contentKey: 'g4a', perceptualKey: 'g4', variant: 1, effect: '?grayscale' },
  { accountId: PHONE, providerPhotoId: '22902', picsumId: 1016, filename: 'IMG_2290_edit.HEIC', createdAt: '2026-04-12T08:02:14Z', sizeMB: 4.1, width: 4032, height: 3024, contentKey: 'g4b', perceptualKey: 'g4', variant: 0 },

  // g5 — burst in the old Google account
  { accountId: G_OLD, providerPhotoId: 'AF1QipO1432a', picsumId: 1069, filename: 'PXL_20260705_143201.jpg', createdAt: '2026-07-05T14:32:01Z', sizeMB: 3.6, width: 3072, height: 4080, contentKey: 'g5a', perceptualKey: 'g5', variant: 2, effect: '?blur=2' },
  { accountId: G_OLD, providerPhotoId: 'AF1QipO1432b', picsumId: 1069, filename: 'PXL_20260705_143202.jpg', createdAt: '2026-07-05T14:32:02Z', sizeMB: 3.5, width: 3072, height: 4080, contentKey: 'g5b', perceptualKey: 'g5', variant: 1 },
  { accountId: G_OLD, providerPhotoId: 'AF1QipO1432c', picsumId: 1069, filename: 'PXL_20260705_143202_1.jpg', createdAt: '2026-07-05T14:32:02Z', sizeMB: 3.9, width: 3072, height: 4080, contentKey: 'g5c', perceptualKey: 'g5', variant: 0 },

  // g6 — same photo in all three Google accounts
  { accountId: G_PERSONAL, providerPhotoId: 'AF1QipP1175', picsumId: 1080, filename: 'IMG_1175.HEIC', createdAt: '2026-05-18T19:48:22Z', sizeMB: 2.4, width: 4032, height: 3024, contentKey: 'g6', perceptualKey: 'g6', variant: 0 },
  { accountId: G_WORK, providerPhotoId: 'AF1QipW1175', picsumId: 1080, filename: 'IMG_1175.HEIC', createdAt: '2026-05-18T19:48:22Z', sizeMB: 2.4, width: 4032, height: 3024, contentKey: 'g6', perceptualKey: 'g6', variant: 0 },
  { accountId: G_OLD, providerPhotoId: 'AF1QipO1175', picsumId: 1080, filename: 'IMG_1175.HEIC', createdAt: '2026-05-18T19:48:22Z', sizeMB: 2.4, width: 4032, height: 3024, contentKey: 'g6', perceptualKey: 'g6', variant: 0 },

  // g7 — screenshot on the phone, cropped copy in iCloud
  { accountId: PHONE, providerPhotoId: '61003', picsumId: 1074, filename: 'Screenshot_2026-10-03.png', createdAt: '2026-10-03T21:10:45Z', sizeMB: 1.6, width: 1170, height: 2532, contentKey: 'g7a', perceptualKey: 'g7', variant: 0 },
  { accountId: ICLOUD, providerPhotoId: 'B7E2-61003-C', picsumId: 1074, filename: 'Screenshot 2026-10-03 cropped.png', createdAt: '2026-10-03T21:12:09Z', sizeMB: 0.9, width: 1170, height: 1170, contentKey: 'g7b', perceptualKey: 'g7', variant: 1 },

  // g8 — iCloud photo also backed up to OneDrive
  { accountId: ICLOUD, providerPhotoId: 'C41A-0817', picsumId: 1084, filename: 'IMG_0817.JPG', createdAt: '2026-03-08T13:20:05Z', sizeMB: 3.3, width: 4032, height: 3024, contentKey: 'g8', perceptualKey: 'g8', variant: 0 },
  { accountId: ONEDRIVE, providerPhotoId: '01BYE5RZ-0817', picsumId: 1084, filename: 'IMG_0817.JPG', createdAt: '2026-03-08T13:20:05Z', sizeMB: 3.3, width: 4032, height: 3024, contentKey: 'g8', perceptualKey: 'g8', variant: 0 },
];

export const samplePhotos: Photo[] = specs.map(toPhoto);

/** Short helper to reference a sample photo by account + provider ID. */
const id = (accountId: AccountId, providerPhotoId: string) => makePhotoId(accountId, providerPhotoId);

// ─── Sample duplicate groups (what a real detector would produce) ─────────

export const sampleGroups: DuplicateGroup[] = [
  {
    id: 'g1', kind: 'similar', similarity: 94, title: 'Burst of 4 shots',
    photoIds: [id(PHONE, '48211'), id(PHONE, '48212'), id(PHONE, '48213'), id(PHONE, '48214')],
    suggestedKeepId: id(PHONE, '48212'), suggestionReason: 'Sharpest of the burst',
  },
  {
    id: 'g6', kind: 'exact', similarity: 100, title: 'Same photo in 3 Google accounts',
    photoIds: [id(G_PERSONAL, 'AF1QipP1175'), id(G_WORK, 'AF1QipW1175'), id(G_OLD, 'AF1QipO1175')],
    suggestedKeepId: id(G_PERSONAL, 'AF1QipP1175'), suggestionReason: 'Kept in your personal account',
  },
  {
    id: 'g2', kind: 'exact', similarity: 100, title: 'Phone photo also in Google Photos',
    photoIds: [id(PHONE, '33071'), id(G_PERSONAL, 'AF1QipN3307')],
    suggestedKeepId: id(G_PERSONAL, 'AF1QipN3307'), suggestionReason: 'Already backed up, frees phone space',
  },
  {
    id: 'g3', kind: 'similar', similarity: 97, title: 'Original and 2 chat copies',
    photoIds: [id(G_WORK, 'AF1QipW0921'), id(PHONE, '50004'), id(PHONE, '50007')],
    suggestedKeepId: id(G_WORK, 'AF1QipW0921'), suggestionReason: 'Full-resolution original',
  },
  {
    id: 'g8', kind: 'exact', similarity: 100, title: 'Same photo in iCloud and OneDrive',
    photoIds: [id(ICLOUD, 'C41A-0817'), id(ONEDRIVE, '01BYE5RZ-0817')],
    suggestedKeepId: id(ICLOUD, 'C41A-0817'), suggestionReason: 'Keeps your main library copy',
  },
  {
    id: 'g4', kind: 'similar', similarity: 88, title: 'Original and edited copy',
    photoIds: [id(PHONE, '22901'), id(PHONE, '22902')],
    suggestedKeepId: id(PHONE, '22902'), suggestionReason: 'Your edited version',
  },
  {
    id: 'g5', kind: 'similar', similarity: 91, title: 'Burst of 3 shots',
    photoIds: [id(G_OLD, 'AF1QipO1432a'), id(G_OLD, 'AF1QipO1432b'), id(G_OLD, 'AF1QipO1432c')],
    suggestedKeepId: id(G_OLD, 'AF1QipO1432c'), suggestionReason: 'Best focus and exposure',
  },
  {
    id: 'g7', kind: 'similar', similarity: 86, title: 'Screenshot and cropped copy',
    photoIds: [id(PHONE, '61003'), id(ICLOUD, 'B7E2-61003-C')],
    suggestedKeepId: id(PHONE, '61003'), suggestionReason: 'Full, uncropped version',
  },
];

/** Steps the demo scan screen walks through. */
export const scanStages = [
  'Listing photos in each account',
  'Creating a visual fingerprint for each photo',
  'Comparing fingerprints to find matches',
  'Grouping duplicates and picking the best copy',
] as const;
