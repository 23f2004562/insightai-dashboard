import { Feather } from '@expo/vector-icons';
import { StyleSheet, View } from 'react-native';

import { colors, radius, spacing } from '@/theme';
import { AppText } from './AppText';

interface SampleBadgeProps {
  /** 'inline' = small pill, 'banner' = full-width explanation */
  kind?: 'inline' | 'banner';
  message?: string;
}

/**
 * Shown wherever sample results appear, so nobody mistakes them for a real scan.
 * Remove it only when results come from a real scan (ScanSummary.source === 'device-scan').
 */
export function SampleBadge({ kind = 'inline', message }: SampleBadgeProps) {
  if (kind === 'inline') {
    return (
      <View style={styles.pill} accessibilityLabel="Sample data">
        <Feather name="info" size={12} color={colors.sample} />
        <AppText variant="caption" style={styles.pillText}>
          Sample data
        </AppText>
      </View>
    );
  }
  return (
    <View style={styles.banner} accessibilityRole="text">
      <Feather name="info" size={16} color={colors.sample} style={styles.bannerIcon} />
      <AppText variant="small" color="ink" style={styles.bannerText}>
        {message ??
          'These are sample results for the prototype. Your photos have not been scanned, and nothing will be deleted.'}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'flex-start',
    backgroundColor: colors.sampleTint,
    paddingHorizontal: spacing.xs,
    paddingVertical: 3,
    borderRadius: radius.pill,
  },
  pillText: { color: colors.sample, fontWeight: '600' },
  banner: {
    flexDirection: 'row',
    gap: spacing.xs,
    backgroundColor: colors.sampleTint,
    padding: spacing.sm,
    borderRadius: radius.md,
    borderLeftWidth: 3,
    borderLeftColor: colors.sample,
  },
  bannerIcon: { marginTop: 2 },
  bannerText: { flex: 1 },
});
