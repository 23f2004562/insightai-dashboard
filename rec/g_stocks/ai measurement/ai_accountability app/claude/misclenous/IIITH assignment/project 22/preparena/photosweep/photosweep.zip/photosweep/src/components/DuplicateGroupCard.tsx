import { Feather } from '@expo/vector-icons';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';

import { accountShortName, getPhotos, providers } from '@/sources';
import { decisionFor, Decisions, keptInGroup } from '@/state/selection';
import { colors, radius, spacing } from '@/theme';
import { DuplicateGroup, PhotoCatalog, PhotoId } from '@/types';
import { plural } from '@/utils/format';
import { AppText } from './AppText';
import { PhotoThumb } from './PhotoThumb';

interface DuplicateGroupCardProps {
  group: DuplicateGroup;
  catalog: PhotoCatalog;
  decisions: Decisions;
  onTogglePhoto: (photoId: PhotoId) => void;
  onUseSuggestion: () => void;
}

const THUMB = 124;

/** One group of matching photos, showing which account each copy lives in. */
export function DuplicateGroupCard({ group, catalog, decisions, onTogglePhoto, onUseSuggestion }: DuplicateGroupCardProps) {
  const photos = getPhotos(catalog, group.photoIds);
  const kept = keptInGroup(group, decisions).length;
  const marked = photos.filter((p) => decisionFor(decisions, p.id) === 'delete');
  const markedCloud = marked.filter((p) => providers[p.provider].kind === 'cloud').length;
  const suggested = catalog.photos[group.suggestedKeepId];
  const suggestedAccount = suggested ? catalog.accounts[suggested.accountId] : undefined;
  const followsSuggestion = group.photoIds.every(
    (id) => decisionFor(decisions, id) === (id === group.suggestedKeepId ? 'keep' : 'delete'),
  );

  const accountIds = [...new Set(photos.map((p) => p.accountId))];
  const accountsLine =
    accountIds.length === 1
      ? `All in ${accountShortName(catalog.accounts[accountIds[0]])}`
      : `Across ${accountIds.length} accounts`;

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View style={styles.headerText}>
          <AppText variant="heading">{group.title}</AppText>
          <AppText variant="small" color="inkSoft">
            {accountsLine}
          </AppText>
        </View>
        <View style={[styles.kind, group.kind === 'exact' ? styles.kindExact : styles.kindSimilar]}>
          <Feather name={group.kind === 'exact' ? 'copy' : 'eye'} size={12} color={colors.ink} />
          <AppText variant="caption" style={styles.kindText}>
            {group.kind === 'exact' ? 'Exact match' : `Similar, ${group.similarity}%`}
          </AppText>
        </View>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.thumbs}>
        {photos.map((p) => (
          <PhotoThumb
            key={p.id}
            photo={p}
            size={THUMB}
            account={catalog.accounts[p.accountId]}
            showDetails
            decision={decisionFor(decisions, p.id)}
            suggested={p.id === group.suggestedKeepId}
            onPress={() => onTogglePhoto(p.id)}
          />
        ))}
      </ScrollView>

      <View style={styles.footer}>
        <AppText variant="small" color="inkSoft" style={styles.footerText}>
          Keeping {kept}
          {marked.length > 0 ? (
            <AppText variant="smallStrong" color="remove">
              , removing {marked.length}
            </AppText>
          ) : null}
        </AppText>
        {!followsSuggestion && (
          <Pressable
            onPress={onUseSuggestion}
            style={({ pressed }) => [styles.suggestBtn, pressed && { backgroundColor: colors.sunken }]}
            accessibilityRole="button"
            accessibilityLabel={`Keep best only: ${suggested?.filename}`}
          >
            <Feather name="star" size={14} color={colors.accent} />
            <AppText variant="smallStrong" style={{ color: colors.accent }}>
              Keep best only
            </AppText>
          </Pressable>
        )}
      </View>

      {markedCloud > 0 && (
        <View style={styles.cloudNote}>
          <Feather name="flag" size={13} color={colors.inkSoft} style={styles.noteIcon} />
          <AppText variant="caption" color="inkSoft" style={styles.flex}>
            {plural(markedCloud, 'cloud copy', 'cloud copies')} marked. PhotoSweep won't delete{' '}
            {markedCloud === 1 ? 'it' : 'them'}; you'll get a checklist to remove {markedCloud === 1 ? 'it' : 'them'}{' '}
            yourself.
          </AppText>
        </View>
      )}

      {!followsSuggestion && suggested && suggestedAccount && (
        <AppText variant="caption" color="inkFaint" style={styles.reason}>
          Best: {suggested.filename} in {accountShortName(suggestedAccount)}. {group.suggestionReason}.
        </AppText>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  header: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm, paddingHorizontal: spacing.md },
  headerText: { flex: 1, gap: 2 },
  kind: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: spacing.xs,
    paddingVertical: 3,
    borderRadius: radius.sm,
  },
  kindExact: { backgroundColor: colors.removeTint },
  kindSimilar: { backgroundColor: colors.sunken },
  kindText: { fontWeight: '600', color: colors.ink },
  thumbs: { gap: spacing.sm, paddingHorizontal: spacing.md, paddingVertical: spacing.md },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    minHeight: 36,
  },
  footerText: { flex: 1 },
  suggestBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.md,
  },
  cloudNote: { flexDirection: 'row', gap: 6, paddingHorizontal: spacing.md, marginTop: spacing.xxs },
  noteIcon: { marginTop: 2 },
  reason: { paddingHorizontal: spacing.md, marginTop: spacing.xxs },
});
