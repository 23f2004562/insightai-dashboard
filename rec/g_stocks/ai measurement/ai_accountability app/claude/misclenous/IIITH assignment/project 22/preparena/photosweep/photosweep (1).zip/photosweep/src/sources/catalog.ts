import { AccountId, Photo, PhotoCatalog, PhotoId, PhotoSource, SourceAccount } from '@/types';
import { PhotoSourceAdapter } from './adapter';
import { makeAccountId, makePhotoId } from './ids';
import { providers } from './providers';

/** Thrown when an adapter returns data that breaks the catalog's rules. */
export class CatalogValidationError extends Error {
  constructor(
    public readonly code:
      | 'duplicate-account'
      | 'inconsistent-account-id'
      | 'unknown-provider'
      | 'duplicate-photo'
      | 'unknown-account'
      | 'wrong-account'
      | 'provider-mismatch'
      | 'inconsistent-photo-id'
      | 'repeated-cursor'
      | 'too-many-pages',
    message: string,
  ) {
    super(message);
    this.name = 'CatalogValidationError';
  }
}

/** Thrown when the caller cancels while the catalog is being built. */
export class CancelledError extends Error {
  constructor() {
    super('Cancelled');
    this.name = 'CancelledError';
  }
}

/** Anything with an `aborted` flag (an AbortSignal works). */
export interface CancelSignal {
  readonly aborted: boolean;
}

export interface BuildCatalogOptions {
  signal?: CancelSignal;
  /** Called after every page with the running photo count. */
  onProgress?: (photosListed: number) => void;
  /** Safety net against adapters that never stop paging. */
  maxPagesPerAccount?: number;
}

/** Checks one account's own fields. */
export function validateAccount(account: SourceAccount): void {
  if (!providers[account.provider]) {
    throw new CatalogValidationError(
      'unknown-provider',
      `Account "${account.id}" has unknown provider "${account.provider}"`,
    );
  }
  const expected = makeAccountId(account.provider, account.providerAccountId);
  if (account.id !== expected) {
    throw new CatalogValidationError(
      'inconsistent-account-id',
      `Account ID "${account.id}" should be "${expected}" (provider + provider account ID)`,
    );
  }
}

/** Checks one photo against the catalog it is about to join. */
export function validatePhoto(photo: Photo, catalog: PhotoCatalog, expectedAccountId: AccountId): void {
  const account = catalog.accounts[photo.accountId];
  if (!account) {
    throw new CatalogValidationError(
      'unknown-account',
      `Photo "${photo.id}" refers to unknown account "${photo.accountId}"`,
    );
  }
  if (photo.accountId !== expectedAccountId) {
    throw new CatalogValidationError(
      'wrong-account',
      `Photo "${photo.id}" belongs to "${photo.accountId}" but was listed for "${expectedAccountId}"`,
    );
  }
  if (photo.provider !== account.provider) {
    throw new CatalogValidationError(
      'provider-mismatch',
      `Photo "${photo.id}" says provider "${photo.provider}" but its account is "${account.provider}"`,
    );
  }
  const expectedId = makePhotoId(photo.accountId, photo.providerPhotoId);
  if (photo.id !== expectedId) {
    throw new CatalogValidationError(
      'inconsistent-photo-id',
      `Photo ID "${photo.id}" should be "${expectedId}" (account ID + provider photo ID)`,
    );
  }
  if (catalog.photos[photo.id]) {
    throw new CatalogValidationError('duplicate-photo', `Photo ID "${photo.id}" was returned more than once`);
  }
}

/**
 * Builds the catalog (all accounts + their photo collections) by asking
 * each adapter for its accounts and paging through their photos.
 * Rejects anything inconsistent instead of silently overwriting it.
 */
export async function buildCatalog(
  adapters: PhotoSourceAdapter[],
  { signal, onProgress, maxPagesPerAccount = 10_000 }: BuildCatalogOptions = {},
): Promise<PhotoCatalog> {
  const catalog: PhotoCatalog = { accounts: {}, collections: {}, photos: {} };
  let listed = 0;

  for (const adapter of adapters.filter((a) => a.isAvailable())) {
    for (const account of await adapter.listAccounts()) {
      validateAccount(account);
      if (catalog.accounts[account.id]) {
        throw new CatalogValidationError(
          'duplicate-account',
          `Duplicate account ID "${account.id}" from adapter "${adapter.id}"`,
        );
      }
      catalog.accounts[account.id] = account;
      catalog.collections[account.id] = [];

      const seenCursors = new Set<string>();
      let cursor: string | undefined;
      let pages = 0;
      do {
        if (signal?.aborted) throw new CancelledError();
        if (++pages > maxPagesPerAccount) {
          throw new CatalogValidationError(
            'too-many-pages',
            `Account "${account.id}" returned more than ${maxPagesPerAccount} pages`,
          );
        }
        const page = await adapter.listPhotos(account.id, cursor);
        for (const photo of page.photos) {
          validatePhoto(photo, catalog, account.id);
          catalog.photos[photo.id] = photo;
          catalog.collections[account.id].push(photo.id);
        }
        listed += page.photos.length;
        onProgress?.(listed);

        cursor = page.nextCursor;
        if (cursor !== undefined) {
          if (seenCursors.has(cursor)) {
            throw new CatalogValidationError(
              'repeated-cursor',
              `Account "${account.id}" returned cursor "${cursor}" twice, which would loop forever`,
            );
          }
          seenCursors.add(cursor);
        }
      } while (cursor !== undefined);
    }
  }
  return catalog;
}

/** Human-friendly label that never depends on the email being present. */
export function accountLabel(account: SourceAccount): string {
  return account.email ?? `${providers[account.provider].label} (${account.displayName})`;
}

/** Short label for tight spaces: "Google Photos: Work", or "Phone library" for the device. */
export function accountShortName(account: SourceAccount): string {
  if (account.provider === 'device') return account.displayName;
  return `${providers[account.provider].label}: ${account.displayName}`;
}

/** All source details for one photo: provider, account ID, display name, email, label. */
export function resolvePhotoSource(photo: Photo, catalog: PhotoCatalog): PhotoSource {
  const account = catalog.accounts[photo.accountId];
  if (!account) throw new Error(`Unknown account "${photo.accountId}" for photo "${photo.id}"`);
  const info = providers[account.provider];
  return {
    provider: account.provider,
    providerLabel: info.label,
    accountId: account.id,
    accountDisplayName: account.displayName,
    email: account.email,
    label: accountLabel(account),
    deletionPolicy: info.deletionPolicy,
  };
}

export function getPhotos(catalog: PhotoCatalog, ids: PhotoId[]): Photo[] {
  return ids.map((id) => catalog.photos[id]).filter((p): p is Photo => Boolean(p));
}

/** Accounts sorted by provider order; accounts of the same provider keep the order they were added. */
export function listAccounts(catalog: PhotoCatalog, order: readonly string[]): SourceAccount[] {
  return Object.values(catalog.accounts).sort((a, b) => order.indexOf(a.provider) - order.indexOf(b.provider));
}

export function accountOf(catalog: PhotoCatalog, accountId: AccountId): SourceAccount | undefined {
  return catalog.accounts[accountId];
}
