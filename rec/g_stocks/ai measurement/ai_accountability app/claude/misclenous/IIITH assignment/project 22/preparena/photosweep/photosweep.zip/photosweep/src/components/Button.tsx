import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { ComponentProps } from 'react';
import { Platform, Pressable, StyleSheet, View, ViewStyle } from 'react-native';

import { colors, radius, spacing } from '@/theme';
import { AppText } from './AppText';

type Variant = 'primary' | 'secondary' | 'danger' | 'ghost' | 'onNight';
type Size = 'md' | 'lg';

interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: Variant;
  size?: Size;
  icon?: ComponentProps<typeof Feather>['name'];
  disabled?: boolean;
  style?: ViewStyle;
  accessibilityHint?: string;
}

const palette: Record<Variant, { bg: string; pressed: string; fg: string; border?: string }> = {
  primary: { bg: colors.accent, pressed: colors.accentPressed, fg: colors.onAccent },
  secondary: { bg: colors.card, pressed: colors.sunken, fg: colors.ink, border: colors.line },
  danger: { bg: colors.remove, pressed: '#B9372F', fg: '#FFFFFF' },
  ghost: { bg: 'transparent', pressed: colors.sunken, fg: colors.inkSoft },
  onNight: { bg: colors.onNight, pressed: '#D9DEE8', fg: colors.night },
};

/** Reusable button with a light tap vibration on phones. */
export function Button({
  label,
  onPress,
  variant = 'primary',
  size = 'md',
  icon,
  disabled,
  style,
  accessibilityHint,
}: ButtonProps) {
  const p = palette[variant];

  const handlePress = () => {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onPress();
  };

  return (
    <Pressable
      onPress={handlePress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityHint={accessibilityHint}
      accessibilityState={{ disabled }}
      style={({ pressed }) => [
        styles.base,
        size === 'lg' ? styles.lg : styles.md,
        { backgroundColor: pressed ? p.pressed : p.bg },
        p.border && { borderWidth: StyleSheet.hairlineWidth * 2, borderColor: p.border },
        disabled && styles.disabled,
        style,
      ]}
    >
      <View style={styles.row}>
        {icon && <Feather name={icon} size={size === 'lg' ? 20 : 17} color={p.fg} />}
        <AppText variant={size === 'lg' ? 'bodyStrong' : 'smallStrong'} style={{ color: p.fg }}>
          {label}
        </AppText>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: { borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
  md: { minHeight: 44, paddingHorizontal: spacing.md },
  lg: { minHeight: 58, paddingHorizontal: spacing.lg },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  disabled: { opacity: 0.45 },
});
