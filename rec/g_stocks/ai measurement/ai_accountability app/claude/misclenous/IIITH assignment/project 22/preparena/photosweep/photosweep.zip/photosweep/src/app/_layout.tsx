import {
  BricolageGrotesque_400Regular,
  BricolageGrotesque_600SemiBold,
  BricolageGrotesque_700Bold,
  BricolageGrotesque_800ExtraBold,
  useFonts,
} from '@expo-google-fonts/bricolage-grotesque';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { ScanProvider } from '@/state/ScanContext';
import { colors } from '@/theme';

/**
 * ROOT LAYOUT — the first file Expo Router loads.
 *
 * It wraps every screen with:
 * - SafeAreaProvider: knows where the notch / home bar are
 * - ScanProvider: our shared app state
 * - Stack: a navigator where each new screen slides in on top of the last
 *
 * Every file in this src/app folder is a screen. Its file name is its route:
 *   index.tsx   → "/"        Welcome
 *   home.tsx    → "/home"    Dashboard
 *   scan.tsx    → "/scan"    Scanning progress
 *   results.tsx → "/results" Duplicate groups
 *   confirm.tsx → "/confirm" Deletion confirmation (opens as a modal sheet)
 *   done.tsx    → "/done"    Outcome after confirming
 */

// Keep the splash screen visible until our fonts are ready.
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    BricolageGrotesque_400Regular,
    BricolageGrotesque_600SemiBold,
    BricolageGrotesque_700Bold,
    BricolageGrotesque_800ExtraBold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) SplashScreen.hideAsync();
  }, [fontsLoaded, fontError]);

  // If fonts fail, carry on with system fonts rather than showing a blank screen.
  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ScanProvider>
        <Stack
          screenOptions={{
            headerShown: false,
            contentStyle: { backgroundColor: colors.paper },
          }}
        >
          <Stack.Screen name="index" options={{ contentStyle: { backgroundColor: colors.night } }} />
          <Stack.Screen name="home" options={{ animation: 'fade' }} />
          <Stack.Screen
            name="scan"
            options={{ gestureEnabled: false, animation: 'fade', contentStyle: { backgroundColor: colors.night } }}
          />
          <Stack.Screen name="results" />
          <Stack.Screen name="confirm" options={{ presentation: 'modal' }} />
          <Stack.Screen name="done" options={{ gestureEnabled: false, animation: 'fade' }} />
        </Stack>
      </ScanProvider>
    </SafeAreaProvider>
  );
}
