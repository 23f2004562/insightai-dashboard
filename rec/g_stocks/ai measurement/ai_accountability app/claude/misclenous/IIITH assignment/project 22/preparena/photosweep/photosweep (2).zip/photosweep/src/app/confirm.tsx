import { Feather } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import { useState } from 'react';
import { Pressable, StyleSheet, useWindowDimensions, View } from 'react-native';

import { ActionBar, AppText, Button, PhotoThumb, SampleBadge, Screen, ScreenHeader } from '@/components';
import { useScan } from '@/state/ScanContext';
import { colors, radius, spacing } from '@/theme';
import { formatBytes, plural } from '@/utils/format';

/**
 * CONFIRM DELETION — the safety step.
 *
 * Opens as a modal sheet. The user sees every photo that would be removed
 * and must tick a checkbox before the button unlocks.
 * In this milestone the button does NOT delete anything.
 */
export default function ConfirmScreen() {
  const { markedPhotos, markedBytes } = useScan();
  const [checked, setChecked] = useState(false);
  const { width } = useWindowDimensions();

  if (markedPhotos.length === 0) return <Redirect href="/results" />;

  // 4 thumbnails per row, sized to the screen (capped for tablets).
  const contentWidth = Math.min(width, 640) - spacing.lg * 2;
  const thumb = Math.floor((contentWidth - spacing.sm * 3) / 4);
  const count = markedPhotos.length;

  return (
    <Screen
      scroll
      edges={['top', 'left', 'right']}
      footer={
        <ActionBar>
          <Button label="Cancel" variant="secondary" onPress={() => router.back()} />
          <Button
            label={`Delete ${plural(count, 'photo')}`}
            variant="danger"
            icon="trash-2"
            disabled={!checked}
            style={styles.flex}
            onPress={() => router.replace({ pathname: '/done', params: { count, bytes: markedBytes } })}
            accessibilityHint="Prototype only: shows what would happen. No photos are deleted."
          />
        </ActionBar>
      }
    >
      <ScreenHeader title="Review deletion" leading="close" />

      <View style={styles.summary}>
        <AppText variant="number" color="remove">
          {plural(count, 'photo')}
        </AppText>
        <AppText variant="body" color="inkSoft">
          {formatBytes(markedBytes)} would be freed. One copy of every group stays in your library.
        </AppText>
      </View>

      <SampleBadge
        kind="banner"
        message="This is a prototype using sample photos. Confirming will not delete anything from any device or account."
      />

      <View style={styles.grid}>
        {markedPhotos.map((p) => (
          <PhotoThumb key={p.id} photo={p} size={thumb} decision="delete" />
        ))}
      </View>

      <View style={styles.info}>
        <Feather name="rotate-ccw" size={18} color={colors.inkSoft} style={styles.infoIcon} />
        <AppText variant="small" color="inkSoft" style={styles.flex}>
          In the finished app, deleted photos will go to each library's Recently Deleted folder, where they can
          be restored for a limited time.
        </AppText>
      </View>

      <Pressable
        onPress={() => setChecked((c) => !c)}
        style={styles.check}
        accessibilityRole="checkbox"
        accessibilityState={{ checked }}
      >
        <View style={[styles.box, checked && styles.boxOn]}>
          {checked && <Feather name="check" size={16} color="#FFFFFF" />}
        </View>
        <AppText variant="bodyStrong" style={styles.flex}>
          I've looked through these {plural(count, 'photo')} and want to delete them
        </AppText>
      </Pressable>
    </Screen>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  summary: { gap: spacing.xxs, marginBottom: spacing.md },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.lg },
  info: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.lg },
  infoIcon: { marginTop: 1 },
  check: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.lg,
    padding: spacing.md,
    backgroundColor: colors.card,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  box: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: colors.inkFaint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  boxOn: { backgroundColor: colors.remove, borderColor: colors.remove },
});
