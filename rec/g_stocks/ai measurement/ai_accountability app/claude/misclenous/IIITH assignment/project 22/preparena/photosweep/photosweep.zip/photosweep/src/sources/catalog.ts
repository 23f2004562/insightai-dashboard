import { AccountId, Photo, PhotoCatalog, PhotoId, PhotoSource, SourceAccount } from '@/types';
import { PhotoSourceAdapter } from './adapter';
import { providers } from './providers';

/**
 * Builds the catalog (all accounts + their photo collections) by asking
 * each adapter for its accounts and paging through their photos.
 * The same function will work unchanged once real adapters exist.
 */
export async function buildCatalog(adapters: PhotoSourceAdapter[]): Promise<PhotoCatalog> {
  const catalog: PhotoCatalog = { accounts: {}, collections: {}, photos: {} };

  for (const adapter of adapters.filter((a) => a.isAvailable())) {
    for (const account of await adapter.listAccounts()) {
      if (catalog.accounts[account.id]) {
        throw new Error(`Duplicate account ID "${account.id}" from adapter "${adapter.id}"`);
      }
      catalog.accounts[account.id] = account;
      catalog.collections[account.id] = [];

      let cursor: string | undefined;
      do {
        const page = await adapter.listPhotos(account.id, cursor);
        for (const photo of page.photos) {
          if (photo.accountId !== account.id) {
            throw new Error(`Photo "${photo.id}" returned for the wrong account`);
          }
          catalog.photos[photo.id] = photo;
          catalog.collections[account.id].push(photo.id);
        }
        cursor = page.nextCursor;
      } while (cursor);
    }
  }
  return catalog;
}

/** Human-friendly label that never depends on the email being present. */
export function accountLabel(account: SourceAccount): string {
  return account.email ?? `${providers[account.provider].label} (${account.displayName})`;
}

/** Short label for tight spaces: "Google Photos: Work", or "Phone library" for the device. */
export function accountShortName(account: SourceAccount): string {
  if (account.provider === 'device') return account.displayName;
  return `${providers[account.provider].label}: ${account.displayName}`;
}

/** All source details for one photo: provider, account ID, display name, email, label. */
export function resolvePhotoSource(photo: Photo, catalog: PhotoCatalog): PhotoSource {
  const account = catalog.accounts[photo.accountId];
  if (!account) throw new Error(`Unknown account "${photo.accountId}" for photo "${photo.id}"`);
  const info = providers[account.provider];
  return {
    provider: account.provider,
    providerLabel: info.label,
    accountId: account.id,
    accountDisplayName: account.displayName,
    email: account.email,
    label: accountLabel(account),
    deletionPolicy: info.deletionPolicy,
  };
}

export function getPhotos(catalog: PhotoCatalog, ids: PhotoId[]): Photo[] {
  return ids.map((id) => catalog.photos[id]).filter((p): p is Photo => Boolean(p));
}

/** Accounts sorted by provider order; accounts of the same provider keep the order they were added. */
export function listAccounts(catalog: PhotoCatalog, order: readonly string[]): SourceAccount[] {
  return Object.values(catalog.accounts).sort((a, b) => order.indexOf(a.provider) - order.indexOf(b.provider));
}

export function accountOf(catalog: PhotoCatalog, accountId: AccountId): SourceAccount | undefined {
  return catalog.accounts[accountId];
}
