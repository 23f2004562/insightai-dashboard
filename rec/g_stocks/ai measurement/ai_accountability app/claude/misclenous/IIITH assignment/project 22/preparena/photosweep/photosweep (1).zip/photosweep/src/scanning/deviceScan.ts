import { buildCatalog, CancelSignal } from '@/sources/catalog';
import { createDeviceAdapter } from '@/sources/device/deviceAdapter';
import { ScanSummary } from '@/types';
import { findExactDuplicates, ScanProgress } from './exactDuplicates';

/**
 * A REAL scan of this phone's photo library.
 * Everything happens on the device. Nothing is uploaded or deleted.
 */

export type DeviceScanProgress = { phase: 'listing'; photosListed: number } | ScanProgress;

export interface DeviceScanOptions {
  /** True when the user only shared selected photos. */
  limitedAccess: boolean;
  signal?: CancelSignal;
  onProgress?: (p: DeviceScanProgress) => void;
}

export async function runDeviceScan({ limitedAccess, signal, onProgress }: DeviceScanOptions): Promise<ScanSummary> {
  const adapter = createDeviceAdapter();

  // 1. List photos, a page at a time (metadata only).
  onProgress?.({ phase: 'listing', photosListed: 0 });
  const catalog = await buildCatalog([adapter], {
    signal,
    onProgress: (photosListed) => onProgress?.({ phase: 'listing', photosListed }),
  });
  for (const id of Object.keys(catalog.accounts)) {
    catalog.accounts[id] = { ...catalog.accounts[id], totalPhotos: catalog.collections[id].length };
  }

  // 2–3. Sizes, then SHA-256 of originals that share a size, then exact groups.
  const result = await findExactDuplicates(catalog, () => adapter, { signal, onProgress });

  return {
    source: 'device-scan',
    totalPhotosScanned: result.stats.photosListed,
    catalog: { ...catalog, photos: result.photos },
    groups: result.groups,
    completedAt: new Date().toISOString(),
    stats: { ...result.stats, limitedAccess },
  };
}
