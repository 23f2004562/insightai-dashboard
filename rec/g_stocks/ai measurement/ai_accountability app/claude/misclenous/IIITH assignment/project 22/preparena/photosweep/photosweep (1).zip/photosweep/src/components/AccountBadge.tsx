import { Feather } from '@expo/vector-icons';
import { StyleSheet, View } from 'react-native';

import { accountLabel, accountShortName, providers } from '@/sources';
import { colors, radius, spacing } from '@/theme';
import { SourceAccount } from '@/types';
import { AppText } from './AppText';

interface AccountBadgeProps {
  account: SourceAccount;
  /** compact = one line for thumbnails; full = name + email row for headers and lists */
  variant?: 'compact' | 'full';
}

/** Shows which account a photo or list belongs to: provider icon, account name, email or fallback label. */
export function AccountBadge({ account, variant = 'compact' }: AccountBadgeProps) {
  const info = providers[account.provider];

  if (variant === 'compact' && account.provider === 'device') {
    // Device libraries have one, longer name ("Photos on this iPhone"): show it whole, no provider line.
    return (
      <View style={styles.compactDevice}>
        <Feather name={info.icon} size={11} color={colors.inkSoft} style={styles.deviceIcon} />
        <AppText variant="caption" color="ink" numberOfLines={2} style={[styles.compactText, styles.flexShrink]}>
          {account.displayName}
        </AppText>
      </View>
    );
  }

  if (variant === 'compact') {
    return (
      <View>
        <View style={styles.compact}>
          <Feather name={info.icon} size={11} color={colors.inkSoft} />
          <AppText variant="caption" color="inkSoft" numberOfLines={1} style={styles.flexShrink}>
            {info.label}
          </AppText>
        </View>
        <AppText variant="caption" color="ink" numberOfLines={1} style={styles.compactText}>
          {account.displayName}
        </AppText>
      </View>
    );
  }

  return (
    <View style={styles.full}>
      <View style={[styles.icon, info.kind === 'cloud' ? styles.iconCloud : styles.iconDevice]}>
        <Feather name={info.icon} size={17} color={colors.ink} />
      </View>
      <View style={styles.fullText}>
        <AppText variant="bodyStrong" numberOfLines={1}>
          {accountShortName(account)}
        </AppText>
        <AppText variant="small" color="inkSoft" numberOfLines={1}>
          {account.provider === 'device' ? 'On this phone' : account.email ?? 'Email not shared'}
        </AppText>
      </View>
    </View>
  );
}

/** Accessible one-line description, e.g. for screen readers and notices. */
export function describeAccount(account: SourceAccount): string {
  return account.provider === 'device' ? account.displayName : `${accountShortName(account)} (${accountLabel(account)})`;
}

const styles = StyleSheet.create({
  compact: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  compactDevice: { flexDirection: 'row', alignItems: 'flex-start', gap: 4 },
  deviceIcon: { marginTop: 2 },
  compactText: { fontWeight: '600' },
  flexShrink: { flexShrink: 1 },
  full: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, flex: 1 },
  fullText: { flex: 1, gap: 1 },
  icon: { width: 36, height: 36, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
  iconDevice: { backgroundColor: colors.paper },
  iconCloud: { backgroundColor: colors.cloudTint },
});
