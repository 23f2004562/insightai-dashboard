import { Feather } from '@expo/vector-icons';
import { router, useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { AccountBadge, AppText, Button, SampleBadge, Screen, StatFigure } from '@/components';
import { LibraryAccess } from '@/scanning/permissions';
import { getPhotos, listAccounts, providerOrder, providers } from '@/sources';
import { checkLibraryAccess } from '@/sources/device/permissions';
import { potentialSavings, splitByDeletionPolicy, totalBytes } from '@/state/selection';
import { useScan } from '@/state/ScanContext';
import { colors, radius, spacing } from '@/theme';
import { ProviderId } from '@/types';
import { formatBytes, formatCount, plural } from '@/utils/format';

/** HOME DASHBOARD */

// Honest status for each provider before any scan.
const notConnectedStatus: Record<Exclude<ProviderId, 'device'>, string> = {
  google_photos: 'Sign-in coming in a later version',
  icloud: 'On iPhone, iCloud photos are included in the phone scan',
  onedrive: 'Sign-in coming in a later version',
};

const deviceStatus: Record<LibraryAccess, string> = {
  undetermined: 'Access not requested yet',
  all: 'Access to all photos',
  limited: 'Access to selected photos only',
  denied: 'Access declined',
  blocked: 'Access turned off in Settings',
  unavailable: 'Available in the iOS and Android app',
};

export default function HomeScreen() {
  const { summary, markedPhotos } = useScan();
  const [access, setAccess] = useState<LibraryAccess | null>(null);

  // Read (never request) the current photo permission whenever the dashboard is shown.
  useFocusEffect(
    useCallback(() => {
      checkLibraryAccess()
        .then(setAccess)
        .catch(() => setAccess('unavailable'));
    }, []),
  );

  const isSample = summary?.source === 'sample';
  const isReal = summary !== null && !isSample;
  const savings = summary ? potentialSavings(summary.groups, summary.catalog) : 0;
  const duplicatePhotos = summary ? summary.groups.reduce((n, g) => n + g.photoIds.length, 0) : 0;

  // Sample: split suggested savings into phone vs cloud. Real: space taken by extra copies.
  const suggestedRemovals = summary
    ? summary.groups.flatMap((g) =>
        getPhotos(
          summary.catalog,
          g.photoIds.filter((id) => id !== g.suggestedKeepId),
        ),
      )
    : [];
  const split = splitByDeletionPolicy(suggestedRemovals);
  const accounts = summary ? listAccounts(summary.catalog, providerOrder) : [];

  return (
    <Screen scroll>
      <View style={styles.header}>
        <AppText variant="title">Library overview</AppText>
        {isSample && <SampleBadge />}
        {isReal && (
          <View style={styles.realBadge}>
            <Feather name="smartphone" size={12} color={colors.keep} />
            <AppText variant="caption" style={styles.realBadgeText}>
              Real scan of this phone
            </AppText>
          </View>
        )}
      </View>

      <View style={styles.panel}>
        {summary && isSample && (
          <>
            <StatFigure size="large" color="keep" value={formatBytes(savings)} label="Potential storage savings" />
            <AppText variant="small" color="inkSoft" style={styles.splitLine}>
              {formatBytes(totalBytes(split.device))} on this phone, {formatBytes(totalBytes(split.cloud))} in cloud
              accounts
            </AppText>
          </>
        )}
        {summary && isReal && (
          <>
            <StatFigure
              size="large"
              color="keep"
              value={formatBytes(totalBytes(suggestedRemovals))}
              label="Taken by extra copies of identical photos"
            />
            <AppText variant="small" color="inkSoft" style={styles.splitLine}>
              Review only. Nothing has been deleted and no space has been freed.
            </AppText>
          </>
        )}
        {summary ? (
          <>
            <View style={styles.divider} />
            <View style={styles.row}>
              <StatFigure
                value={formatCount(summary.totalPhotosScanned)}
                label={isReal ? 'Photos found' : 'Photos scanned'}
              />
              <View style={styles.vDivider} />
              <StatFigure
                value={formatCount(summary.groups.length)}
                label={isReal ? 'Exact duplicate groups' : 'Duplicate groups'}
              />
            </View>
          </>
        ) : (
          <View style={styles.empty}>
            <AppText variant="heading">No scan yet</AppText>
            <AppText variant="small" color="inkSoft">
              Scan this phone to find photos that are exact, byte-for-byte copies. Everything stays on your phone, and
              nothing is deleted. Or try the sample demo to explore every feature with invented accounts.
            </AppText>
            <View style={styles.row}>
              <StatFigure value="–" label="Photos found" />
              <View style={styles.vDivider} />
              <StatFigure value="–" label="Duplicate groups" />
            </View>
          </View>
        )}
      </View>

      <Button
        label={isReal ? 'Scan this phone again' : 'Scan this phone'}
        icon="smartphone"
        size="lg"
        onPress={() => router.push('/permission')}
        accessibilityHint="Explains photo access first. Nothing is requested until you choose."
        style={styles.scanButton}
      />
      <Button
        label={isSample ? 'Run the sample demo again' : 'Try the sample demo'}
        icon="play"
        variant="secondary"
        onPress={() => router.push('/scan')}
        accessibilityHint="Runs a demo scan with invented accounts and photos"
        style={styles.demoButton}
      />

      {summary && (
        <Pressable
          onPress={() => router.push('/results')}
          style={({ pressed }) => [styles.resultsLink, pressed && { backgroundColor: colors.sunken }]}
          accessibilityRole="button"
        >
          <View style={styles.flex}>
            <AppText variant="bodyStrong">{isReal ? 'Review exact duplicates' : 'Review duplicates'}</AppText>
            <AppText variant="small" color="inkSoft">
              {summary.groups.length === 0
                ? 'No exact duplicates found'
                : `${plural(duplicatePhotos, 'photo')} in ${plural(summary.groups.length, 'group')}`}
              {markedPhotos.length > 0 ? `, ${markedPhotos.length} marked` : ''}
            </AppText>
          </View>
          <Feather name="chevron-right" size={22} color={colors.inkFaint} />
        </Pressable>
      )}

      <AppText variant="heading" style={styles.sectionTitle}>
        Accounts
      </AppText>

      {summary ? (
        <View style={styles.list}>
          {accounts.map((a, i) => (
            <View key={a.id} style={[styles.listRow, i > 0 && styles.rowBorder]}>
              <AccountBadge account={a} variant="full" />
              {a.totalPhotos !== undefined && (
                <AppText variant="small" color="inkSoft">
                  {plural(a.totalPhotos, 'photo')}
                </AppText>
              )}
            </View>
          ))}
        </View>
      ) : (
        <View style={styles.list}>
          {providerOrder.map((id, i) => (
            <View key={id} style={[styles.listRow, i > 0 && styles.rowBorder]}>
              <View style={styles.libIcon}>
                <Feather name={providers[id].icon} size={17} color={colors.inkSoft} />
              </View>
              <View style={styles.flex}>
                <AppText variant="bodyStrong">{providers[id].label}</AppText>
                <AppText variant="small" color="inkFaint">
                  {id === 'device' ? (access ? deviceStatus[access] : ' ') : notConnectedStatus[id]}
                </AppText>
              </View>
            </View>
          ))}
        </View>
      )}
      <AppText variant="caption" color="inkFaint" style={styles.footnote}>
        You'll be able to add several accounts from the same service, such as a personal and a work Google account.
      </AppText>
    </Screen>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, gap: 2 },
  header: { paddingTop: spacing.lg, paddingBottom: spacing.lg, gap: spacing.xs },
  panel: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.lg,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  splitLine: { marginTop: spacing.xs },
  divider: { height: StyleSheet.hairlineWidth * 2, backgroundColor: colors.line, marginVertical: spacing.lg },
  row: { flexDirection: 'row', alignItems: 'stretch', gap: spacing.lg },
  vDivider: { width: StyleSheet.hairlineWidth * 2, backgroundColor: colors.line },
  empty: { gap: spacing.md },
  scanButton: { marginTop: spacing.lg },
  demoButton: { marginTop: spacing.sm },
  realBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'flex-start',
    backgroundColor: colors.keepTint,
    paddingHorizontal: spacing.xs,
    paddingVertical: 3,
    borderRadius: radius.pill,
  },
  realBadgeText: { color: colors.keep, fontWeight: '600' },
  resultsLink: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.md,
  },
  sectionTitle: { marginTop: spacing.xl, marginBottom: spacing.sm },
  list: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  listRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, padding: spacing.md },
  rowBorder: { borderTopWidth: StyleSheet.hairlineWidth * 2, borderTopColor: colors.line },
  libIcon: {
    width: 36,
    height: 36,
    borderRadius: radius.md,
    backgroundColor: colors.paper,
    alignItems: 'center',
    justifyContent: 'center',
  },
  footnote: { marginTop: spacing.sm },
});
