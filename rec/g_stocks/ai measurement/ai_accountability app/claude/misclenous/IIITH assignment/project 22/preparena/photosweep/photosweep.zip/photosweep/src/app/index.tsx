import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { ComponentProps } from 'react';
import { StyleSheet, View } from 'react-native';

import { AppText, Button, PhotoStack, Screen } from '@/components';
import { colors, spacing } from '@/theme';

/** WELCOME SCREEN — first thing people see. */

const promises: { icon: ComponentProps<typeof Feather>['name']; text: string }[] = [
  { icon: 'layers', text: 'Finds copies and look-alikes across your phone and all your cloud accounts' },
  { icon: 'shield', text: 'Nothing is deleted until you review and confirm' },
  { icon: 'smartphone', text: 'Photos are compared on your phone, never uploaded' },
];

export default function WelcomeScreen() {
  return (
    <Screen tone="night" edges={['top', 'bottom', 'left', 'right']} contentStyle={styles.content}>
      <View style={styles.brand}>
        <View style={styles.logo}>
          <Feather name="copy" size={14} color={colors.night} />
        </View>
        <AppText variant="bodyStrong" color="onNight">
          PhotoSweep
        </AppText>
      </View>

      <View style={styles.hero}>
        <PhotoStack />
      </View>

      <View style={styles.copy}>
        <AppText variant="hero" color="onNight">
          Keep the best.{'\n'}Let the copies go.
        </AppText>
        <View style={styles.promises}>
          {promises.map((p) => (
            <View key={p.icon} style={styles.promise}>
              <Feather name={p.icon} size={18} color={colors.onNightSoft} style={styles.promiseIcon} />
              <AppText variant="small" color="onNightSoft" style={styles.promiseText}>
                {p.text}
              </AppText>
            </View>
          ))}
        </View>
      </View>

      <Button
        label="Get started"
        variant="onNight"
        size="lg"
        onPress={() => router.replace('/home')}
        accessibilityHint="Opens the dashboard. No permissions are requested."
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { justifyContent: 'space-between', paddingTop: spacing.md, paddingBottom: spacing.md },
  brand: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  logo: {
    width: 26,
    height: 26,
    borderRadius: 7,
    backgroundColor: colors.onNight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  hero: { flex: 1, justifyContent: 'center', minHeight: 260 },
  copy: { gap: spacing.lg, marginBottom: spacing.xl },
  promises: { gap: spacing.sm },
  promise: { flexDirection: 'row', gap: spacing.sm },
  promiseIcon: { marginTop: 1 },
  promiseText: { flex: 1 },
});
