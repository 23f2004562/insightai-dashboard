import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { ReactNode } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { colors, radius, spacing } from '@/theme';
import { AppText } from './AppText';

interface ScreenHeaderProps {
  title: string;
  /** 'back' shows a chevron, 'close' shows an X (for modals). */
  leading?: 'back' | 'close';
  trailing?: ReactNode;
}

/** Simple top bar with a back/close button and a large title below it. */
export function ScreenHeader({ title, leading = 'back', trailing }: ScreenHeaderProps) {
  return (
    <View style={styles.wrap}>
      <View style={styles.bar}>
        <Pressable
          onPress={() => (router.canGoBack() ? router.back() : router.replace('/home'))}
          hitSlop={12}
          style={({ pressed }) => [styles.iconBtn, pressed && { backgroundColor: colors.sunken }]}
          accessibilityRole="button"
          accessibilityLabel={leading === 'back' ? 'Go back' : 'Close'}
        >
          <Feather name={leading === 'back' ? 'chevron-left' : 'x'} size={24} color={colors.ink} />
        </Pressable>
        {trailing}
      </View>
      <AppText variant="title" accessibilityRole="header">
        {title}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { paddingTop: spacing.xs, paddingBottom: spacing.md, gap: spacing.sm },
  bar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginLeft: -spacing.xs },
  iconBtn: { width: 40, height: 40, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
});
