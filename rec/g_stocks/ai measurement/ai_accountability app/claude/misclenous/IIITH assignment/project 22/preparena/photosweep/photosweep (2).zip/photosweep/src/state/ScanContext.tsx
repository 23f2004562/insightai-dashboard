import { createContext, ReactNode, useCallback, useContext, useMemo, useState } from 'react';

import { createSampleSummary } from '@/data/sampleData';
import { Photo, ScanSummary } from '@/types';
import {
  Decisions,
  decisionFor,
  markedForDeletion,
  suggestedDecisions,
  totalBytes,
  wouldDeleteLastCopy,
} from './selection';

/**
 * Shared app state, available to every screen.
 *
 * WHY CONTEXT? The Results screen sets keep/delete choices and the Confirm
 * screen needs to read them. React Context lets both screens share the same
 * data without passing it through every component in between.
 *
 * Nothing here touches the real photo library — it only holds sample data
 * and the user's choices in memory. Closing the app resets everything.
 */

export type ToggleResult = 'ok' | 'blocked-last-copy';

interface ScanContextValue {
  /** null until a (demo) scan has finished. */
  summary: ScanSummary | null;
  decisions: Decisions;
  markedPhotos: Photo[];
  markedBytes: number;

  loadSampleResults: () => void;
  togglePhoto: (groupId: string, photoId: string) => ToggleResult;
  applySuggestion: (groupId: string) => void;
  applyAllSuggestions: () => void;
  clearDecisions: () => void;
}

const ScanContext = createContext<ScanContextValue | null>(null);

export function ScanProvider({ children }: { children: ReactNode }) {
  const [summary, setSummary] = useState<ScanSummary | null>(null);
  const [decisions, setDecisions] = useState<Decisions>({});

  const loadSampleResults = useCallback(() => {
    setSummary(createSampleSummary());
    setDecisions({}); // start with everything kept — the user decides
  }, []);

  const togglePhoto = useCallback(
    (groupId: string, photoId: string): ToggleResult => {
      const group = summary?.groups.find((g) => g.id === groupId);
      if (!group) return 'ok';

      const current = decisionFor(decisions, photoId);
      if (current === 'keep' && wouldDeleteLastCopy(group, decisions, photoId)) {
        return 'blocked-last-copy';
      }
      setDecisions((prev) => ({ ...prev, [photoId]: current === 'keep' ? 'delete' : 'keep' }));
      return 'ok';
    },
    [summary, decisions],
  );

  const applySuggestion = useCallback(
    (groupId: string) => {
      const group = summary?.groups.find((g) => g.id === groupId);
      if (group) setDecisions((prev) => ({ ...prev, ...suggestedDecisions(group) }));
    },
    [summary],
  );

  const applyAllSuggestions = useCallback(() => {
    if (!summary) return;
    const all = summary.groups.reduce<Decisions>((acc, g) => ({ ...acc, ...suggestedDecisions(g) }), {});
    setDecisions(all);
  }, [summary]);

  const clearDecisions = useCallback(() => setDecisions({}), []);

  // useMemo recalculates these only when summary or decisions change.
  const value = useMemo<ScanContextValue>(() => {
    const markedPhotos = summary ? markedForDeletion(summary.groups, decisions) : [];
    return {
      summary,
      decisions,
      markedPhotos,
      markedBytes: totalBytes(markedPhotos),
      loadSampleResults,
      togglePhoto,
      applySuggestion,
      applyAllSuggestions,
      clearDecisions,
    };
  }, [summary, decisions, loadSampleResults, togglePhoto, applySuggestion, applyAllSuggestions, clearDecisions]);

  return <ScanContext.Provider value={value}>{children}</ScanContext.Provider>;
}

/** Hook every screen uses: const { summary } = useScan(); */
export function useScan(): ScanContextValue {
  const ctx = useContext(ScanContext);
  if (!ctx) throw new Error('useScan must be used inside <ScanProvider>');
  return ctx;
}
