import { Platform, TextStyle } from 'react-native';

/**
 * Typography.
 *
 * - Display text (titles, big numbers) uses Bricolage Grotesque, loaded in
 *   src/app/_layout.tsx. It gives the app its personality.
 * - Body text uses the phone's own system font (San Francisco on iOS,
 *   Roboto on Android), which is the most legible choice at small sizes.
 */
export const fonts = {
  displayRegular: 'BricolageGrotesque_400Regular',
  displayMedium: 'BricolageGrotesque_600SemiBold',
  displayBold: 'BricolageGrotesque_700Bold',
  displayHeavy: 'BricolageGrotesque_800ExtraBold',
  body: Platform.select({ ios: 'System', default: undefined }),
};

/**
 * Named text styles. Components refer to these by name
 * (e.g. <AppText variant="title">) so sizes stay consistent everywhere.
 */
export const textVariants = {
  hero: { fontFamily: fonts.displayHeavy, fontSize: 40, lineHeight: 43, letterSpacing: -1.1 },
  title: { fontFamily: fonts.displayBold, fontSize: 30, lineHeight: 34, letterSpacing: -0.6 },
  heading: { fontFamily: fonts.displayMedium, fontSize: 20, lineHeight: 26, letterSpacing: -0.2 },
  number: { fontFamily: fonts.displayBold, fontSize: 34, lineHeight: 38, letterSpacing: -0.8 },
  body: { fontFamily: fonts.body, fontSize: 16, lineHeight: 23 },
  bodyStrong: { fontFamily: fonts.body, fontSize: 16, lineHeight: 23, fontWeight: '600' },
  small: { fontFamily: fonts.body, fontSize: 14, lineHeight: 20 },
  smallStrong: { fontFamily: fonts.body, fontSize: 14, lineHeight: 20, fontWeight: '600' },
  caption: { fontFamily: fonts.body, fontSize: 12, lineHeight: 16 },
} satisfies Record<string, TextStyle>;

export type TextVariant = keyof typeof textVariants;
