import { StyleSheet, View } from 'react-native';

import { ColorName, spacing } from '@/theme';
import { AppText } from './AppText';

interface StatFigureProps {
  value: string;
  label: string;
  size?: 'large' | 'regular';
  color?: ColorName;
}

/** A number with a short label underneath. Used on the dashboard and summary screens. */
export function StatFigure({ value, label, size = 'regular', color = 'ink' }: StatFigureProps) {
  return (
    <View style={styles.wrap} accessible accessibilityLabel={`${label}: ${value}`}>
      <AppText
        variant={size === 'large' ? 'hero' : 'number'}
        color={color}
        numberOfLines={1}
        adjustsFontSizeToFit
      >
        {value}
      </AppText>
      <AppText variant="small" color="inkSoft">
        {label}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: spacing.xxs, flexShrink: 1 },
});
