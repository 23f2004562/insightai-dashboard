import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { ComponentProps } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { AppText, Button, SampleBadge, Screen, StatFigure } from '@/components';
import { sampleLibraries } from '@/data/sampleData';
import { potentialSavings } from '@/state/selection';
import { useScan } from '@/state/ScanContext';
import { colors, radius, spacing } from '@/theme';
import { LibraryKind } from '@/types';
import { formatBytes, formatCount, plural } from '@/utils/format';

/** HOME DASHBOARD */

const libraryIcon: Record<LibraryKind, ComponentProps<typeof Feather>['name']> = {
  device: 'smartphone',
  cloud: 'cloud',
  shared: 'users',
};

// Honest status for each library: none are connected in this milestone.
const libraryStatus: Record<LibraryKind, string> = {
  device: 'Access not requested yet',
  cloud: 'Sign-in coming in a later version',
  shared: 'Sign-in coming in a later version',
};

export default function HomeScreen() {
  const { summary, markedPhotos } = useScan();
  const savings = summary ? potentialSavings(summary.groups) : 0;
  const duplicatePhotos = summary ? summary.groups.reduce((n, g) => n + g.photos.length, 0) : 0;

  return (
    <Screen scroll>
      <View style={styles.header}>
        <AppText variant="title">Library overview</AppText>
        {summary && <SampleBadge />}
      </View>

      {/* Summary panel: one panel, with savings as the lead number */}
      <View style={styles.panel}>
        {summary ? (
          <>
            <StatFigure size="large" color="keep" value={formatBytes(savings)} label="Potential storage savings" />
            <View style={styles.divider} />
            <View style={styles.row}>
              <StatFigure value={formatCount(summary.totalPhotosScanned)} label="Photos scanned" />
              <View style={styles.vDivider} />
              <StatFigure value={formatCount(summary.groups.length)} label="Duplicate groups" />
            </View>
          </>
        ) : (
          <View style={styles.empty}>
            <AppText variant="heading">No scan yet</AppText>
            <AppText variant="small" color="inkSoft">
              Run a scan to see how many duplicates you have and how much space you could free up. In this
              prototype, the scan is a demo that uses sample photos.
            </AppText>
            <View style={styles.row}>
              <StatFigure value="–" label="Photos scanned" />
              <View style={styles.vDivider} />
              <StatFigure value="–" label="Duplicate groups" />
            </View>
          </View>
        )}
      </View>

      <Button
        label={summary ? 'Scan again' : 'Scan photos'}
        icon="search"
        size="lg"
        onPress={() => router.push('/scan')}
        accessibilityHint="Runs a demo scan with sample photos"
        style={styles.scanButton}
      />

      {summary && (
        <Pressable
          onPress={() => router.push('/results')}
          style={({ pressed }) => [styles.resultsLink, pressed && { backgroundColor: colors.sunken }]}
          accessibilityRole="button"
        >
          <View style={styles.resultsText}>
            <AppText variant="bodyStrong">Review duplicates</AppText>
            <AppText variant="small" color="inkSoft">
              {plural(duplicatePhotos, 'photo')} in {plural(summary.groups.length, 'group')}
              {markedPhotos.length > 0 ? `, ${markedPhotos.length} marked to delete` : ''}
            </AppText>
          </View>
          <Feather name="chevron-right" size={22} color={colors.inkFaint} />
        </Pressable>
      )}

      <AppText variant="heading" style={styles.sectionTitle}>
        Libraries
      </AppText>
      <View style={styles.libraries}>
        {sampleLibraries.map((lib, i) => (
          <View key={lib.id} style={[styles.library, i > 0 && styles.libraryBorder]}>
            <View style={styles.libIcon}>
              <Feather name={libraryIcon[lib.kind]} size={18} color={colors.inkSoft} />
            </View>
            <View style={styles.resultsText}>
              <AppText variant="bodyStrong">{lib.name}</AppText>
              <AppText variant="small" color="inkFaint">
                {libraryStatus[lib.kind]}
              </AppText>
            </View>
          </View>
        ))}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { paddingTop: spacing.lg, paddingBottom: spacing.lg, gap: spacing.xs },
  panel: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.lg,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  divider: { height: StyleSheet.hairlineWidth * 2, backgroundColor: colors.line, marginVertical: spacing.lg },
  row: { flexDirection: 'row', alignItems: 'stretch', gap: spacing.lg },
  vDivider: { width: StyleSheet.hairlineWidth * 2, backgroundColor: colors.line },
  empty: { gap: spacing.md },
  scanButton: { marginTop: spacing.lg },
  resultsLink: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.md,
  },
  resultsText: { flex: 1, gap: 2 },
  sectionTitle: { marginTop: spacing.xl, marginBottom: spacing.sm },
  libraries: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  library: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, padding: spacing.md },
  libraryBorder: { borderTopWidth: StyleSheet.hairlineWidth * 2, borderTopColor: colors.line },
  libIcon: {
    width: 36,
    height: 36,
    borderRadius: radius.md,
    backgroundColor: colors.paper,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
