import { sampleAccounts, samplePhotos } from '@/data/sampleData';
import { AccountId } from '@/types';
import { PhotoPage, PhotoSourceAdapter } from '../adapter';

const PAGE_SIZE = 5; // small on purpose, so paging is exercised even with sample data

/**
 * Serves the invented sample accounts and photos through the real adapter
 * interface. It has no requestDeletion(), so it can never delete anything.
 */
export const sampleAdapter: PhotoSourceAdapter = {
  id: 'sample',
  providers: ['device', 'google_photos', 'icloud', 'onedrive'],

  isAvailable: () => true,

  async listAccounts() {
    return sampleAccounts.map((a) => ({ ...a }));
  },

  async listPhotos(accountId: AccountId, cursor?: string): Promise<PhotoPage> {
    const all = samplePhotos.filter((p) => p.accountId === accountId);
    const start = cursor ? Number(cursor) : 0;
    const end = start + PAGE_SIZE;
    return {
      photos: all.slice(start, end),
      nextCursor: end < all.length ? String(end) : undefined,
    };
  },
};
