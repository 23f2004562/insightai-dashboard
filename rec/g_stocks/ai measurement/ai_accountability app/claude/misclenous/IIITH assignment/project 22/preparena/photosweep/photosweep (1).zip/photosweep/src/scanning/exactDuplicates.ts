import { PhotoSourceAdapter } from '@/sources/adapter';
import { CancelledError, CancelSignal } from '@/sources/catalog';
import { DuplicateGroup, HashFailureReason, Photo, PhotoCatalog, PhotoId, ScanStats } from '@/types';

/**
 * EXACT DUPLICATE DETECTION
 *
 * 1. Size check: read each original's exact byte size (no file contents).
 *    Two files of different sizes can never be byte-identical, so only photos
 *    that share a size with another photo need hashing. A matching size is
 *    NOT treated as proof of anything; it only decides what to hash.
 * 2. Hash: SHA-256 of the full original bytes, one file at a time. The device
 *    adapter uses expo-file-system's native File.digest('SHA-256'), which
 *    streams the file in 64 KB chunks off the JavaScript thread.
 * 3. Group: photos are grouped ONLY when their content hashes are equal.
 *
 * Filenames, dates and dimensions are never used to decide a match.
 */

export type ScanProgress =
  | { phase: 'sizing'; done: number; total: number }
  | { phase: 'hashing'; filesDone: number; filesTotal: number; bytesDone: number; bytesTotal: number };

export interface ExactScanOptions {
  signal?: CancelSignal;
  onProgress?: (p: ScanProgress) => void;
  /** How many size lookups run at once. Hashing is always one file at a time. */
  sizeConcurrency?: number;
}

export interface ExactScanResult {
  /** Photos with updated sizeBytes, availability and hash state. */
  photos: Record<PhotoId, Photo>;
  groups: DuplicateGroup[];
  stats: Omit<ScanStats, 'limitedAccess'>;
}

function emptyFailures(): Record<HashFailureReason, number> {
  return { 'cloud-only': 0, unreadable: 0, 'not-supported': 0 };
}

/** Runs `worker` over `items` with at most `limit` running at once. */
async function runPool<T>(items: T[], limit: number, worker: (item: T) => Promise<void>, signal?: CancelSignal) {
  let next = 0;
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      if (signal?.aborted) throw new CancelledError();
      const item = items[next++];
      await worker(item);
    }
  });
  await Promise.all(runners);
}

/** Groups photos whose content hashes are identical. Pure, so it's easy to test. */
export function groupByContentHash(photos: Photo[]): DuplicateGroup[] {
  const byHash = new Map<string, Photo[]>();
  for (const p of photos) {
    if (p.hash.status !== 'complete') continue;
    byHash.set(p.hash.content, [...(byHash.get(p.hash.content) ?? []), p]);
  }
  const groups: DuplicateGroup[] = [];
  for (const [hash, list] of byHash) {
    if (list.length < 2) continue;
    // Oldest first; the oldest copy is marked as the reference copy.
    const sorted = [...list].sort((a, b) => a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id));
    groups.push({
      id: `sha256:${hash}`,
      kind: 'exact',
      similarity: 100,
      title: `${sorted.length} identical copies`,
      photoIds: sorted.map((p) => p.id),
      suggestedKeepId: sorted[0].id,
      suggestionReason: 'Oldest copy',
    });
  }
  // Biggest wasted space first.
  return groups.sort((a, b) => b.photoIds.length - a.photoIds.length);
}

export async function findExactDuplicates(
  catalog: PhotoCatalog,
  adapterFor: (photo: Photo) => PhotoSourceAdapter | undefined,
  { signal, onProgress, sizeConcurrency = 4 }: ExactScanOptions = {},
): Promise<ExactScanResult> {
  const photos: Record<PhotoId, Photo> = {};
  for (const p of Object.values(catalog.photos)) photos[p.id] = { ...p, hash: { status: 'pending' } };
  const all = Object.values(photos);
  const failed = emptyFailures();
  const fail = (p: Photo, reason: HashFailureReason, message?: string) => {
    photos[p.id] = { ...photos[p.id], hash: { status: 'failed', reason, message } };
    failed[reason] += 1;
  };

  // ── 1. Sizes ──────────────────────────────────────────────────────────
  let sized = 0;
  onProgress?.({ phase: 'sizing', done: 0, total: all.length });
  await runPool(
    all,
    sizeConcurrency,
    async (p) => {
      const adapter = adapterFor(p);
      if (!adapter?.getOriginalSize || !adapter.hashOriginal) {
        fail(p, 'not-supported');
      } else {
        try {
          const r = await adapter.getOriginalSize(p);
          photos[p.id] = { ...photos[p.id], availability: r.availability };
          if (r.ok) photos[p.id] = { ...photos[p.id], sizeBytes: r.size };
          else fail(p, r.reason, r.message);
        } catch (e) {
          fail(p, 'unreadable', e instanceof Error ? e.message : String(e));
        }
      }
      sized += 1;
      onProgress?.({ phase: 'sizing', done: sized, total: all.length });
    },
    signal,
  );

  // ── 2. Pick candidates: sizes shared by 2+ photos ──────────────────────
  const bySize = new Map<number, Photo[]>();
  for (const p of Object.values(photos)) {
    if (p.hash.status !== 'pending' || p.sizeBytes === undefined) continue;
    bySize.set(p.sizeBytes, [...(bySize.get(p.sizeBytes) ?? []), p]);
  }
  const candidates: Photo[] = [];
  let uniqueSize = 0;
  for (const list of bySize.values()) {
    if (list.length > 1) candidates.push(...list);
    else {
      photos[list[0].id] = { ...list[0], hash: { status: 'skipped', reason: 'unique-size' } };
      uniqueSize += 1;
    }
  }

  // ── 3. Hash candidates, one file at a time ─────────────────────────────
  const bytesTotal = candidates.reduce((n, p) => n + (p.sizeBytes ?? 0), 0);
  let bytesDone = 0;
  let filesDone = 0;
  let hashed = 0;
  let bytesHashed = 0;
  const report = () =>
    onProgress?.({ phase: 'hashing', filesDone, filesTotal: candidates.length, bytesDone, bytesTotal });
  report();

  for (const p of candidates) {
    // Cancel is checked between files: a single native digest can't be interrupted.
    if (signal?.aborted) throw new CancelledError();
    const adapter = adapterFor(p)!;
    photos[p.id] = { ...photos[p.id], hash: { status: 'processing' } };
    try {
      const r = await adapter.hashOriginal!(photos[p.id]);
      if (r.ok) {
        photos[p.id] = { ...photos[p.id], hash: { status: 'complete', content: r.sha256 } };
        hashed += 1;
        bytesHashed += p.sizeBytes ?? 0;
      } else {
        fail(p, r.reason, r.message);
      }
    } catch (e) {
      fail(p, 'unreadable', e instanceof Error ? e.message : String(e));
    }
    bytesDone += p.sizeBytes ?? 0;
    filesDone += 1;
    report();
  }

  return {
    photos,
    groups: groupByContentHash(Object.values(photos)),
    stats: { photosListed: all.length, hashed, uniqueSize, failed, bytesHashed },
  };
}
