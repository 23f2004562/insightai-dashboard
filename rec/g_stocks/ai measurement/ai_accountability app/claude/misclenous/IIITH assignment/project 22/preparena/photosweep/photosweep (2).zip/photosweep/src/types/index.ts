/**
 * Shared TypeScript types.
 *
 * Defining the shape of our data in one place means TypeScript can warn us
 * if a screen expects a field that doesn't exist. When the real scanner is
 * built later, it only has to produce data in these same shapes and the UI
 * will keep working.
 */

/** Where a photo lives. Later milestones will connect real libraries. */
export type LibraryKind = 'device' | 'cloud' | 'shared';

export interface PhotoLibrary {
  id: string;
  name: string;
  kind: LibraryKind;
}

export interface Photo {
  id: string;
  /** Image address used for the thumbnail. */
  uri: string;
  filename: string;
  libraryId: string;
  /** ISO date string, e.g. "2026-08-14T18:22:00Z" */
  takenAt: string;
  sizeBytes: number;
  width: number;
  height: number;
}

/**
 * exact   = byte-for-byte or pixel-identical copies
 * similar = burst shots, edits or re-saves that look nearly the same
 */
export type MatchKind = 'exact' | 'similar';

export interface DuplicateGroup {
  id: string;
  kind: MatchKind;
  /** 0–100. How alike the photos in the group are. */
  similarity: number;
  /** Short human-readable label, e.g. "Beach sunset, 4 burst shots". */
  title: string;
  photos: Photo[];
  /** The photo we would suggest keeping (largest / sharpest / original). */
  suggestedKeepId: string;
  /** Why that photo is suggested, shown to the user. */
  suggestionReason: string;
}

/** What the user decided for each photo. Undecided photos count as "keep". */
export type PhotoDecision = 'keep' | 'delete';

/**
 * Where the results came from. Only 'sample' exists in this milestone.
 * Keeping it as a field means the UI can always tell the user honestly
 * whether they are looking at sample or real results.
 */
export type ResultSource = 'sample' | 'device-scan';

export interface ScanSummary {
  source: ResultSource;
  totalPhotosScanned: number;
  librariesScanned: number;
  groups: DuplicateGroup[];
  completedAt: string;
}
