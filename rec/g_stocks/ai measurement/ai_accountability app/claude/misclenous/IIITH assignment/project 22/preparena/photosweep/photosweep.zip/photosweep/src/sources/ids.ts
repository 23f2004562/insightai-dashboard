import { AccountId, PhotoId, ProviderId } from '@/types';

/**
 * ID helpers. Provider IDs are only unique inside one provider or one account,
 * so we always prefix them. This guarantees uniqueness across every account.
 */

/** makeAccountId('google_photos', 'acct-work') → "google_photos:acct-work" */
export function makeAccountId(provider: ProviderId, providerAccountId: string): AccountId {
  return `${provider}:${providerAccountId}`;
}

/** makePhotoId('google_photos:acct-work', 'AF1Qip') → "google_photos:acct-work/AF1Qip" */
export function makePhotoId(accountId: AccountId, providerPhotoId: string): PhotoId {
  return `${accountId}/${providerPhotoId}`;
}
