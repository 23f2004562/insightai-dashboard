import { Feather } from '@expo/vector-icons';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';

import { sampleLibraries } from '@/data/sampleData';
import { decisionFor, Decisions, keptInGroup } from '@/state/selection';
import { colors, radius, spacing } from '@/theme';
import { DuplicateGroup } from '@/types';
import { plural } from '@/utils/format';
import { AppText } from './AppText';
import { PhotoThumb } from './PhotoThumb';

interface DuplicateGroupCardProps {
  group: DuplicateGroup;
  decisions: Decisions;
  onTogglePhoto: (photoId: string) => void;
  onUseSuggestion: () => void;
}

const THUMB = 104;

/** One group of matching photos with keep/delete controls. */
export function DuplicateGroupCard({ group, decisions, onTogglePhoto, onUseSuggestion }: DuplicateGroupCardProps) {
  const kept = keptInGroup(group, decisions).length;
  const toDelete = group.photos.length - kept;
  const suggested = group.photos.find((p) => p.id === group.suggestedKeepId);
  const followsSuggestion = group.photos.every(
    (p) => decisionFor(decisions, p.id) === (p.id === group.suggestedKeepId ? 'keep' : 'delete'),
  );

  const libraryNames = [...new Set(group.photos.map((p) => p.libraryId))]
    .map((id) => sampleLibraries.find((l) => l.id === id)?.name ?? id)
    .join(', ');

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View style={styles.headerText}>
          <AppText variant="heading">{group.title}</AppText>
          <AppText variant="small" color="inkSoft">
            {libraryNames}
          </AppText>
        </View>
        <View style={[styles.kind, group.kind === 'exact' ? styles.kindExact : styles.kindSimilar]}>
          <AppText variant="caption" style={styles.kindText}>
            {group.kind === 'exact' ? 'Exact copies' : `${group.similarity}% similar`}
          </AppText>
        </View>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.thumbs}>
        {group.photos.map((p) => (
          <PhotoThumb
            key={p.id}
            photo={p}
            size={THUMB}
            decision={decisionFor(decisions, p.id)}
            suggested={p.id === group.suggestedKeepId}
            onPress={() => onTogglePhoto(p.id)}
          />
        ))}
      </ScrollView>

      <View style={styles.footer}>
        <AppText variant="small" color="inkSoft" style={styles.footerText}>
          Keeping {kept}
          {toDelete > 0 ? (
            <AppText variant="smallStrong" color="remove">
              , deleting {toDelete}
            </AppText>
          ) : null}
        </AppText>
        {!followsSuggestion && (
          <Pressable
            onPress={onUseSuggestion}
            style={({ pressed }) => [styles.suggestBtn, pressed && { backgroundColor: colors.sunken }]}
            accessibilityRole="button"
            accessibilityLabel={`Use suggestion: keep ${suggested?.filename}`}
          >
            <Feather name="star" size={14} color={colors.accent} />
            <AppText variant="smallStrong" style={{ color: colors.accent }}>
              Keep best only
            </AppText>
          </Pressable>
        )}
      </View>
      {!followsSuggestion && suggested && (
        <AppText variant="caption" color="inkFaint" style={styles.reason}>
          Best: {suggested.filename}. {group.suggestionReason}. Deletes the other{' '}
          {plural(group.photos.length - 1, 'photo')}.
        </AppText>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  headerText: { flex: 1, gap: 2 },
  kind: { paddingHorizontal: spacing.xs, paddingVertical: 3, borderRadius: radius.sm },
  kindExact: { backgroundColor: colors.removeTint },
  kindSimilar: { backgroundColor: colors.sunken },
  kindText: { fontWeight: '600', color: colors.ink },
  thumbs: { gap: spacing.sm, paddingHorizontal: spacing.md, paddingVertical: spacing.md },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    minHeight: 36,
  },
  footerText: { flex: 1 },
  suggestBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.md,
  },
  reason: { paddingHorizontal: spacing.md, marginTop: 2 },
});
