import { DuplicateGroup, Photo, PhotoLibrary, ScanSummary } from '@/types';

/**
 * SAMPLE DATA — NOT REAL SCAN RESULTS.
 *
 * Everything in this file is invented so we can design and test the UI
 * before the real scanner exists. The thumbnails are free stock photos
 * from picsum.photos (loaded over the internet; nothing is uploaded).
 *
 * The UI labels these results as "Sample data" wherever they appear, and
 * ScanSummary.source is set to 'sample' so code can tell them apart from
 * real results later.
 */

export const sampleLibraries: PhotoLibrary[] = [
  { id: 'phone', name: 'Phone library', kind: 'device' },
  { id: 'gphotos', name: 'Google Photos', kind: 'cloud' },
  { id: 'family', name: 'Family shared album', kind: 'shared' },
];

const MB = 1024 * 1024;

/** Small helper so each sample photo is one readable line below. */
function photo(
  id: string,
  picsumId: number,
  libraryId: string,
  filename: string,
  takenAt: string,
  sizeMB: number,
  // Crop changes the framing, which makes "similar" photos look slightly different.
  crop: { w: number; h: number } = { w: 400, h: 400 },
  variant = '',
): Photo {
  return {
    id,
    uri: `https://picsum.photos/id/${picsumId}/${crop.w}/${crop.h}${variant}`,
    filename,
    libraryId,
    takenAt,
    sizeBytes: Math.round(sizeMB * MB),
    width: crop.w * 10,
    height: crop.h * 10,
  };
}

const square = { w: 400, h: 400 };
const wide = { w: 480, h: 400 };
const tall = { w: 400, h: 480 };

export const sampleGroups: DuplicateGroup[] = [
  {
    id: 'g1',
    kind: 'similar',
    similarity: 94,
    title: 'Burst of 4 shots',
    suggestedKeepId: 'p1b',
    suggestionReason: 'Sharpest of the burst',
    photos: [
      photo('p1a', 1015, 'phone', 'IMG_4821.HEIC', '2026-08-14T18:42:03Z', 3.1, square),
      photo('p1b', 1015, 'phone', 'IMG_4822.HEIC', '2026-08-14T18:42:03Z', 3.4, wide),
      photo('p1c', 1015, 'phone', 'IMG_4823.HEIC', '2026-08-14T18:42:04Z', 3.0, tall),
      photo('p1d', 1015, 'phone', 'IMG_4824.HEIC', '2026-08-14T18:42:04Z', 2.9, square, '?blur=1'),
    ],
  },
  {
    id: 'g2',
    kind: 'exact',
    similarity: 100,
    title: 'Same photo in 2 libraries',
    suggestedKeepId: 'p2a',
    suggestionReason: 'Original from your phone',
    photos: [
      photo('p2a', 1025, 'phone', 'IMG_3307.HEIC', '2026-06-02T09:15:40Z', 2.7),
      photo('p2b', 1025, 'gphotos', 'IMG_3307.HEIC', '2026-06-02T09:15:40Z', 2.7),
    ],
  },
  {
    id: 'g3',
    kind: 'exact',
    similarity: 100,
    title: 'Saved 3 times from a chat',
    suggestedKeepId: 'p3a',
    suggestionReason: 'Highest resolution copy',
    photos: [
      photo('p3a', 237, 'family', 'family-dog.jpg', '2026-09-21T16:03:11Z', 4.2),
      photo('p3b', 237, 'phone', 'IMG-20260921-WA0004.jpg', '2026-09-21T16:05:29Z', 0.31),
      photo('p3c', 237, 'phone', 'IMG-20260921-WA0007.jpg', '2026-09-21T16:05:52Z', 0.31),
    ],
  },
  {
    id: 'g4',
    kind: 'similar',
    similarity: 88,
    title: 'Original and edited copy',
    suggestedKeepId: 'p4b',
    suggestionReason: 'Your edited version',
    photos: [
      photo('p4a', 1016, 'phone', 'IMG_2290.HEIC', '2026-04-11T11:27:00Z', 3.8, wide, '?grayscale'),
      photo('p4b', 1016, 'phone', 'IMG_2290_edit.HEIC', '2026-04-12T08:02:14Z', 4.1, wide),
    ],
  },
  {
    id: 'g5',
    kind: 'similar',
    similarity: 91,
    title: 'Burst of 3 shots',
    suggestedKeepId: 'p5c',
    suggestionReason: 'Best focus and exposure',
    photos: [
      photo('p5a', 1069, 'gphotos', 'PXL_20260705_143201.jpg', '2026-07-05T14:32:01Z', 3.6, tall, '?blur=2'),
      photo('p5b', 1069, 'gphotos', 'PXL_20260705_143202.jpg', '2026-07-05T14:32:02Z', 3.5, square),
      photo('p5c', 1069, 'gphotos', 'PXL_20260705_143202_1.jpg', '2026-07-05T14:32:02Z', 3.9, tall),
    ],
  },
  {
    id: 'g6',
    kind: 'exact',
    similarity: 100,
    title: 'Same photo in 3 libraries',
    suggestedKeepId: 'p6a',
    suggestionReason: 'Original from your phone',
    photos: [
      photo('p6a', 1080, 'phone', 'IMG_1175.HEIC', '2026-05-18T19:48:22Z', 2.4),
      photo('p6b', 1080, 'gphotos', 'IMG_1175.HEIC', '2026-05-18T19:48:22Z', 2.4),
      photo('p6c', 1080, 'family', 'IMG_1175.jpeg', '2026-05-18T19:48:22Z', 1.9),
    ],
  },
  {
    id: 'g7',
    kind: 'similar',
    similarity: 86,
    title: 'Screenshot and cropped copy',
    suggestedKeepId: 'p7a',
    suggestionReason: 'Full, uncropped version',
    photos: [
      photo('p7a', 1074, 'phone', 'Screenshot_2026-10-03.png', '2026-10-03T21:10:45Z', 1.6, wide),
      photo('p7b', 1074, 'phone', 'Screenshot_2026-10-03 cropped.png', '2026-10-03T21:12:09Z', 0.9, square),
    ],
  },
];

/**
 * A sample summary the dashboard can display after the demo scan.
 * totalPhotosScanned is an invented figure for a typical library size.
 */
export function createSampleSummary(): ScanSummary {
  return {
    source: 'sample',
    totalPhotosScanned: 4812,
    librariesScanned: sampleLibraries.length,
    groups: sampleGroups,
    completedAt: new Date().toISOString(),
  };
}

/** Steps the demo scan screen walks through. */
export const scanStages = [
  'Listing photos in each library',
  'Creating a visual fingerprint for each photo',
  'Comparing fingerprints to find matches',
  'Grouping duplicates and picking the best copy',
] as const;
