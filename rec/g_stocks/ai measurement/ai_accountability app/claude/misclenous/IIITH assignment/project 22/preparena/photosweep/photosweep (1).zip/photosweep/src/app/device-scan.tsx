import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';

import { AppText, Button, ProgressBar, Screen } from '@/components';
import { DeviceScanProgress, runDeviceScan } from '@/scanning/deviceScan';
import { CancelledError } from '@/sources/catalog';
import { useScan } from '@/state/ScanContext';
import { colors, fonts, radius, spacing } from '@/theme';
import { formatBytes, formatCount } from '@/utils/format';

/**
 * REAL SCAN of this phone's photo library. Progress comes from the actual work:
 * listing photos, reading file sizes, and hashing original files.
 * Nothing is uploaded and nothing is deleted.
 */

const stages = [
  { key: 'listing', label: 'Listing photos on this phone' },
  { key: 'sizing', label: 'Checking each original file' },
  { key: 'hashing', label: 'Comparing file contents (SHA-256)' },
] as const;

/** Rough weighting so the bar moves steadily: listing 5%, sizes 35%, hashing 60%. */
function overall(p: DeviceScanProgress | null): number {
  if (!p) return 0;
  if (p.phase === 'listing') return 0.03;
  if (p.phase === 'sizing') return 0.05 + 0.35 * (p.total ? p.done / p.total : 1);
  return 0.4 + 0.6 * (p.bytesTotal ? p.bytesDone / p.bytesTotal : p.filesTotal ? p.filesDone / p.filesTotal : 1);
}

function detail(p: DeviceScanProgress | null): string {
  if (!p) return 'Starting';
  if (p.phase === 'listing') return `${formatCount(p.photosListed)} photos found so far`;
  if (p.phase === 'sizing') return `${formatCount(p.done)} of ${formatCount(p.total)} photos checked`;
  if (p.filesTotal === 0) return 'No photos share a file size, so none need comparing';
  return `${formatCount(p.filesDone)} of ${formatCount(p.filesTotal)} files compared, ${formatBytes(p.bytesDone)} of ${formatBytes(p.bytesTotal)}`;
}

export default function DeviceScanScreen() {
  const { limited } = useLocalSearchParams<{ limited?: string }>();
  const { setDeviceResults } = useScan();
  const [progress, setProgress] = useState<DeviceScanProgress | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const controller = useRef<AbortController | null>(null);

  useEffect(() => {
    const ac = new AbortController();
    controller.current = ac;
    let lastUpdate = 0;
    runDeviceScan({
      limitedAccess: limited === '1',
      signal: ac.signal,
      onProgress: (p) => {
        // Throttle screen updates to ~10 per second so the scan isn't slowed by rendering.
        const now = Date.now();
        if (now - lastUpdate > 100 || (p.phase === 'hashing' && p.filesDone === p.filesTotal)) {
          lastUpdate = now;
          setProgress(p);
        }
      },
    })
      .then((summary) => {
        if (ac.signal.aborted) return;
        setDeviceResults(summary);
        router.replace('/results');
      })
      .catch((e: unknown) => {
        if (e instanceof CancelledError || ac.signal.aborted) {
          router.back();
          return;
        }
        setError(e instanceof Error ? e.message : String(e));
      });
    // Leaving the screen stops the scan.
    return () => ac.abort();
  }, [limited, setDeviceResults]);

  const cancel = () => {
    setCancelling(true);
    controller.current?.abort();
  };

  const stageIndex = progress ? stages.findIndex((s) => s.key === progress.phase) : 0;
  const percent = Math.round(overall(progress) * 100);

  if (error) {
    return (
      <Screen tone="night" edges={['top', 'bottom', 'left', 'right']} contentStyle={styles.content}>
        <View style={styles.center}>
          <Feather name="alert-triangle" size={28} color={colors.onNight} />
          <AppText variant="title" color="onNight">
            The scan stopped
          </AppText>
          <AppText variant="body" color="onNightSoft">
            {error}
          </AppText>
          <AppText variant="small" color="onNightSoft">
            No photos were changed. You can try again from the overview.
          </AppText>
        </View>
        <Button label="Back to overview" variant="onNight" size="lg" onPress={() => router.replace('/home')} />
      </Screen>
    );
  }

  return (
    <Screen tone="night" edges={['top', 'bottom', 'left', 'right']} contentStyle={styles.content}>
      <View style={styles.note}>
        <Feather name="smartphone" size={14} color={colors.onNightSoft} />
        <AppText variant="caption" color="onNightSoft" style={styles.flex}>
          Real scan of this phone{limited === '1' ? ' (selected photos only)' : ''}. Nothing is uploaded or deleted.
        </AppText>
      </View>

      <View style={styles.center}>
        <AppText variant="small" color="onNightSoft">
          {cancelling ? 'Stopping after the current file' : 'Looking for exact duplicates'}
        </AppText>
        <AppText style={styles.percent} color="onNight" accessibilityLiveRegion="polite">
          {percent}%
        </AppText>
        <ProgressBar progress={overall(progress)} trackColor={colors.lineNight} fillColor={colors.onNight} height={6} />
        <AppText variant="small" color="onNightSoft" style={styles.tabular}>
          {detail(progress)}
        </AppText>
      </View>

      <View style={styles.stages}>
        {stages.map((s, i) => {
          const done = i < stageIndex;
          const active = i === stageIndex;
          return (
            <View key={s.key} style={styles.stage}>
              <View style={[styles.dot, done && styles.dotDone]}>
                {done ? (
                  <Feather name="check" size={13} color={colors.night} />
                ) : active ? (
                  <ActivityIndicator size="small" color={colors.onNight} />
                ) : (
                  <AppText variant="caption" color="onNightSoft">
                    {i + 1}
                  </AppText>
                )}
              </View>
              <AppText variant="small" color={done || active ? 'onNight' : 'onNightSoft'} style={styles.flex}>
                {s.label}
              </AppText>
            </View>
          );
        })}
      </View>

      <Button label={cancelling ? 'Cancelling' : 'Cancel'} variant="ghost" onPress={cancel} disabled={cancelling} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { justifyContent: 'space-between', paddingTop: spacing.md, paddingBottom: spacing.md },
  flex: { flex: 1 },
  note: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.lineNight,
  },
  center: { gap: spacing.sm },
  percent: {
    fontFamily: fonts.displayHeavy,
    fontSize: 96,
    lineHeight: 100,
    letterSpacing: -4,
    fontVariant: ['tabular-nums'],
  },
  tabular: { fontVariant: ['tabular-nums'] },
  stages: { gap: spacing.md, backgroundColor: colors.nightRaised, borderRadius: radius.lg, padding: spacing.lg },
  stage: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  dot: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: colors.lineNight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dotDone: { backgroundColor: colors.onNight, borderColor: colors.onNight },
});
