import { getPermissionsAsync, presentPermissionsPicker, requestPermissionsAsync } from 'expo-media-library';
import { Linking, Platform } from 'react-native';

import { LibraryAccess, toLibraryAccess } from '@/scanning/permissions';

/**
 * Thin wrappers around expo-media-library's permission calls.
 * We only ever ask for read access to PHOTOS (no video, audio, or saving).
 */

const supported = Platform.OS === 'ios' || Platform.OS === 'android';

/** Reads the current state without showing any prompt. */
export async function checkLibraryAccess(): Promise<LibraryAccess> {
  if (!supported) return 'unavailable';
  return toLibraryAccess(await getPermissionsAsync(false, ['photo']));
}

/** Shows the system prompt. Only call this after the user taps a clear button. */
export async function requestLibraryAccess(): Promise<LibraryAccess> {
  if (!supported) return 'unavailable';
  return toLibraryAccess(await requestPermissionsAsync(false, ['photo']));
}

/** With limited access, lets the user add more photos (iOS, Android 14+). */
export async function chooseMorePhotos(): Promise<LibraryAccess> {
  if (!supported) return 'unavailable';
  await presentPermissionsPicker(['photo']);
  return checkLibraryAccess();
}

export function openAppSettings(): Promise<void> {
  return Linking.openSettings();
}
