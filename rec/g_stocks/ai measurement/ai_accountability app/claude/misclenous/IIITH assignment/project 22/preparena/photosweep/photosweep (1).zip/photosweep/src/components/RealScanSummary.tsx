import { Feather } from '@expo/vector-icons';
import { StyleSheet, View } from 'react-native';

import { getPhotos } from '@/sources/catalog';
import { totalBytes } from '@/state/selection';
import { colors, radius, spacing } from '@/theme';
import { ScanSummary } from '@/types';
import { formatBytes, formatCount, plural } from '@/utils/format';
import { AppText } from './AppText';

/**
 * Honest summary of a REAL scan: what was checked, what wasn't, and why.
 * It never claims space was freed; it only reports space taken by extra copies.
 */
export function RealScanSummary({ summary }: { summary: ScanSummary }) {
  const stats = summary.stats;
  if (!stats) return null;
  const accountName = Object.values(summary.catalog.accounts)[0]?.displayName ?? 'this phone';
  const extraCopies = summary.groups.flatMap((g) => getPhotos(summary.catalog, g.photoIds.slice(1)));
  const notChecked = stats.failed['cloud-only'] + stats.failed.unreadable + stats.failed['not-supported'];

  const rows: { label: string; value: string; note?: string }[] = [
    { label: 'Photos found', value: formatCount(stats.photosListed) },
    {
      label: 'Compared by file contents',
      value: formatCount(stats.hashed),
      note: 'Only photos that share an exact file size with another photo need comparing.',
    },
    { label: 'Unique file size, so no exact copy possible', value: formatCount(stats.uniqueSize) },
  ];
  if (stats.failed['cloud-only'] > 0) {
    rows.push({
      label: 'Original stored only in iCloud, not checked',
      value: formatCount(stats.failed['cloud-only']),
      note: 'PhotoSweep does not download originals. Copies of these photos may not be found.',
    });
  }
  if (stats.failed.unreadable + stats.failed['not-supported'] > 0) {
    rows.push({
      label: "Couldn't be read, not checked",
      value: formatCount(stats.failed.unreadable + stats.failed['not-supported']),
    });
  }

  return (
    <View style={styles.wrap}>
      <View style={styles.banner}>
        <Feather name="smartphone" size={16} color={colors.keep} style={styles.icon} />
        <AppText variant="small" style={styles.flex}>
          Real results from {accountName}. Photos are grouped only when their original files are byte-for-byte identical
          (same SHA-256). Review only: nothing can be deleted in this version.
        </AppText>
      </View>

      {stats.limitedAccess && (
        <View style={[styles.banner, styles.warn]}>
          <Feather name="grid" size={16} color={colors.sample} style={styles.icon} />
          <AppText variant="small" style={styles.flex}>
            You shared selected photos only, so duplicates of other photos can't be found.
          </AppText>
        </View>
      )}

      <View style={styles.panel}>
        <View style={styles.headline}>
          <AppText variant="number">{formatCount(summary.groups.length)}</AppText>
          <AppText variant="small" color="inkSoft">
            {summary.groups.length === 1 ? 'group of identical photos' : 'groups of identical photos'}
            {extraCopies.length > 0
              ? `, with ${plural(extraCopies.length, 'extra copy', 'extra copies')} taking ${formatBytes(totalBytes(extraCopies))}`
              : ''}
          </AppText>
        </View>
        {rows.map((r) => (
          <View key={r.label} style={styles.row}>
            <View style={styles.flex}>
              <AppText variant="small">{r.label}</AppText>
              {r.note && (
                <AppText variant="caption" color="inkFaint">
                  {r.note}
                </AppText>
              )}
            </View>
            <AppText variant="smallStrong" style={styles.value}>
              {r.value}
            </AppText>
          </View>
        ))}
      </View>

      {summary.groups.length === 0 && (
        <View style={styles.empty}>
          <AppText variant="heading">No exact duplicates found</AppText>
          <AppText variant="small" color="inkSoft">
            None of the {formatCount(stats.hashed + stats.uniqueSize)} photos that could be checked have a byte-for-byte
            copy among the photos PhotoSweep could see.
            {notChecked > 0 ? ` ${plural(notChecked, 'photo')} couldn't be checked (listed above).` : ''} Visually
            similar photos, such as bursts or edited versions, aren't detected yet.
          </AppText>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: spacing.md },
  flex: { flex: 1 },
  banner: {
    flexDirection: 'row',
    gap: spacing.xs,
    backgroundColor: colors.keepTint,
    padding: spacing.sm,
    borderRadius: radius.md,
    borderLeftWidth: 3,
    borderLeftColor: colors.keep,
  },
  warn: { backgroundColor: colors.sampleTint, borderLeftColor: colors.sample },
  icon: { marginTop: 2 },
  panel: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.md,
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: colors.line,
  },
  headline: { gap: 2, paddingBottom: spacing.xs },
  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    paddingTop: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth * 2,
    borderTopColor: colors.line,
  },
  value: { fontVariant: ['tabular-nums'] },
  empty: { gap: spacing.xs, paddingVertical: spacing.sm },
});
