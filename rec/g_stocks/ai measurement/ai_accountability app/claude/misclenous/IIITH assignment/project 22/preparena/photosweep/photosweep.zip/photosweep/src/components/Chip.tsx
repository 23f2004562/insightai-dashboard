import { Pressable, StyleSheet } from 'react-native';

import { colors, radius, spacing } from '@/theme';
import { AppText } from './AppText';

interface ChipProps {
  label: string;
  selected: boolean;
  onPress: () => void;
}

/** A small toggle used for filters ("All", "Exact copies", …). */
export function Chip({ label, selected, onPress }: ChipProps) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected }}
      style={[styles.chip, selected ? styles.on : styles.off]}
    >
      <AppText variant="smallStrong" style={{ color: selected ? colors.paper : colors.inkSoft }}>
        {label}
      </AppText>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  chip: { paddingHorizontal: spacing.sm, paddingVertical: 7, borderRadius: radius.pill, borderWidth: 1 },
  on: { backgroundColor: colors.ink, borderColor: colors.ink },
  off: { backgroundColor: 'transparent', borderColor: colors.line },
});
