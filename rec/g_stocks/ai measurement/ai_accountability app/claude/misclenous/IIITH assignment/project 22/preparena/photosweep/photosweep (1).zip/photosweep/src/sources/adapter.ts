import { AccountId, Availability, HashFailureReason, Photo, PhotoId, ProviderId, SourceAccount } from '@/types';

/**
 * THE PLUG-IN CONTRACT FOR PHOTO SOURCES.
 *
 * Every way of reading photos implements this interface. The rest of the
 * app (catalog, duplicate detection, screens) only talks to this interface,
 * so new sources can be added without touching the UI.
 *
 * Implemented:
 *   sample/sampleAdapter.ts        invented accounts and photos (demo mode)
 *   device/deviceAdapter.ts        this phone's photo library (expo-media-library)
 *
 * Planned (same interface):
 *   google/pickerAdapter.ts        Google Photos Picker API (user-picked items only)
 *   onedrive/graphAdapter.ts       Microsoft Graph
 */

export interface PhotoPage {
  photos: Photo[];
  /** Pass back to listPhotos() for the next page. Undefined = no more pages. */
  nextCursor?: string;
}

export type OriginalSizeResult =
  | { ok: true; size: number; availability: Availability }
  | { ok: false; reason: HashFailureReason; message?: string; availability: Availability };

export type HashOriginalResult =
  | { ok: true; sha256: string }
  | { ok: false; reason: HashFailureReason; message?: string };

export interface PhotoSourceAdapter {
  /** Stable name for this adapter, e.g. 'sample', 'device-media-library'. */
  readonly id: string;
  /** Which providers' accounts this adapter can return. */
  readonly providers: readonly ProviderId[];

  /** Can this adapter run on this platform right now? (e.g. not on web) */
  isAvailable(): boolean;

  /** Accounts this adapter can see. A provider can return several (multiple Google accounts). */
  listAccounts(): Promise<SourceAccount[]>;

  /** One page of an account's photo collection. Photos must use IDs from makePhotoId(). */
  listPhotos(accountId: AccountId, cursor?: string): Promise<PhotoPage>;

  /**
   * Exact byte size of the full ORIGINAL file, without reading its contents.
   * Must not download cloud-only originals; report them as 'cloud-only' instead.
   */
  getOriginalSize?(photo: Photo): Promise<OriginalSizeResult>;

  /**
   * SHA-256 (lowercase hex) of every byte of the full ORIGINAL file.
   * Never a thumbnail or preview. Must stream the file rather than load it whole.
   */
  hashOriginal?(photo: Photo): Promise<HashOriginalResult>;

  /**
   * ONLY for providers whose deletionPolicy is 'system-dialog' (the device library).
   * Not implemented by any adapter in this milestone, and nothing calls it.
   */
  requestDeletion?(photoIds: PhotoId[]): Promise<{ deleted: PhotoId[]; cancelled: boolean }>;
}
