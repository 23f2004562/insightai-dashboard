/**
 * Exact-duplicate tests using REAL files on disk.
 *
 * The test adapter mirrors the device adapter's contract: it reports exact
 * byte sizes and streams each file through SHA-256 (here with Node's crypto;
 * on the phone, expo-file-system's native File.digest). Run with: npm test
 */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, describe, it } from 'node:test';

import { PhotoSourceAdapter } from '@/sources/adapter';
import { buildCatalog } from '@/sources/catalog';
import { makeAccountId, makePhotoId } from '@/sources/ids';
import { findExactDuplicates, groupByContentHash, ScanProgress } from '@/scanning/exactDuplicates';
import { Photo } from '@/types';

const ACC = makeAccountId('device', 'test-device');
let dir: string;
const files: Record<string, string> = {};

function sha256File(path: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const h = createHash('sha256');
    createReadStream(path, { highWaterMark: 64 * 1024 })
      .on('data', (c) => h.update(c))
      .on('end', () => resolve(h.digest('hex')))
      .on('error', reject);
  });
}

before(() => {
  dir = mkdtempSync(join(tmpdir(), 'photosweep-'));
  // Deterministic pseudo-random bytes so files look like real binary data.
  const bytes = (n: number, seed: number) => {
    const b = Buffer.alloc(n);
    let x = seed;
    for (let i = 0; i < n; i++) {
      x = (x * 1103515245 + 12345) >>> 0;
      b[i] = x >>> 24;
    }
    return b;
  };
  const original = bytes(300_000, 1);
  const tweaked = Buffer.from(original);
  tweaked[150_000] ^= 0xff; // same size, one byte different
  const write = (name: string, data: Buffer) => {
    files[name] = join(dir, name);
    writeFileSync(files[name], data);
  };
  write('IMG_0001.jpg', original);
  write('IMG_0001 copy.jpg', original); // byte-identical copy
  write('IMG_0002.jpg', tweaked); // same size as original, different bytes
  write('IMG_0003.jpg', bytes(300_000, 99)); // same size, totally different bytes
  write('IMG_0004.jpg', bytes(123_456, 7)); // unique size
  write('IMG_0001.jpg-renamed.png', bytes(10, 3)); // similar name, different content
});

after(() => rmSync(dir, { recursive: true, force: true }));

function testAdapter(cloudOnly: Set<string> = new Set()): PhotoSourceAdapter {
  const names = () => Object.keys(files).concat(['IMG_9999 (iCloud).HEIC']);
  return {
    id: 'node-files',
    providers: ['device'],
    isAvailable: () => true,
    listAccounts: async () => [
      { id: ACC, provider: 'device', providerAccountId: 'test-device', displayName: 'Test', connection: 'connected' },
    ],
    listPhotos: async () => ({
      photos: names().map((name): Photo => ({
        id: makePhotoId(ACC, name),
        accountId: ACC,
        provider: 'device',
        providerPhotoId: name,
        uri: name,
        filename: 'IMG.jpg', // same filename for ALL photos: must not affect grouping
        createdAt: '2026-01-01T00:00:00.000Z', // same date for all
        width: 4032,
        height: 3024, // same dimensions for all
        hash: { status: 'pending' },
      })),
    }),
    async getOriginalSize(p) {
      if (cloudOnly.has(p.providerPhotoId) || !files[p.providerPhotoId]) {
        return { ok: false, reason: 'cloud-only', availability: 'cloud-only' };
      }
      return { ok: true, size: statSync(files[p.providerPhotoId]).size, availability: 'local' };
    },
    async hashOriginal(p) {
      return { ok: true, sha256: await sha256File(files[p.providerPhotoId]) };
    },
  };
}

describe('findExactDuplicates', () => {
  it('groups only byte-identical files, ignoring names, dates, dimensions and size', async () => {
    const adapter = testAdapter();
    const catalog = await buildCatalog([adapter]);
    const progress: ScanProgress[] = [];
    const result = await findExactDuplicates(catalog, () => adapter, { onProgress: (p) => progress.push(p) });

    assert.equal(result.groups.length, 1, 'exactly one duplicate group');
    const ids = result.groups[0].photoIds.map((id) => result.photos[id].providerPhotoId).sort();
    assert.deepEqual(ids, ['IMG_0001 copy.jpg', 'IMG_0001.jpg']);
    assert.equal(result.groups[0].kind, 'exact');

    // The hash is the real SHA-256 of the file bytes.
    const expected = createHash('sha256').update(readFileSync(files['IMG_0001.jpg'])).digest('hex');
    const h = result.photos[makePhotoId(ACC, 'IMG_0001.jpg')].hash;
    assert.equal(h.status, 'complete');
    assert.equal(h.status === 'complete' && h.content, expected);

    // Same size but different bytes: hashed, NOT grouped.
    for (const name of ['IMG_0002.jpg', 'IMG_0003.jpg']) {
      const s = result.photos[makePhotoId(ACC, name)].hash;
      assert.equal(s.status, 'complete');
      assert.notEqual(s.status === 'complete' && s.content, expected);
    }
    // Unique sizes: never hashed, honestly marked as skipped.
    assert.deepEqual(result.photos[makePhotoId(ACC, 'IMG_0004.jpg')].hash, {
      status: 'skipped',
      reason: 'unique-size',
    });
    // Cloud-only original: not downloaded, marked failed with a reason.
    const cloud = result.photos[makePhotoId(ACC, 'IMG_9999 (iCloud).HEIC')];
    assert.deepEqual(cloud.hash, { status: 'failed', reason: 'cloud-only', message: undefined });
    assert.equal(cloud.availability, 'cloud-only');

    assert.equal(result.stats.hashed, 4);
    assert.equal(result.stats.uniqueSize, 2);
    assert.equal(result.stats.failed['cloud-only'], 1);

    const last = progress[progress.length - 1];
    assert.equal(last.phase, 'hashing');
    assert.ok(last.phase === 'hashing' && last.filesDone === last.filesTotal && last.bytesDone === last.bytesTotal);
  });

  it('records unreadable files without crashing the scan', async () => {
    const adapter = testAdapter();
    adapter.hashOriginal = async () => {
      throw new Error('permission denied');
    };
    const catalog = await buildCatalog([adapter]);
    const result = await findExactDuplicates(catalog, () => adapter);
    assert.equal(result.groups.length, 0);
    assert.equal(result.stats.failed.unreadable, 4);
  });

  it('can be cancelled', async () => {
    const adapter = testAdapter();
    const catalog = await buildCatalog([adapter]);
    const signal = { aborted: false };
    await assert.rejects(
      findExactDuplicates(catalog, () => adapter, {
        signal,
        onProgress: (p) => {
          if (p.phase === 'hashing' && p.filesDone === 1) signal.aborted = true;
        },
      }),
      { name: 'CancelledError' },
    );
  });
});

describe('groupByContentHash', () => {
  it('never groups photos that are not fully hashed', () => {
    const base: Photo = {
      id: 'a',
      accountId: ACC,
      provider: 'device',
      providerPhotoId: 'a',
      uri: '',
      filename: 'x',
      createdAt: '',
      width: 1,
      height: 1,
      hash: { status: 'pending' },
    };
    const groups = groupByContentHash([
      { ...base, id: 'a', hash: { status: 'pending' } },
      { ...base, id: 'b', hash: { status: 'pending' } },
      { ...base, id: 'c', hash: { status: 'skipped', reason: 'unique-size' } },
    ]);
    assert.equal(groups.length, 0);
  });
});
